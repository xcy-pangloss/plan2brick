# Plan2Brick portable tool

Local workbench + deterministic LEGO interior generator.

## Quick start (Windows)

1. Install Python 3.10+ (3.14 tested) and `pip install -r requirements.txt`.
2. Double-click `start-workbench.cmd`; open http://127.0.0.1:8000/app/workbench.html.
3. Pick a preset (Studio/1-BR/2-BR/3-BR, or real R1/R2/R3), edit rooms,
   enter a brief, Generate 3/6/9 candidates. The Walls selector offers a
   1.2 m cutaway, a 2.4 m real-height mode (1.92 m doors + lintel), and a
   translucent 2.4 m mode. The candidate panel reports layout closure and
   door clipping checks.
   For an uploaded floor plan, switch Source to Upload; the vision call
   uses `lego-nova/modelbench/config.local.json` (Claude/GPT). Set the API
   key file/env there, or the upload mode returns a clear error.

CLI equivalent:

```powershell
plan2brick.cmd generate --plan 2br --brief "Use the dining room as a study." --candidates 6 --diversity fidelity
```

Outputs are written under `lego-nova/out/workbench/` or `lego-nova/out/plan2brick/`.

## 3D viewer / LDraw

The workbench's 3D player needs the LDraw parts library. Set `LDRAW_DIR` to a
directory containing `parts/`, `p/`, `models/` (for example the local BrickNet
LDraw copy), or pass `--ldraw PATH`. Without it the static page still works but
the player reports missing parts.

## What is in the package

- `lego-nova/app/` — workbench and viewer
- `lego-nova/novalib/` — deterministic brief, floorplan, solver, walls/floors, diversity
- `lego-nova/nova.py` — CLI entry
- `fyp-pipeline/check_ir.py` — IR validator
- `fyp-pipeline/library/` — promoted library used by default
- `examples/` — sample IR and brief

No model calls are made by the workbench or the default generator; the only
optional model use is perception/LLM comparison in the research pipeline.
