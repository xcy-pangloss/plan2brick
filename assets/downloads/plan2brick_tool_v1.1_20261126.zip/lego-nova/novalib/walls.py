"""Deterministic LEGO walls for Plan2Brick scenes.

Rooms in ``assembly.py`` are LDU rectangles (x0, z0, x1, z1).  Their boundary
edges become a one-stud-thick wall on a global 20-LDU grid, five standard brick
courses high (120 LDU = 1.2 m).  The result is real LDraw geometry: every wall
brick is a ``1 ...`` line in the MPD and is counted in the BOM.

Design notes
------------
* One grid convention everywhere: a wall line at ``at`` uses row/column
  ``floor(at / 20 + eps)``; a run from ``a`` to ``b`` covers cells
  ``floor(a/20) .. ceil(b/20)-1``.  Shared room edges therefore land on the
  same cells and are emitted once.
* Corners and T-junctions are cells with both an ``h`` and a ``v`` flag.  Each
  course gives the shared cell to exactly one orientation (horizontal on even
  courses, vertical on odd ones), so courses interlock and every cell is
  covered exactly once per course.
* Brick lengths {1,2,3,4,6,8} are packed exactly; 1x3 is ``3622`` (Brick 1x3),
  never ``3623`` (Plate 1x3, 8 LDU tall).  Greedy packing avoids leaving a
  single-stud remainder, and the starting length rotates with course/run for
  a running-bond look.

Pure Python, no LDraw or three.js dependency.
"""
from __future__ import annotations

import math

LDU = 20
WALL_COURSES = 5
WALL_HEIGHT_LDU = WALL_COURSES * 24  # 120 LDU = 1.2 m
WALL_THICKNESS_LDU = LDU             # one stud thick
WALL_COLOR = 71                      # Light Bluish Gray
WALLS_MARKER = "0 // ---- WALLS (LEGO bricks) ----"
OPENINGS_MARKER = "0 // ---- DOORS / WINDOWS ----"
DOOR_PART = "3861a"       # Door 1x4x5 with 4 panes
DOOR_COLOR = 6           # reddish brown: reads as a wooden door, distinct from blue window glass
WINDOW_FRAME_PART = "3853"  # Window 1x4x3
WINDOW_GLASS_PART = "3855b" # Glass for Window 1x4x3, no handle
WINDOW_GLASS_COLOR = 43  # Trans-Light Blue
FRAME_COLOR = 71         # Light Bluish Gray

# length in studs -> LDraw part.  3622 is Brick 1 x 3; 3623 is Plate 1 x 3.
WALL_BRICK_BY_LENGTH = {
    1: "3005",  # Brick 1 x 1
    2: "3004",  # Brick 1 x 2
    3: "3622",  # Brick 1 x 3
    4: "3010",  # Brick 1 x 4
    6: "3009",  # Brick 1 x 6
    8: "3008",  # Brick 1 x 8
}
ALLOWED_LENGTHS = (8, 6, 4, 3, 2, 1)
STARTS = (4, 3, 2, 1, 6, 8)
MATRIX_H = "1 0 0 0 1 0 0 0 1"
MATRIX_V = "0 0 1 0 1 0 -1 0 0"

EPS = 1e-6
# A wall/furniture pair only counts as overlapping when both axes have positive
# area above this threshold.  Furniture coordinates are floats, so a piece that
# merely touches a wall face can sit ~1e-15 LDU past it; real interference is
# >= 1 LDU.  1e-3 LDU matches fyp-pipeline/evaluate.py's EPS_LDU.
EPS_OVERLAP = 1e-3


def _cell_index(v: float) -> int:
    return int(math.floor(v / LDU + EPS))


def _cell_end(v: float) -> int:
    """Last cell index covered by an endpoint (inclusive)."""
    return int(math.ceil(v / LDU - EPS)) - 1


def _interval_cells(a: float, b: float) -> range:
    i0 = _cell_index(a)
    i1 = _cell_end(b)
    if i1 < i0:
        i1 = i0  # degenerate/very short edge still gets one cell
    return range(i0, i1 + 1)


def wall_segments(rooms: list[dict], tol: float = 2.0) -> list[dict]:
    """Merge room-boundary edges into wall centre-line segments.

    ``rooms`` need ``x0/z0/x1/z1`` in LDU.  Collinear intervals whose offset
    differs by at most ``tol`` LDU are grouped and merged.  Segments are for
    reporting/tests; ``wall_cells`` rasterises the same edges directly.
    """
    horiz: list[tuple[float, float, float]] = []
    vert: list[tuple[float, float, float]] = []
    for r in rooms:
        x0, z0, x1, z1 = (float(r[k]) for k in ("x0", "z0", "x1", "z1"))
        horiz.append((z0, x0, x1))
        horiz.append((z1, x0, x1))
        vert.append((x0, z0, z1))
        vert.append((x1, z0, z1))

    def merge(edges: list[tuple[float, float, float]], axis: str) -> list[dict]:
        edges = sorted(edges, key=lambda e: (e[0], e[1], e[2]))
        groups: list[list[tuple[float, float, float]]] = []
        for e in edges:
            if groups and abs(e[0] - groups[-1][0][0]) <= tol:
                groups[-1].append(e)
            else:
                groups.append([e])
        out = []
        for group in groups:
            at = sum(e[0] for e in group) / len(group)
            intervals = sorted((e[1], e[2]) for e in group)
            merged = [list(intervals[0])]
            for a, b in intervals[1:]:
                if a <= merged[-1][1] + tol:
                    merged[-1][1] = max(merged[-1][1], b)
                else:
                    merged.append([a, b])
            for a, b in merged:
                if b - a > EPS:
                    out.append({"axis": axis, "at": round(at, 4),
                                "a": round(a, 4), "b": round(b, 4)})
        return out

    return merge(horiz, "h") + merge(vert, "v")


def wall_cells(rooms: list[dict]) -> dict[tuple[int, int], dict[str, bool]]:
    """Map room boundaries to global 20-LDU cells.

    Returns ``{(i, j): {"h": bool, "v": bool}}`` where ``i`` indexes x and
    ``j`` indexes z.  ``h`` means a horizontal wall crosses the cell, ``v`` a
    vertical one; corner/T cells carry both flags.
    """
    cells: dict[tuple[int, int], dict[str, bool]] = {}
    for seg in wall_segments(rooms):
        if seg["axis"] == "h":
            j = _cell_index(seg["at"])
            for i in _interval_cells(seg["a"], seg["b"]):
                cells.setdefault((i, j), {"h": False, "v": False})["h"] = True
        else:
            i = _cell_index(seg["at"])
            for j in _interval_cells(seg["a"], seg["b"]):
                cells.setdefault((i, j), {"h": False, "v": False})["v"] = True
    return cells


def _runs(cells: set[tuple[int, int]], axis: str) -> list[list[tuple[int, int]]]:
    """Split a cell set into contiguous same-row/column runs."""
    if not cells:
        return []
    if axis == "h":
        key, step = (lambda c: c[1]), (lambda c: c[0])
    else:
        key, step = (lambda c: c[0]), (lambda c: c[1])
    grouped: dict[int, list[int]] = {}
    for cell in cells:
        grouped.setdefault(key(cell), []).append(step(cell))
    runs = []
    for fixed in sorted(grouped):
        values = sorted(grouped[fixed])
        start = prev = values[0]
        for v in values[1:]:
            if v != prev + 1:
                runs.append([(start, fixed) if axis == "h" else (fixed, start),
                             (prev, fixed) if axis == "h" else (fixed, prev)])
                start = v
            prev = v
        runs.append([(start, fixed) if axis == "h" else (fixed, start),
                     (prev, fixed) if axis == "h" else (fixed, prev)])
    # expand (first, last) endpoints into the full cell list
    expanded = []
    for first, last in runs:
        n = last[0] - first[0] + 1 if axis == "h" else last[1] - first[1] + 1
        expanded.append([(first[0] + k, first[1]) if axis == "h"
                         else (first[0], first[1] + k) for k in range(n)])
    return expanded


def pack_run(length: int, phase: int = 0) -> list[int]:
    """Exact partition of a run into allowed brick lengths.

    The first brick cycles through STARTS so adjacent courses stagger; the
    remainder is filled longest-first while never leaving a lone 1-stud brick.
    """
    if length <= 0:
        return []
    out: list[int] = []
    rem = length
    for k in range(len(STARTS)):
        start = STARTS[(phase + k) % len(STARTS)]
        if start <= rem and rem - start != 1:
            out.append(start)
            rem -= start
            break
    if not out:  # length 1, or a pathological start set
        out.append(rem)
        rem = 0
    while rem > 0:
        if rem in WALL_BRICK_BY_LENGTH:
            out.append(rem)
            break
        take = None
        for cand in ALLOWED_LENGTHS:
            if cand <= rem and rem - cand != 1:
                take = cand
                break
        if take is None:
            take = 1
        out.append(take)
        rem -= take
    return out


def _make_brick(cells: list[tuple[int, int]], course: int, yaw: int,
                color: int = WALL_COLOR) -> dict:
    i0 = min(c[0] for c in cells)
    i1 = max(c[0] for c in cells)
    j0 = min(c[1] for c in cells)
    j1 = max(c[1] for c in cells)
    length = len(cells)
    part = WALL_BRICK_BY_LENGTH[length]
    if yaw == 0:  # horizontal: long axis along x
        cx = (i0 + i1 + 1) * LDU / 2
        cz = j0 * LDU + LDU / 2
        aabb = [i0 * LDU, j0 * LDU, (i1 + 1) * LDU, (j1 + 1) * LDU]
        matrix = MATRIX_H
    else:         # vertical: long axis along z
        cx = i0 * LDU + LDU / 2
        cz = (j0 + j1 + 1) * LDU / 2
        aabb = [i0 * LDU, j0 * LDU, (i1 + 1) * LDU, (j1 + 1) * LDU]
        matrix = MATRIX_V
    return {
        "part": part,
        "color": color,
        "course": course,
        "center_ldu": [round(cx, 1), round(-24.0 * course, 1), round(cz, 1)],
        "yaw": yaw,
        "cells": [list(c) for c in cells],
        "aabb_ldu": [round(v, 1) for v in aabb],
        "matrix": matrix,
    }


def _room_edges(rooms: list[dict]) -> list[dict]:
    edges = []
    for idx, r in enumerate(rooms):
        x0, z0, x1, z1 = (float(r[k]) for k in ("x0", "z0", "x1", "z1"))
        edges.append({"room": idx, "axis": "h", "at": z0, "a": x0, "b": x1, "side": "N"})
        edges.append({"room": idx, "axis": "h", "at": z1, "a": x0, "b": x1, "side": "S"})
        edges.append({"room": idx, "axis": "v", "at": x0, "a": z0, "b": z1, "side": "W"})
        edges.append({"room": idx, "axis": "v", "at": x1, "a": z0, "b": z1, "side": "E"})
    return edges


def _overlap(a: float, b: float, c: float, d: float) -> float:
    return min(b, d) - max(a, c)


def _opening_cells(axis: str, at: float, a: float, b: float,
                   width_cells: int) -> list[tuple[int, int]]:
    if axis == "h":
        i0, i1 = _cell_index(a), _cell_end(b)
        j = _cell_index(at)
        n = i1 - i0 + 1
        if n < width_cells + 2:
            return []
        start = i0 + (n - width_cells) // 2
        return [(i, j) for i in range(start, start + width_cells)]
    j0, j1 = _cell_index(a), _cell_end(b)
    i = _cell_index(at)
    n = j1 - j0 + 1
    if n < width_cells + 2:
        return []
    start = j0 + (n - width_cells) // 2
    return [(i, j) for j in range(start, start + width_cells)]


def _door_priority(rooms: list[dict], pair: tuple[int, int]) -> int:
    """Connection preference for the apartment door tree (lower is better).

    A normal flat is entered once and the hallway is the distribution spine.
    Connecting through the hallway/living space is preferred; a direct
    bedroom-to-bedroom or bathroom-to-kitchen door is only a last resort when
    the layout has no corridor.
    """
    types = {rooms[i].get("room_type") for i in pair if 0 <= i < len(rooms)}
    if "hallway" in types:
        return 0
    if "living" in types:
        return 1
    if {"dining", "kitchen"} <= types:
        return 1
    if "bathroom" in types and (types & {"hallway", "living"}):
        return 1
    if "bathroom" in types:
        return 4
    if types == {"bedroom"}:
        return 5
    return 3


def window_courses(courses: int = WALL_COURSES) -> list[int]:
    """Three glass courses at a real-world sill height.

    Five-course walls keep the original 2-4 band (0.48-1.2 m).  Taller
    presentation walls put the window at courses 4-6 (0.96-1.68 m), which
    leaves a proper sill and a lintel above.
    """
    courses = max(1, int(courses))
    start = 4 if courses >= 8 else 2
    start = min(start, max(1, courses - 2))
    return [c for c in (start, start + 1, start + 2) if c <= courses]


def wall_openings(rooms: list[dict], door_width: int = 4, window_width: int = 4,
                  courses: int = WALL_COURSES) -> list[dict]:
    """Deterministic door/window openings for the wall raster.

    * Interior doors form a **minimum spanning tree** over the room adjacency
      graph, rooted at the hallway (or living room).  This gives one sensible
      door per connected room instead of a door on every shared edge, keeps
      bedroom-to-bedroom doors out of the plan, and guarantees that every
      non-root room has a route back to the entrance.
    * Exactly one exterior door is cut, on the longest exterior edge of the
      hallway (fallback: living room, then any room with an exterior edge).
    * One window on the longest exterior edge of every room, removing three
      middle courses and keeping a sill/lintel.
    * Duplicate cells (corner cases) are filtered; small edges are skipped.
    """
    edges = _room_edges(rooms)
    openings: list[dict] = []

    def shared(room_idx: int, e: dict) -> bool:
        return any(
            o["room"] != room_idx and o["axis"] == e["axis"]
            and abs(o["at"] - e["at"]) <= 2.0
            and _overlap(e["a"], e["b"], o["a"], o["b"]) > 0
            for o in edges)

    def exterior_edges(room_idx: int) -> list[dict]:
        return [e for e in edges if e["room"] == room_idx and not shared(room_idx, e)]

    # one candidate per room pair, on the longest shared interval (avoids short
    # corner overlaps becoming the only door)
    best: dict[tuple[int, int], dict] = {}
    for e in edges:
        if e["axis"] == "h" and e["side"] == "S":
            continue
        if e["axis"] == "v" and e["side"] == "E":
            continue
        for o in edges:
            if o["room"] == e["room"] or o["axis"] != e["axis"]:
                continue
            if abs(o["at"] - e["at"]) > 2.0:
                continue
            lo, hi = max(e["a"], o["a"]), min(e["b"], o["b"])
            length = hi - lo
            # A shared edge shorter than the door itself is only a corner
            # touch; it must not win over a real wall just because it touches
            # the hallway/living room.
            if length < door_width * LDU:
                continue
            pair = tuple(sorted((e["room"], o["room"])))
            cur = best.get(pair)
            if cur is None or length > cur["length"]:
                best[pair] = {"pair": pair, "axis": e["axis"],
                              "at": (e["at"] + o["at"]) / 2,
                              "a": lo, "b": hi, "length": length}

    # Prim forest: grow a tree from the hallway/living room, then (only for a
    # genuinely disconnected input layout) start another component so every
    # connected room still gets a door.  The layout QA reports the remaining
    # disconnect instead of silently leaving a doorless room.
    candidates = list(best.values())
    chosen: list[dict] = []
    remaining = set(range(len(rooms)))
    while remaining and candidates:
        root = None
        for preferred in ("hallway", "living"):
            root = next((i for i in sorted(remaining)
                         if rooms[i].get("room_type") == preferred
                         and any(i in c["pair"] for c in candidates)), None)
            if root is not None:
                break
        if root is None:
            root = next((i for i in sorted(remaining)
                         if any(i in c["pair"] for c in candidates)), None)
        if root is None:
            break
        visited = {root}
        remaining.discard(root)
        while True:
            frontier = [c for c in candidates
                        if (c["pair"][0] in visited) != (c["pair"][1] in visited)]
            if not frontier:
                break
            pick = min(frontier, key=lambda c: (_door_priority(rooms, c["pair"]),
                                                -c["length"], c["pair"]))
            chosen.append(pick)
            visited.update(pick["pair"])
        remaining -= visited
    # Doors are 8 courses (1.92 m) in a 10-course wall, leaving a two-course
    # lintel; the five-course cutaway keeps its full-height 1.2 m opening.
    door_courses = min(max(1, courses), 8) if courses >= 8 else max(1, courses)
    for info in sorted(chosen, key=lambda c: c["pair"]):
        cells = _opening_cells(info["axis"], info["at"], info["a"], info["b"], door_width)
        if cells:
            openings.append({"kind": "door", "axis": info["axis"], "at": round(info["at"], 1),
                             "rooms": list(info["pair"]), "cells": cells,
                             "courses": list(range(1, door_courses + 1)),
                             "connection": _door_priority(rooms, info["pair"])})

    # Exactly one exterior entrance.  Prefer the distribution spine, but do
    # not invent a second exterior door if it has no outside wall.
    entry = None
    entry_edge = None
    for preferred in ("hallway", "living"):
        idx = next((i for i, r in enumerate(rooms) if r.get("room_type") == preferred), None)
        if idx is not None and exterior_edges(idx):
            entry = idx
            break
    if entry is None:
        for idx in range(len(rooms)):
            if exterior_edges(idx):
                entry = idx
                break
    if entry is not None:
        ext = exterior_edges(entry)
        if ext:
            e = max(ext, key=lambda x: abs(x["b"] - x["a"]))
            cells = _opening_cells(e["axis"], e["at"], e["a"], e["b"], door_width)
            if cells:
                entry_edge = (entry, e["axis"], round(e["at"], 1))
                openings.append({"kind": "door", "axis": e["axis"], "at": round(e["at"], 1),
                                 "rooms": [entry], "cells": cells,
                                 "courses": list(range(1, door_courses + 1)),
                                 "connection": -1, "entrance": True})

    # windows: longest exterior edge per room (one per room), preferring a
    # different edge from the main entrance
    window_course_list = window_courses(courses)
    for idx, _r in enumerate(rooms):
        ext = exterior_edges(idx)
        if not ext:
            continue
        if entry_edge and entry_edge[0] == idx and len(ext) > 1:
            ext = [e for e in ext if (e["axis"], round(e["at"], 1)) != entry_edge[1:]]
        if not ext:
            continue
        e = max(ext, key=lambda x: abs(x["b"] - x["a"]))
        cells = _opening_cells(e["axis"], e["at"], e["a"], e["b"], window_width)
        if cells:
            openings.append({"kind": "window", "axis": e["axis"], "at": round(e["at"], 1),
                             "rooms": [idx], "cells": cells,
                             "courses": window_course_list})
    # a cell may be claimed by two openings at a corner; keep the first
    used: set[tuple[int, int]] = set()
    out = []
    for op in openings:
        cells = [c for c in op["cells"] if c not in used]
        if len(cells) < 2:
            continue
        used.update(cells)
        op = dict(op)
        op["cells"] = cells
        out.append(op)
    return out


def _window_cells(axis: str, at: float, start: int, width: int) -> list[tuple[int, int]]:
    """Window cells from an explicit along-wall start cell."""
    if axis == "h":
        j = _cell_index(at)
        return [(i, j) for i in range(start, start + width)]
    i = _cell_index(at)
    return [(i, j) for j in range(start, start + width)]


def reposition_windows(rooms: list[dict], openings: list[dict],
                       placed: list[dict], min_height_m: float = 0.9) -> tuple[list[dict], list[dict]]:
    """Slide each window away from tall furniture on the same exterior wall.

    ``wall_openings`` places a window at the centre of the longest exterior
    edge before furniture exists.  A tall wardrobe, bookshelf or fridge can
    then end up directly in front of it.  This pass keeps the same edge but
    moves the four-cell window to the nearest free interval.  It never moves
    doors, and it leaves a window in place when the whole edge is obstructed
    (the placement record reports ``obstructed`` windows separately).
    """
    doors = [op for op in openings if op.get("kind") == "door"]
    door_cells = {tuple(c) for op in doors for c in (op.get("cells") or [])}
    moves: list[dict] = []
    out: list[dict] = []
    min_height_ldu = float(min_height_m) * 100.0
    for op in openings:
        if op.get("kind") != "window":
            out.append(op)
            continue
        axis, at = op.get("axis"), float(op.get("at", 0.0))
        cells = [tuple(c) for c in (op.get("cells") or [])]
        if not cells:
            out.append(op)
            continue
        rid = (op.get("rooms") or [None])[0]
        room = rooms[rid] if rid is not None and 0 <= rid < len(rooms) else None
        if room is None:
            out.append(op)
            continue
        # Along-wall cell range and the current window start.
        if axis == "h":
            i0, i1 = _cell_index(room["x0"]), _cell_end(room["x1"])
            cur_start = min(c[0] for c in cells)
        else:
            i0, i1 = _cell_index(room["z0"]), _cell_end(room["z1"])
            cur_start = min(c[1] for c in cells)
        width = len(cells)
        lo, hi = i0 + 1, i1 - width  # one-cell corner margin, as in wall_openings
        if hi < lo:
            out.append(op)
            continue
        blocked: set[int] = set()
        # Door cells on the same wall line.
        for c in door_cells:
            if axis == "h" and c[1] == _cell_index(at):
                blocked.add(c[0])
            elif axis == "v" and c[0] == _cell_index(at):
                blocked.add(c[1])
        # Tall furniture whose back is against this wall: block its interval.
        for p in placed:
            if p.get("rid") != rid:
                continue
            item = p.get("item") or {}
            sy = (item.get("size_studs") or [0, 0, 0])[1]
            if sy * LDU < min_height_ldu:
                continue
            foot = p.get("foot") or {}
            if axis == "h":
                near = abs(foot.get("z0", 1e9) - at) <= LDU or abs(foot.get("z1", 1e9) - at) <= LDU
                if near:
                    a, b = _cell_index(foot["x0"]), _cell_end(foot["x1"])
                    blocked.update(range(a, b + 1))
            else:
                near = abs(foot.get("x0", 1e9) - at) <= LDU or abs(foot.get("x1", 1e9) - at) <= LDU
                if near:
                    a, b = _cell_index(foot["z0"]), _cell_end(foot["z1"])
                    blocked.update(range(a, b + 1))
        candidates = [s for s in range(lo, hi + 1)
                      if not any(i in blocked for i in range(s, s + width))
                      and not any(tuple(c) in door_cells for c in _window_cells(axis, at, s, width))]
        if not candidates:
            op = dict(op)
            op["obstructed"] = True
            out.append(op)
            continue
        best = min(candidates, key=lambda s: (abs(s - cur_start), s))
        if best == cur_start:
            out.append(op)
            continue
        new = dict(op)
        new["cells"] = _window_cells(axis, at, best, width)
        new["repositioned_from"] = cells
        out.append(new)
        moves.append({"room": rid, "axis": axis, "at": at,
                      "from_cells": cells, "to_cells": new["cells"]})
    return out, moves


def door_clearance_zones(rooms: list[dict], openings: list[dict],
                         depth_ldu: float = 20.0) -> dict[int, list[dict]]:
    """Reserve a furniture-free approach zone on both sides of every door.

    ``depth_ldu`` is one stud (0.2 m) into the room.  The zone spans the door
    cells plus one cell of tolerance; it is clipped to the room rectangle.
    """
    zones: dict[int, list[dict]] = {r["rid"]: [] for r in rooms}
    for op in openings:
        if op.get("kind") != "door":
            continue
        cells = [tuple(c) for c in op.get("cells") or []]
        if not cells:
            continue
        for rid in op.get("rooms") or []:
            room = rooms[rid]
            if op["axis"] == "h":
                x0 = min(c[0] for c in cells) * LDU - LDU
                x1 = (max(c[0] for c in cells) + 1) * LDU + LDU
                z = float(op["at"])
                if room["z1"] <= z + 2:
                    rect = {"x0": x0, "z0": z - depth_ldu, "x1": x1, "z1": z}
                elif room["z0"] >= z - 2:
                    rect = {"x0": x0, "z0": z, "x1": x1, "z1": z + depth_ldu}
                else:
                    continue
            else:
                z0 = min(c[1] for c in cells) * LDU - LDU
                z1 = (max(c[1] for c in cells) + 1) * LDU + LDU
                x = float(op["at"])
                if room["x1"] <= x + 2:
                    rect = {"x0": x - depth_ldu, "z0": z0, "x1": x, "z1": z1}
                elif room["x0"] >= x - 2:
                    rect = {"x0": x, "z0": z0, "x1": x + depth_ldu, "z1": z1}
                else:
                    continue
            rect["x0"] = max(rect["x0"], room["x0"])
            rect["z0"] = max(rect["z0"], room["z0"])
            rect["x1"] = min(rect["x1"], room["x1"])
            rect["z1"] = min(rect["z1"], room["z1"])
            if rect["x1"] > rect["x0"] and rect["z1"] > rect["z0"]:
                zones[rid].append(rect)
    return zones


def _cell_rect(i: int, j: int) -> dict:
    return {"x0": i * LDU, "z0": j * LDU, "x1": (i + 1) * LDU, "z1": (j + 1) * LDU}


def _rect_overlap(a: dict, b: dict) -> float:
    ox = min(a["x1"], b["x1"]) - max(a["x0"], b["x0"])
    oz = min(a["z1"], b["z1"]) - max(a["z0"], b["z0"])
    return max(0.0, ox) * max(0.0, oz)


def _approach_cells(room: dict, op: dict, steps: int = 2) -> list[tuple[int, int]]:
    """Cells just inside ``room`` for a door, up to ``steps`` studs deep."""
    out: list[tuple[int, int]] = []
    at = float(op.get("at", 0.0))
    axis = op.get("axis")
    if axis == "h":
        above = room["z1"] <= at + 2
        below = room["z0"] >= at - 2
        if not (above or below):
            return out
        wall_row = _cell_index(at)
        for ci, _cj in op.get("cells") or []:
            for k in range(1, steps + 1):
                j = wall_row - k if above else wall_row + k
                if room["z0"] <= j * LDU < room["z1"]:
                    out.append((ci, j))
    elif axis == "v":
        left = room["x1"] <= at + 2
        right = room["x0"] >= at - 2
        if not (left or right):
            return out
        wall_col = _cell_index(at)
        for _ci, cj in op.get("cells") or []:
            for k in range(1, steps + 1):
                i = wall_col - k if left else wall_col + k
                if room["x0"] <= i * LDU < room["x1"]:
                    out.append((i, cj))
    return out


def _approach_free(room: dict, op: dict, placed: list[dict]) -> bool:
    """True when the first two studs inside ``room`` are clear of furniture."""
    cells = _approach_cells(room, op, steps=2)
    if not cells:
        return False
    feet = [p.get("foot") for p in placed if p.get("rid") == room["rid"]]
    feet = [f for f in feet if isinstance(f, dict)]
    for i, j in cells:
        c = _cell_rect(i, j)
        if any(_rect_overlap(c, f) > 1e-6 for f in feet):
            return False
    return True


def _edge_interval(rooms: list[dict], op: dict) -> tuple[float, float] | None:
    """Along-wall interval shared by the door's rooms (or the single room)."""
    at = float(op.get("at", 0.0))
    axis = op.get("axis")
    edges = _room_edges(rooms)
    spans = []
    for rid in op.get("rooms") or []:
        for e in edges:
            if e["room"] == rid and e["axis"] == axis and abs(e["at"] - at) <= 2:
                spans.append((e["a"], e["b"]))
    if not spans:
        return None
    lo = max(a for a, _ in spans)
    hi = min(b for _, b in spans)
    return (lo, hi) if hi > lo else None


def fix_bathroom_doors(rooms: list[dict], openings: list[dict], placed: list[dict],
                       max_shift_cells: int = 12,
                       bath_rids: set[int] | None = None) -> tuple[list[dict], list[dict], list[dict]]:
    """Slide blocked bathroom doors after furniture placement.

    A bathroom door is considered blocked when the bathroom side has
    furniture in the first two studs of its approach.  We try to slide the
    opening along the shared wall; if no free position exists the door is kept
    (marked ``obstructed``) rather than removed, so a bathroom never loses all
    of its doors.  Non-bathroom doors are left untouched.
    """
    bath_rids = bath_rids if bath_rids is not None else {
        r["rid"] for r in rooms if r.get("room_type") == "bathroom"}
    if not bath_rids:
        return openings, [], []
    doors = [op for op in openings if op.get("kind") == "door"]
    moves: list[dict] = []
    removed: list[dict] = []
    removed_ids: set[int] = set()
    out: list[dict] = []
    for op in openings:
        if op.get("kind") != "door" or not (set(op.get("rooms") or []) & bath_rids):
            out.append(op)
            continue
        other_door_cells = {tuple(c) for o in doors if o is not op for c in (o.get("cells") or [])}
        rids = [r for r in (op.get("rooms") or []) if 0 <= r < len(rooms)]
        bath_in_op = [r for r in rids if r in bath_rids]
        if not bath_in_op:
            out.append(op)
            continue
        if all(_approach_free(rooms[r], op, placed) for r in bath_in_op):
            out.append(op)
            continue
        axis, at = op["axis"], float(op["at"])
        cells = [tuple(c) for c in (op.get("cells") or [])]
        width = len(cells)
        span = _edge_interval(rooms, op)
        best = None
        if span and width:
            lo, hi = span
            i0, i1 = _cell_index(lo), _cell_end(hi)
            cur = min((c[0] if axis == "h" else c[1]) for c in cells)
            starts = [s for s in range(max(i0 + 1, cur - max_shift_cells),
                                       min(i1 - width, cur + max_shift_cells) + 1)]
            for s in starts:
                cand_cells = _window_cells(axis, at, s, width)
                if any(tuple(c) in other_door_cells for c in cand_cells):
                    continue
                cand = dict(op)
                cand["cells"] = cand_cells
                if all(_approach_free(rooms[r], cand, placed) for r in bath_in_op):
                    best = (s, cand)
                    break
        if best is not None:
            _, cand = best
            cand["repositioned_from"] = cells
            out.append(cand)
            moves.append({"rooms": op.get("rooms"), "axis": axis, "at": at,
                          "from_cells": cells, "to_cells": cand["cells"]})
            continue
        # No free slide: drop this door only when the same bathroom has
        # another door with a free approach, otherwise keep it.
        bath_room = next((r for r in bath_in_op), None)
        if bath_room is not None:
            other_free = any(
                o is not op and id(o) not in removed_ids
                and o.get("kind") == "door" and bath_room in (o.get("rooms") or [])
                and _approach_free(rooms[bath_room], o, placed)
                for o in openings)
            if other_free:
                removed.append({"rooms": op.get("rooms"), "axis": axis, "at": at, "cells": cells})
                removed_ids.add(id(op))
                continue
        op = dict(op)
        op["obstructed"] = True
        out.append(op)
    return out, moves, removed


def _scale_y(matrix: str, sy: float) -> str:
    """Scale an LDraw matrix along Y (part height), preserving its yaw."""
    vals = matrix.split()
    vals[4] = f"{sy:.4f}"
    return " ".join(vals)


def opening_parts(openings: list[dict], courses: int = WALL_COURSES) -> list[dict]:
    """Return LDraw parts for doors, door-frame posts and window frames/glass.

    Door leaves are 1x4x5 (``3861a``).  With the five-course product walls
    that is a full-height 1.2 m door; with taller presentation walls
    (``courses > 5``) the leaf is scaled vertically to the wall height, so the
    door reads as a normal ~2 m door instead of a half-height panel.  Windows
    keep their 1x4x3 frame and are placed at the sill band returned by
    :func:`window_courses`.
    """
    courses = max(1, int(courses))
    win_start = (window_courses(courses) or [2])[0]
    window_mid_y = -((win_start - 1) * 24.0 + 36.0)
    parts: list[dict] = []
    for op in openings or []:
        cells = [tuple(c) for c in op.get("cells") or []]
        if not cells:
            continue
        axis = op.get("axis")
        at = float(op.get("at") or 0)
        lo = min(c[0] for c in cells); hi = max(c[0] for c in cells) if axis == "h" else 0
        lz = min(c[1] for c in cells); hz = max(c[1] for c in cells) if axis == "v" else 0
        if axis == "h":
            j = _cell_index(at)
            cx = (lo + hi + 1) * LDU / 2
            cz = j * LDU + LDU / 2
            m = MATRIX_V
        else:
            i = _cell_index(at)
            cx = i * LDU + LDU / 2
            cz = (lz + hz + 1) * LDU / 2
            m = MATRIX_H
        if op.get("kind") == "door":
            # 1x4x5 door leaf with four panes and a built-in border; the wall
            # opening itself provides the reveal.  The leaf is scaled to the
            # opening (8 courses = 1.92 m in tall-wall mode).
            door_span = max(op.get("courses") or [courses])
            door_scale = door_span / WALL_COURSES
            door_mid_y = -door_span * 12.0
            parts.append({"part": DOOR_PART, "color": DOOR_COLOR,
                          "center_ldu": [round(cx, 1), round(door_mid_y, 1), round(cz, 1)],
                          "matrix": _scale_y(m, door_scale), "kind": "door_leaf"})
        else:
            parts.append({"part": WINDOW_FRAME_PART, "color": FRAME_COLOR,
                          "center_ldu": [round(cx, 1), round(window_mid_y, 1), round(cz, 1)],
                          "matrix": m, "kind": "window_frame"})
            parts.append({"part": WINDOW_GLASS_PART, "color": WINDOW_GLASS_COLOR,
                          "center_ldu": [round(cx, 1), round(window_mid_y, 1), round(cz, 1)],
                          "matrix": m, "kind": "window_glass"})
    return parts


def wall_bricks(rooms: list[dict], openings: list[dict] | None = None,
                courses: int = WALL_COURSES, color: int = WALL_COLOR) -> list[dict]:
    """Return every wall brick for ``courses`` courses, minus openings."""
    cells = wall_cells(rooms)
    if not cells:
        return []
    if openings is None:
        openings = []
    courses = max(1, int(courses))
    blocked: dict[int, set[tuple[int, int]]] = {c: set() for c in range(1, courses + 1)}
    for op in openings:
        for course in op.get("courses") or []:
            if course in blocked:
                blocked[course].update(tuple(c) for c in op.get("cells") or [])
    shared = {c for c, f in cells.items() if f["h"] and f["v"]}
    h_cells = {c for c, f in cells.items() if f["h"]}
    v_cells = {c for c, f in cells.items() if f["v"]}

    bricks: list[dict] = []
    for course in range(1, courses + 1):
        if course % 2 == 0:       # even course: horizontal owns shared cells
            owned_h, owned_v = h_cells, v_cells - shared
        else:                     # odd course: vertical owns shared cells
            owned_h, owned_v = h_cells - shared, v_cells
        owned_h = owned_h - blocked[course]
        owned_v = owned_v - blocked[course]
        run_no = 0
        for axis, owned, yaw in (("h", owned_h, 0), ("v", owned_v, 90)):
            for run in _runs(owned, axis):
                phase = (course - 1 + run_no) % len(STARTS)
                pos = 0
                for length in pack_run(len(run), phase):
                    piece = run[pos:pos + length]
                    if len(piece) != length:
                        raise AssertionError("wall packing produced a short brick")
                    bricks.append(_make_brick(piece, course, yaw, color))
                    pos += length
                if pos != len(run):
                    raise AssertionError("wall packing did not cover the run")
                run_no += 1
    _assert_coverage(cells, bricks, blocked, courses)
    return bricks


def _assert_coverage(cells: dict, bricks: list[dict],
                     blocked: dict[int, set[tuple[int, int]]] | None = None,
                     courses: int = WALL_COURSES) -> None:
    """Every non-opening cell exactly once per course; the cell set is course-invariant."""
    blocked = blocked or {}
    for course in range(1, courses + 1):
        want = set(cells) - blocked.get(course, set())
        seen = set()
        for b in bricks:
            if b["course"] != course:
                continue
            for c in b["cells"]:
                key = (c[0], c[1])
                if key in seen:
                    raise AssertionError(f"course {course}: cell {key} covered twice")
                seen.add(key)
        if seen != want:
            missing = sorted(want - seen)[:6]
            extra = sorted(seen - want)[:6]
            raise AssertionError(f"course {course}: coverage mismatch "
                                 f"missing={missing} extra={extra}")


def wall_summary(bricks: list[dict], openings: list[dict] | None = None,
                 opening_part_count: int = 0, courses: int = WALL_COURSES,
                 color: int = WALL_COLOR) -> dict:
    openings = openings or []
    courses = max(1, int(courses))
    return {
        "courses": courses,
        "height_ldu": courses * 24,
        "height_m": round(courses * 0.24, 2),
        "thickness_ldu": WALL_THICKNESS_LDU,
        "color": color,
        "brick_count": len(bricks),
        "opening_count": len(openings),
        "door_count": sum(1 for o in openings if o.get("kind") == "door"),
        "window_count": sum(1 for o in openings if o.get("kind") == "window"),
        "exterior_door_count": sum(1 for o in openings
                                   if o.get("kind") == "door" and len(o.get("rooms") or []) == 1),
        "door_height_m": round(max((max(o.get("courses") or [0]) for o in openings
                                    if o.get("kind") == "door"), default=0) * 0.24, 2),
        "opening_part_count": opening_part_count,
    }


def _footprint(entry: dict) -> tuple[float, float, float, float] | None:
    foot = entry.get("foot")
    if isinstance(foot, dict):
        return (foot["x0"], foot["z0"], foot["x1"], foot["z1"])
    box = entry.get("foot_ldu")
    if isinstance(box, (list, tuple)) and len(box) == 4:
        return tuple(float(v) for v in box)
    return None


def check_wall_furniture(wall_bricks_list: list[dict], placements: list[dict]) -> list[dict]:
    """Strict AABB intersections between wall bricks and furniture footprints.

    Touching faces (zero area) are not an overlap; ``EPS_OVERLAP`` absorbs
    floating-point contact noise.  With the 20-LDU furniture margin the
    expected result is an empty list.
    """
    out = []
    for wi, wall in enumerate(wall_bricks_list):
        wx0, wz0, wx1, wz1 = (float(v) for v in wall["aabb_ldu"])
        for p in placements:
            foot = _footprint(p)
            if foot is None:
                continue
            fx0, fz0, fx1, fz1 = foot
            ox = min(wx1, fx1) - max(wx0, fx0)
            oz = min(wz1, fz1) - max(wz0, fz0)
            if ox > EPS_OVERLAP and oz > EPS_OVERLAP:
                out.append({
                    "wall_no": wall.get("no", wi + 1),
                    "wall_part": wall["part"],
                    "furniture_no": p.get("no", p.get("index")),
                    "furniture_id": p.get("library_id", p.get("item", {}).get("id")),
                    "overlap_ldu": [round(ox, 1), round(oz, 1)],
                })
    return out


def mpd_line(brick: dict) -> str:
    x, y, z = brick["center_ldu"]
    return (f"1 {brick['color']} {x:.4f} {y:.4f} {z:.4f} "
            f"{brick['matrix']} {brick['part']}.dat")
