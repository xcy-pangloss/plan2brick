/* Plan2Brick local workbench: room editor + brief -> K diverse LDraw candidates. */
"use strict";

const TYPE_LABELS = {
  living: "Living room", dining: "Dining", bedroom: "Bedroom", kitchen: "Kitchen",
  bathroom: "Bathroom", study: "Study", hallway: "Hallway", balcony: "Balcony",
};
const PRESET_LABELS = { studio: "Studio", "1br": "1-bedroom", "2br": "2-bedroom", "3br": "3-bedroom" };

const state = { types: [], presets: {}, layouts: {}, planLabels: {}, realPlans: [],
                preset: null, layout: null, data: null, active: 0 };
const $ = (sel) => document.querySelector(sel);
const el = (tag, cls, text) => {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
};

async function fetchJson(url, options = {}, timeoutMs = 180000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
    return data;
  } catch (error) {
    if (error.name === "AbortError") {
      throw new Error(`Request timed out after ${Math.round(timeoutMs / 1000)}s`);
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function setStatus(message, kind = "") {
  const node = $("#status");
  node.className = "status" + (kind ? " " + kind : "");
  node.textContent = message;
}

function setActivePreset(name) {
  state.preset = name;
  if (!name) state.layout = null;
  for (const button of document.querySelectorAll("#presets button")) {
    button.setAttribute("aria-pressed", String(button.dataset.preset === name));
  }
}

function makeTypeSelect(value) {
  const select = el("select");
  select.setAttribute("aria-label", "Room type");
  for (const type of state.types) {
    const option = el("option", "", TYPE_LABELS[type] || type);
    option.value = type;
    select.append(option);
  }
  select.value = value;
  return select;
}

function makeRoomRow(room) {
  const tr = el("tr");

  const nameCell = el("td");
  const name = el("input");
  name.type = "text";
  name.maxLength = 30;
  name.value = room.name_cn;
  name.setAttribute("aria-label", "Room name");
  nameCell.append(name);

  const typeCell = el("td");
  const type = makeTypeSelect(room.room_type);
  typeCell.append(type);

  const widthCell = el("td");
  const width = el("input");
  width.type = "number";
  width.min = "0.8"; width.max = "20"; width.step = "0.1";
  width.value = Number(room.dims_m[0]).toFixed(1);
  width.setAttribute("aria-label", "Room width in metres");
  widthCell.append(width);

  const depthCell = el("td");
  const depth = el("input");
  depth.type = "number";
  depth.min = "0.8"; depth.max = "20"; depth.step = "0.1";
  depth.value = Number(room.dims_m[1]).toFixed(1);
  depth.setAttribute("aria-label", "Room depth in metres");
  depthCell.append(depth);

  const removeCell = el("td");
  const remove = el("button", "remove", "×");
  remove.type = "button";
  remove.title = "Remove room";
  remove.setAttribute("aria-label", "Remove room");
  remove.addEventListener("click", () => {
    tr.remove();
    setActivePreset(null);
  });
  removeCell.append(remove);

  tr.append(nameCell, typeCell, widthCell, depthCell, removeCell);
  return tr;
}

function loadPreset(name) {
  const rooms = state.presets[name];
  if (!rooms) return;
  const body = $("#room-rows");
  body.replaceChildren(...rooms.map(makeRoomRow));
  setActivePreset(name);
  state.layout = state.layouts[name] || null;
  const label = state.planLabels[name] || PRESET_LABELS[name] || name;
  const real = state.realPlans.find((p) => p.id === name);
  const qa = real && real.qa ? (real.qa.ok ? " · layout closed / connected" : " · layout needs review") : "";
  const repair = real && real.repair && real.repair.length
    ? ` · ${real.repair.length} gap repair` : "";
  setStatus(`${label} loaded${qa}${repair} · edit any room, then generate.${warningSuffix(rooms)}`);
}

function addRoom() {
  const body = $("#room-rows");
  const index = body.children.length + 1;
  body.append(makeRoomRow({
    name_cn: `Room ${index}`, room_type: "living", dims_m: [3.6, 3.6],
  }));
  setActivePreset(null);
}

function readRooms() {
  const rooms = [];
  for (const tr of $("#room-rows").children) {
    const [name, type, width, depth] = tr.querySelectorAll("input, select");
    rooms.push({
      name_cn: name.value.trim(),
      room_type: type.value,
      dims_m: [Number(width.value), Number(depth.value)],
    });
  }
  return rooms;
}

function candidateCount() {
  return Number($("#candidate-count").value) || 6;
}

function generateLabel() {
  return `Generate ${candidateCount()} candidates`;
}

async function generate() {
  const rooms = readRooms();
  if (!rooms.length) {
    setStatus("Add at least one room first.", "error");
    return;
  }
  const mode = $("#mode").value;
  const k = candidateCount();
  const style = $("#style").value;
  const palette = $("#palette").value;
  const wallMode = $("#wall-mode").value;
  const wall_courses = wallMode === "standard" ? 5 : 10;
  const wall_color = wallMode === "tall-glass" ? 47 : 71;
  $("#generate").disabled = true;
  $("#generate").textContent = "Generating…";
  setStatus(`Building ${k} candidates from a ${mode} diversity pool, then validating the LDraw scene…`, "busy");
  try {
    const data = await fetchJson("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rooms, brief: $("#brief").value, mode, k, style, palette,
                             wall_courses, wall_color, layout_m: state.layout }),
    }, 180000);
    renderResult(data);
    const shortfall = data.shortfall ? ` · shortfall ${data.shortfall}` : "";
    setStatus(`Done · ${data.candidates.length}/${data.k || k} candidates built and validated${shortfall}.`);
  } catch (error) {
    setStatus(String(error.message || error), "error");
  } finally {
    $("#generate").disabled = false;
    $("#generate").textContent = generateLabel();
  }
}

function fillRooms(rooms) {
  const body = $("#room-rows");
  body.replaceChildren(...rooms.map(makeRoomRow));
  setActivePreset(null);
}

function roomWarnings(rooms) {
  return rooms
    .filter((r) => !["hallway", "balcony"].includes(r.room_type))
    .map((r) => {
      const [w, d] = (r.dims_m || [0, 0]).map(Number);
      const long = Math.max(w, d);
      const short = Math.min(w, d);
      if (!short || long / short > 2.2 || short < 1.8) {
        return `${r.name_cn} ${w.toFixed(1)}×${d.toFixed(1)} m`;
      }
      return "";
    })
    .filter(Boolean);
}

function warningSuffix(rooms) {
  const bad = roomWarnings(rooms);
  return bad.length ? ` · narrow rooms: ${bad.join(", ")}` : "";
}

function setInputMode(mode) {
  $("#preset-block").hidden = mode !== "preset";
  $("#upload-block").hidden = mode !== "upload";
  $("#rooms-block").hidden = mode !== "rooms";
  if (mode === "preset") {
    setStatus("Pick a preset or edit the rooms, then generate.");
  } else if (mode === "upload") {
    setStatus("Upload a floor plan, then choose Read plan.");
  } else {
    setStatus("Choose a room count, then Generate layout.");
  }
}

async function readPlan() {
  const file = $("#plan-file").files && $("#plan-file").files[0];
  if (!file) {
    setStatus("Choose an image first.", "error");
    return;
  }
  if (file.size > 9 * 1024 * 1024) {
    setStatus("Image is larger than 9 MB; please downscale it.", "error");
    return;
  }
  setStatus("Reading the floor plan with a vision model…", "busy");
  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error("could not read file"));
    reader.readAsDataURL(file);
  });
  try {
    const data = await fetchJson("/api/perceive", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        image_b64: dataUrl,
        has_furniture: $("#has-furniture").checked,
        model: ($("#vision-model") && $("#vision-model").value) || "claude",
      }),
    }, 150000);
    fillRooms(data.rooms || []);
    const notes = data.uncertain && data.uncertain.length ? ` · ${data.uncertain.length} uncertain note(s)` : "";
    setStatus(`Read ${data.rooms.length} rooms with ${data.model}${notes}.${warningSuffix(data.rooms || [])} Check dimensions, then generate.`);
  } catch (error) {
    setStatus(String(error.message || error), "error");
  }
}

async function makeLayout() {
  setStatus("Generating a compact layout…", "busy");
  try {
    const response = await fetch("/api/generate-layout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rooms: Number($("#room-count").value) || 4 }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
    fillRooms(data.rooms || []);
    const corridor = data.corridor ? " with a central corridor" : "";
    setStatus(`Generated ${data.rooms.length} rooms${corridor}; edit if needed, then generate.${warningSuffix(data.rooms || [])}`);
  } catch (error) {
    setStatus(String(error.message || error), "error");
  }
}

function renderBriefReport(data) {
  const box = $("#brief-report");
  box.replaceChildren();
  box.hidden = false;
  box.append(el("strong", "", "Brief report"));
  const actions = data.briefActions || [];
  const unmatched = data.briefUnmatched || [];
  if (actions.length) {
    const list = el("ul");
    for (const action of actions) {
      const detail = action.added || action.removed || action.room_type || action.style
        || action.category || "";
      list.append(el("li", "", `${action.action}${action.room ? " · " + action.room : ""}${detail ? " · " + detail : ""}`));
    }
    box.append(list);
  } else if (!unmatched.length) {
    box.append(el("p", "hint", "No brief actions; the plan program was used unchanged."));
  }
  if (unmatched.length) {
    const list = el("ul", "unmatched");
    for (const clause of unmatched) list.append(el("li", "", `not understood: “${clause}”`));
    box.append(list);
  }
  if (data.aggregate && data.aggregate.pairwise) {
    const agg = data.aggregate;
    box.append(el("p", "hint",
      `Selection · ${data.candidates.length}/${data.k || "?"} candidates · mean pairwise `
      + `distance ${Number(agg.pairwise.distance.mean).toFixed(3)} · coverage `
      + `${Number(agg.coverage_mean).toFixed(3)} · room coverage `
      + `${Number(agg.room_coverage_mean).toFixed(3)}`));
  }
  if (data.shortfall) {
    box.append(el("p", "hint", `Shortfall: ${data.shortfall} valid candidate(s) short of K; `
      + "the pool was not padded with duplicates."));
  }
  const links = el("p", "hint");
  if (data.diversityReport && safeUrl(data.diversityReport)) {
    const a = el("a", "", "Diversity report");
    a.href = data.diversityReport;
    a.target = "_blank";
    a.rel = "noopener";
    links.append(a);
  }
  if (data.diversityGallery && safeUrl(data.diversityGallery)) {
    if (links.childNodes.length) links.append(document.createTextNode(" · "));
    const a = el("a", "", "Diversity gallery");
    a.href = data.diversityGallery;
    a.target = "_blank";
    a.rel = "noopener";
    links.append(a);
  }
  if (links.childNodes.length) box.append(links);
}

function renderResult(data) {
  state.data = data;
  state.active = 0;
  state.candidates = data.candidates;
  $("#empty-state").hidden = true;
  $("#result").hidden = false;
  const eyebrow = $("#result-eyebrow");
  if (eyebrow) {
    eyebrow.textContent = data.mode === "creative"
      ? `Rearranged shell · ${data.candidates.length} diverse candidates`
      : `Same shell · ${data.candidates.length} diverse furnishing schemes`;
  }
  const badge = $("#job-badge");
  badge.hidden = false;
  badge.textContent = `job ${data.job}`;
  renderBriefReport(data);

  const tabs = $("#cand-tabs");
  tabs.replaceChildren();
  data.candidates.forEach((candidate, index) => {
    const button = el("button");
    button.type = "button";
    button.setAttribute("role", "tab");
    const thumb = el("img");
    thumb.className = "candidate-thumb";
    thumb.src = safeUrl(candidate.urls.planSvg);
    thumb.alt = `Plan preview for candidate ${candidate.label}`;
    button.append(thumb);
    button.append(el("strong", "", candidate.label));
    button.append(document.createTextNode(
      `${candidate.style || "mixed"} · ${candidate.totalParts} parts`));
    button.addEventListener("click", () => selectCandidate(index));
    tabs.append(button);
  });
  selectCandidate(0);
}

function safeUrl(url) {
  if (typeof url !== "string" || !url.startsWith("/out/workbench/")) return null;
  return url;
}

function selectCandidate(index) {
  const data = state.data;
  const candidate = data && data.candidates[index];
  if (!candidate) return;
  state.active = index;

  for (const [i, button] of [...$("#cand-tabs").children].entries()) {
    button.setAttribute("aria-selected", String(i === index));
    button.tabIndex = i === index ? 0 : -1;
  }

  const ldr = safeUrl(candidate.urls.ldr);
  const player = ldr
    ? `player.html?model=${encodeURIComponent(ldr)}&parts=${candidate.bomParts}&at=end&theme=light`
    : "about:blank";
  $("#viewer").src = player;
  $("#viewer-open").href = player;
  $("#viewer-caption").textContent =
    `${candidate.name} · ${candidate.style || "mixed"}/${candidate.palette || "mixed"} · ${candidate.totalParts} parts · LEGO walls included`;
  const wallHeight = Number(candidate.wallHeightM || 1.2).toFixed(2);
  const wallDesc = `${candidate.wallCourses || 5} courses · ${wallHeight} m` +
    (candidate.wallColor === 47 ? " · translucent" : "");
  const qa = candidate.layoutQA || {};
  const qaText = qa.ok ? "closed / connected" : `${(qa.hard_issues || []).length} issue(s)`;
  const doorCheck = candidate.doorChecks || {};
  const clipText = `${doorCheck.wall_cell_hits || 0} wall · ${doorCheck.furniture_zone_hits || 0} furniture`;
  const doorHeight = Number(doorCheck.door_height_m || 1.2).toFixed(2);

  const stats = [
    ["Style", `${candidate.style || "mixed"} / ${candidate.palette || "mixed"}`, candidate.wallProfile || ""],
    ["Coverage", `${candidate.placed}/${candidate.requested}`, `${candidate.rooms} rooms`],
    ["Furniture", candidate.furnitureParts, "parts"],
    ["Wall bricks", candidate.wallParts, wallDesc],
    ["Doors / windows", `${candidate.doors || 0} / ${candidate.windows || 0}`,
      `${candidate.exteriorDoors || 0} exterior · ${doorHeight} m · ${clipText} clips`],
    ["Layout", qaText, qa.soft_issues && qa.soft_issues.length ? `${qa.soft_issues.length} warning(s)` : ""],
    ["Total", candidate.totalParts, "MPD parts"],
    ["Overlaps", `${candidate.overlaps + candidate.wallOverlaps}`, "furniture + wall"],
  ];
  const grid = $("#stats");
  grid.replaceChildren();
  for (const [label, value, sub] of stats) {
    const stat = el("dl", "stat");
    stat.append(el("dt", "", label));
    const dd = el("dd", "", String(value));
    if (sub) dd.append(el("small", "", ` ${sub}`));
    stat.append(dd);
    grid.append(stat);
  }

  const plan = $("#plan");
  const planUrl = safeUrl(candidate.urls.planSvg);
  plan.hidden = !planUrl;
  if (planUrl) {
    plan.src = planUrl;
    plan.alt = `Floor plan for candidate ${candidate.label}`;
  }

  const downloads = [
    ["3D model (.ldr)", candidate.urls.ldr],
    ["Scene (.mpd)", candidate.urls.mpd],
    ["BOM (.csv)", candidate.urls.bom],
    ["Placements (.json)", candidate.urls.placements],
    ["IR (.json)", candidate.urls.ir],
  ];
  const box = $("#downloads");
  box.replaceChildren();
  for (const [text, url] of downloads) {
    const safe = safeUrl(url);
    if (!safe) continue;
    const link = el("a", "", text);
    link.href = safe;
    link.download = "";
    box.append(link);
  }
}

async function init() {
  const presets = $("#presets");
  try {
    const response = await fetch("/api/presets", { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    state.types = data.types;
    state.presets = data.presets;
    state.realPlans = data.real_plans || [];
    for (const plan of state.realPlans) {
      state.presets[plan.id] = plan.rooms;
      state.layouts[plan.id] = plan.layout_m;
      state.planLabels[plan.id] = plan.label;
    }
    if (data.library) {
      const badge = $("#library-badge");
      if (badge) {
        badge.textContent = `${data.library.name} · ${data.library.items} items`;
        badge.title = `Furniture library: ${data.library.path}`;
      }
    }
  } catch (error) {
    setStatus("Could not load presets. Start the local server with: python app/serve.py --open-workbench", "error");
    return;
  }

  presets.replaceChildren();
  const presetOrder = ["studio", "1br", "2br", "3br",
                       ...state.realPlans.map((p) => p.id)];
  for (const name of presetOrder) {
    if (!state.presets[name]) continue;
    const button = el("button", "", state.planLabels[name] || PRESET_LABELS[name] || name);
    button.type = "button";
    button.dataset.preset = name;
    button.setAttribute("aria-pressed", "false");
    button.addEventListener("click", () => loadPreset(name));
    presets.append(button);
  }

  $("#add-room").addEventListener("click", addRoom);
  $("#generate").addEventListener("click", generate);
  $("#input-mode").addEventListener("change", (event) => setInputMode(event.target.value));
  $("#read-plan").addEventListener("click", readPlan);
  $("#make-layout").addEventListener("click", makeLayout);
  $("#plan-file").addEventListener("change", () => {
    const file = $("#plan-file").files && $("#plan-file").files[0];
    if (file) {
      $("#plan-preview").src = URL.createObjectURL(file);
      setStatus(`Selected ${file.name}; choose Read plan.`);
    }
  });
  $("#candidate-count").addEventListener("change", () => {
    $("#generate").textContent = generateLabel();
  });
  $("#brief").addEventListener("keydown", (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key === "Enter") generate();
  });
  for (const chip of document.querySelectorAll("[data-brief]")) {
    chip.addEventListener("click", () => {
      $("#brief").value = chip.dataset.brief;
      $("#brief").focus();
    });
  }
  $("#room-rows").addEventListener("input", () => setActivePreset(null));

  setInputMode("preset");
  loadPreset("2br");
}

document.addEventListener("DOMContentLoaded", init);
