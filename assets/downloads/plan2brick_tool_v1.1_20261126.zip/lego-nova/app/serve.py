"""Serve the static showcase with the LDraw library the 3D player needs.

The showcase is plain files, but the optional interactive player resolves parts
from two endpoints, exactly like the original viewer backend:

    /ldraw/<path>      the LDraw library root (parts/, p/, models/)
    /ldraw-id/<name>   parts/<name>, then p/<name>, then models/<name>
                       with X-LDraw-Folder telling the player what it found

Usage (from the lego-nova root):

    python app/serve.py --port 8000 --open

The LDraw root defaults to the local BrickNet library; override with
--ldraw PATH or the LDRAW_DIR environment variable.
"""
from __future__ import annotations

import argparse
import base64
import binascii
import json
import math
import mimetypes
import os
import re
import secrets
import subprocess
import sys
import tempfile
import threading
import webbrowser
from datetime import datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

APP_DIR = Path(__file__).resolve().parent
ROOT = APP_DIR.parent
DEFAULT_LDRAW = Path(r"C:\Users\XCY\Desktop\bricknet\ldraw\ldraw")
DEFAULT_LIBRARY = ROOT.parent / "fyp-pipeline" / "library"
WORKBENCH_LIBRARY = ROOT.parent / "fyp-pipeline" / "library_v1.6_final"
if not WORKBENCH_LIBRARY.exists():
    WORKBENCH_LIBRARY = ROOT.parent / "fyp-pipeline" / "library_v1.5"
LIBRARY = WORKBENCH_LIBRARY if WORKBENCH_LIBRARY.exists() else DEFAULT_LIBRARY
FYP_CHECK = ROOT.parent / "fyp-pipeline" / "check_ir.py"
WORKBENCH_OUT = ROOT / "out" / "workbench"
GENERATE_LOCK = threading.Lock()

sys.path.insert(0, str(ROOT))
from novalib import brief, diversity, floorplan, layout_gen, variants  # noqa: E402

try:  # optional: image perception uses the multi-model transport
    from modelbench.config import load_config as _load_mb_config
    from modelbench.transport import TransportError as _TransportError, call_model as _call_model
except Exception:  # pragma: no cover - package may omit modelbench
    _load_mb_config = None
    _call_model = None
    _TransportError = Exception

ROOM_TYPES = list(floorplan.FURNISH)   # includes "empty" for closets/storage
MAX_ROOMS = 20
MAX_BRIEF = 600
MAX_IMAGE_BYTES = 10 * 1024 * 1024
NAME_BAD = set('<>"\'/\\')

mimetypes.add_type("application/wasm", ".wasm")
mimetypes.add_type("application/json", ".json")
mimetypes.add_type("text/plain", ".dat")
mimetypes.add_type("text/plain", ".ldr")
mimetypes.add_type("text/plain", ".mpd")
mimetypes.add_type("text/markdown", ".md")
mimetypes.add_type("image/png", ".png")
mimetypes.add_type("image/svg+xml", ".svg")

HIDDEN_PREFIXES = ("api/", "files/", "gallery-files/", "demo/", "ref/", "viewer/", "xr/", "assets/")


def _validate_rooms(payload: dict) -> list[dict]:
    """Validate the workbench room editor payload; return normalised rooms."""
    raw = payload.get("rooms")
    if not isinstance(raw, list) or not (1 <= len(raw) <= MAX_ROOMS):
        raise ValueError(f"rooms must be a list of 1-{MAX_ROOMS} entries")
    rooms, seen = [], set()
    for i, r in enumerate(raw):
        if not isinstance(r, dict):
            raise ValueError(f"room {i + 1}: expected an object")
        name = str(r.get("name_cn") or "").strip()
        if not (1 <= len(name) <= 30):
            raise ValueError(f"room {i + 1}: name must be 1-30 characters")
        if any(ch in NAME_BAD or ord(ch) < 32 for ch in name):
            raise ValueError(f"room {i + 1}: name contains an unsupported character")
        if name in seen:
            raise ValueError(f"room {i + 1}: duplicate room name {name!r}")
        seen.add(name)
        rtype = str(r.get("room_type") or "")
        if rtype not in ROOM_TYPES:
            raise ValueError(f"room {i + 1}: room_type must be one of {', '.join(ROOM_TYPES)}")
        dims = r.get("dims_m")
        if not isinstance(dims, list) or len(dims) != 2:
            raise ValueError(f"room {i + 1}: dims_m must be [width, depth]")
        try:
            w, d = float(dims[0]), float(dims[1])
        except (TypeError, ValueError):
            raise ValueError(f"room {i + 1}: dims_m must be numbers") from None
        if not all(math.isfinite(v) and 0.8 <= v <= 20.0 for v in (w, d)):
            raise ValueError(f"room {i + 1}: width and depth must be in 0.8-20 m")
        rooms.append({"name_cn": name, "name_en": rtype, "room_type": rtype,
                      "dims_m": [round(w, 2), round(d, 2)]})
    if not any(floorplan.FURNISH.get(r["room_type"]) for r in rooms):
        raise ValueError("at least one room must have a furniture programme")
    return rooms


def _write_ldr(mpd_path: Path, ldr_path: Path, title: str) -> None:
    """Flatten an MPD into a plain .ldr the LDraw WASM player accepts."""
    body = [ln for ln in mpd_path.read_text(encoding="utf-8").splitlines()
            if ln.startswith("1 ")]
    ldr_path.write_text("\n".join(
        [f"0 {title}", f"0 Name: {ldr_path.name}", "0 Author: Plan2Brick workbench",
         *body, "0"]) + "\n", encoding="utf-8")


def _write_bom(mpd_path: Path, csv_path: Path) -> int:
    counts: dict[tuple[str, str], int] = {}
    for ln in mpd_path.read_text(encoding="utf-8").splitlines():
        if not ln.startswith("1 "):
            continue
        t = ln.split()
        key = (t[-1], t[1])
        counts[key] = counts.get(key, 0) + 1
    rows = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0][0], kv[0][1]))
    lines = ["part,color,count"] + [f"{part},{color},{n}" for (part, color), n in rows]
    csv_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return sum(counts.values())


def _job_url(job: str, path: Path) -> str:
    rel = path.relative_to(WORKBENCH_OUT / job).as_posix()
    return f"/out/workbench/{job}/{rel}"


def run_generate(payload: dict) -> dict:
    """Run the full local Plan2Brick generate flow for edited rooms + a brief.

    Deterministic: floorplan.make_ir -> brief.apply_brief -> check_ir.py ->
    variants.run_diversity (K diverse candidates, fidelity or creative) ->
    .ldr/BOM artifacts.  No model calls and no network.  Raises ValueError for
    user-correctable input errors.
    """
    rooms = _validate_rooms(payload)
    brief_text = payload.get("brief") or ""
    if not isinstance(brief_text, str) or len(brief_text) > MAX_BRIEF:
        raise ValueError(f"brief must be a string of at most {MAX_BRIEF} characters")
    mode = str(payload.get("mode") or "fidelity").strip().lower()
    if mode not in ("fidelity", "creative"):
        raise ValueError("mode must be 'fidelity' or 'creative'")
    try:
        k = int(payload.get("k") or 6)
    except (TypeError, ValueError):
        raise ValueError("k must be an integer from 3 to 9") from None
    if not 3 <= k <= 9:
        raise ValueError("k must be an integer from 3 to 9")
    style = str(payload.get("style") or "mixed").strip().lower()
    if style != "mixed" and style not in diversity.STYLES:
        raise ValueError("style must be mixed or one of " + ", ".join(diversity.STYLES))
    palette = str(payload.get("palette") or "mixed").strip().lower()
    if palette != "mixed" and palette not in diversity.PALETTES:
        raise ValueError("palette must be mixed or one of " + ", ".join(diversity.PALETTES))
    try:
        door_clearance = int(payload.get("door_clearance_ldu") or 40)
    except (TypeError, ValueError):
        raise ValueError("door_clearance_ldu must be an integer") from None
    if door_clearance < 0 or door_clearance > 200:
        raise ValueError("door_clearance_ldu must be 0-200")
    try:
        wall_courses = int(payload.get("wall_courses") or 5)
    except (TypeError, ValueError):
        raise ValueError("wall_courses must be an integer") from None
    if wall_courses < 5 or wall_courses > 12:
        raise ValueError("wall_courses must be 5-12")
    try:
        wall_color = int(payload.get("wall_color") or 71)
    except (TypeError, ValueError):
        raise ValueError("wall_color must be an integer") from None
    if wall_color not in (71, 47):
        raise ValueError("wall_color must be 71 (solid) or 47 (transparent)")
    raw_layout = payload.get("layout_m") or {}
    layout_origins = None
    if raw_layout:
        if not isinstance(raw_layout, dict):
            raise ValueError("layout_m must be an object of room name -> [x, z]")
        candidate = {}
        for r in rooms:
            o = raw_layout.get(r["name_cn"]) or raw_layout.get(r["name_en"])
            if not (isinstance(o, (list, tuple)) and len(o) >= 2):
                candidate = {}
                break
            try:
                x, z = float(o[0]), float(o[1])
            except (TypeError, ValueError):
                candidate = {}
                break
            if abs(x) > 100 or abs(z) > 100:
                candidate = {}
                break
            candidate[r["name_cn"]] = [x, z]
        if len(candidate) != len(rooms):
            raise ValueError("layout_m must give an origin for every room")
        layout_origins = candidate

    with GENERATE_LOCK:
        job = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(4)
        job_dir = WORKBENCH_OUT / job
        (job_dir / "ir").mkdir(parents=True, exist_ok=False)

        total_area = sum(r["dims_m"][0] * r["dims_m"][1] for r in rooms)
        if layout_origins is None:
            max_w = max(max(r["dims_m"][0] for r in rooms), math.sqrt(total_area) * 1.15)
            origins, _score, _bw, _bd = floorplan._shelf_pack(rooms, max_w)
        else:
            origins = layout_origins
        source_ir = floorplan.make_ir(rooms, origins, f"workbench:{job}")
        source_ir.setdefault("_build", {})
        source_ir["_build"].update({"openings": True,
                                    "door_clearance_ldu": door_clearance,
                                    "wall_courses": wall_courses,
                                    "wall_color": wall_color})
        if layout_origins is not None:
            source_ir = floorplan.repair_layout_ir(source_ir)
            layout_qa = floorplan.layout_issues(source_ir.get("rooms") or [],
                                                source_ir.get("layout_m") or {})
            if not layout_qa.get("ok"):
                raise ValueError("layout is not closed: "
                                 + "; ".join(layout_qa.get("hard_issues") or []))
        source_path = job_dir / "ir" / "workbench_source.json"
        source_path.write_text(json.dumps(source_ir, ensure_ascii=False, indent=2),
                               encoding="utf-8")

        applied = brief.apply_brief(source_ir, brief_text)
        briefed_path = job_dir / "ir" / "workbench_briefed.json"
        briefed_path.write_text(json.dumps(applied["ir"], ensure_ascii=False, indent=2),
                                encoding="utf-8")

        check = subprocess.run([sys.executable, str(FYP_CHECK), str(briefed_path)],
                               capture_output=True, text=True, encoding="utf-8")
        if check.returncode != 0:
            raise ValueError("scene IR failed check_ir.py:\n"
                             + (check.stdout or "") + (check.stderr or ""))

        res = variants.run_diversity(briefed_path, n=k, outroot=job_dir,
                                     library=LIBRARY, evaluate=False,
                                     name="workbench", mode=mode, pool=24, seed=0,
                                     styles=None if style == "mixed" else [style],
                                     palettes=None if palette == "mixed" else [palette])

        candidates = []
        for i, row in enumerate(res["candidates"]):
            mpd = Path(row["scene"])
            name = row["name"]
            ldr = mpd.parent / f"{name}.ldr"
            _write_ldr(mpd, ldr, f"Plan2Brick workbench candidate {chr(65 + i)}")
            bom = mpd.parent / f"{name}.bom.csv"
            total = _write_bom(mpd, bom)
            cand_ir = job_dir / "ir" / f"{name}.json"
            pl = json.loads(Path(row["placement_file"]).read_text(encoding="utf-8"))
            ws = pl.get("wall_summary") or {}
            candidates.append({
                "label": chr(65 + i),
                "name": name,
                "coverage": row["coverage"],
                "coverageRatio": row.get("coverage_ratio"),
                "placed": row["placed"],
                "requested": row["requested"],
                "rooms": row["rooms"],
                "furnitureParts": row.get("furniture_parts", row["parts"]),
                "floorParts": row.get("floor_parts", 0),
                "wallParts": row.get("wall_parts", 0),
                "openingParts": pl.get("opening_parts", 0),
                "totalParts": row["parts"],
                "bomParts": total,
                "overlaps": row["overlaps"],
                "wallOverlaps": row.get("wall_furniture_overlaps", 0),
                "dropped": row["dropped"],
                "quality": row.get("quality"),
                "style": row.get("style"),
                "palette": row.get("palette"),
                "wallProfile": row.get("wall_profile"),
                "doors": ws.get("door_count", 0),
                "windows": ws.get("window_count", 0),
                "exteriorDoors": ws.get("exterior_door_count", 0),
                "wallCourses": ws.get("courses", 5),
                "wallColor": ws.get("color", 71),
                "wallHeightM": ws.get("height_m", 1.2),
                "layoutQA": pl.get("layout_qa"),
                "layoutRepair": pl.get("layout_repair") or [],
                "doorChecks": pl.get("door_checks"),
                "urls": {
                    "ldr": _job_url(job, ldr),
                    "mpd": _job_url(job, mpd),
                    "placements": _job_url(job, Path(row["placement_file"])),
                    "bom": _job_url(job, bom),
                    "ir": _job_url(job, cand_ir) if cand_ir.exists() else None,
                    "planSvg": _job_url(job, Path(row["svg"])),
                },
            })

    return {
        "job": job,
        "createdAt": datetime.now().isoformat(timespec="seconds"),
        "brief": brief_text,
        "mode": mode,
        "k": k,
        "style": style,
        "palette": palette,
        "doorClearanceLdu": door_clearance,
        "pool": 24,
        "selection": "qd",
        "shortfall": res.get("shortfall", 0),
        "aggregate": res.get("aggregate"),
        "briefActions": applied["actions"],
        "briefUnmatched": applied["unmatched"],
        "sourceIr": _job_url(job, source_path),
        "briefedIr": _job_url(job, briefed_path),
        "diversityReport": _job_url(job, Path(res["report"])),
        "diversityGallery": _job_url(job, Path(res["gallery"])),
        "candidates": candidates,
    }


def run_generate_layout(payload: dict) -> dict:
    """Generate a compact room programme/layout from a room count."""
    try:
        n = int(payload.get("rooms") or 4)
    except (TypeError, ValueError):
        raise ValueError("rooms must be an integer") from None
    if not 1 <= n <= 10:
        raise ValueError("rooms must be 1-10")
    style = str(payload.get("style") or "mixed").strip().lower()
    ir = layout_gen.make_plan(n, style)
    rooms = [{"name_cn": r["name_cn"], "name_en": r["name_en"],
              "room_type": r["room_type"], "dims_m": list(r["dims_m"])}
             for r in ir["rooms"]]
    return {"rooms": rooms, "layout_m": ir.get("layout_m"),
            "source": ir.get("source"), "style": style,
            "corridor": any(r.get("room_type") == "hallway" for r in rooms)}


def _extract_json(text: str) -> dict:
    text = (text or "").strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.S).strip()
    a, b = text.find("{"), text.rfind("}")
    if a < 0 or b <= a:
        raise ValueError("model did not return a JSON object")
    try:
        obj = json.loads(text[a:b + 1])
    except json.JSONDecodeError as exc:
        raise ValueError(f"model returned invalid JSON: {exc}") from None
    if not isinstance(obj, dict):
        raise ValueError("model JSON is not an object")
    return obj


def run_perceive(payload: dict) -> dict:
    """Image -> scene IR via the configured Claude/GPT vision model."""
    if _load_mb_config is None or _call_model is None:
        raise RuntimeError("modelbench is not installed; image perception is unavailable")
    b64 = str(payload.get("image_b64") or "")
    if b64.startswith("data:") and "," in b64:
        b64 = b64.split(",", 1)[1]
    try:
        raw = base64.b64decode(b64, validate=True)
    except (binascii.Error, ValueError):
        raise ValueError("image_b64 is not valid base64") from None
    if not raw or len(raw) > MAX_IMAGE_BYTES:
        raise ValueError(f"image must be 1-{MAX_IMAGE_BYTES} bytes")
    model_name = str(payload.get("model") or "claude").strip().lower()
    cfg_path = ROOT / "modelbench" / "config.local.json"
    if not cfg_path.exists():
        raise RuntimeError("modelbench config.local.json is missing")
    try:
        cfg = _load_mb_config(cfg_path)
    except Exception as exc:
        raise RuntimeError(f"cannot load modelbench config: {exc}") from exc
    has_furniture = bool(payload.get("has_furniture", False))
    prompt = f"""You are a floorplan parser for a LEGO interior pipeline.
Return ONLY one JSON object, no code fences:
{{"source":"perception","image_type":"floorplan","rooms":[{{"name_cn":"...","name_en":"...","room_type":"living|dining|bedroom|kitchen|bathroom|study|hallway|balcony","dims_m":[width_m,depth_m]}}],"objects":[],"layout_m":{{"room name":[x_m,z_m]}},"uncertain":[],"notes":"..."}}
Rules:
- Read every room from the drawing. Use annotated dimensions (convert mm to m); if unannotated, estimate from scale and note it.
- dims_m = [width E-W, depth N-S] in metres; both positive.
- {'The drawing includes furniture: IGNORE the furniture; only extract room boundaries/names/dimensions.' if has_furniture else 'The drawing is a clean plan; extract rooms/dimensions.'}
- layout_m is optional but useful: approximate each room origin in metres using a consistent coordinate system.
- Use only these room types; do not invent rooms.
"""
    suffix = ".png"
    WORKBENCH_OUT.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix="perceive_", suffix=suffix, dir=WORKBENCH_OUT)
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        tmp.write_bytes(raw)
        try:
            res = _call_model(cfg, model_name, prompt, image_paths=[tmp],
                              temperature=0.0, max_output_tokens=3000)
        except _TransportError as exc:
            raise RuntimeError(f"vision call failed: {exc}") from exc
        ir = _extract_json(res.text)
        ir["image_type"] = "floorplan"
        # normalize/validate the rooms; keep only the fields the workbench uses
        rooms = []
        for r in ir.get("rooms") or []:
            name_cn = str(r.get("name_cn") or r.get("name_en") or "").strip()
            name_en = str(r.get("name_en") or name_cn).strip()
            if not name_cn:
                raise ValueError("model returned a room without a name")
            rtype = str(r.get("room_type") or "").strip().lower()
            if rtype not in ROOM_TYPES:
                rtype = floorplan.infer_room_type(name_en, name_cn)
            dims = r.get("dims_m")
            if not isinstance(dims, list) or len(dims) < 2:
                raise ValueError(f"room {name_cn!r} has no dims_m")
            try:
                w, d = float(dims[0]), float(dims[1])
            except (TypeError, ValueError):
                raise ValueError(f"room {name_cn!r} has invalid dims_m") from None
            if not (0.8 <= w <= 30 and 0.8 <= d <= 30):
                raise ValueError(f"room {name_cn!r} dims outside 0.8-30 m")
            rooms.append({"name_cn": name_cn, "name_en": name_en,
                          "room_type": rtype, "dims_m": [round(w, 2), round(d, 2)]})
        if not rooms:
            raise ValueError("model returned no rooms")
        return {"rooms": rooms, "model": model_name,
                "layout_m": ir.get("layout_m"),
                "uncertain": ir.get("uncertain") or [],
                "notes": ir.get("notes") or ""}
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass


def presets_payload() -> dict:
    presets = {}
    for name, rows in floorplan.PRESETS.items():
        presets[name] = [{"name_cn": n, "name_en": en, "room_type": t,
                          "dims_m": list(dims)} for n, en, t, dims in rows]
    try:
        items = len(json.loads((LIBRARY / "index.json").read_text(encoding="utf-8")))
    except Exception:
        items = 0
    return {"presets": presets, "types": list(ROOM_TYPES),
            "real_plans": real_plan_payload(),
            "library": {"name": LIBRARY.name, "items": items, "path": str(LIBRARY)}}


def real_plan_payload() -> list[dict]:
    """Real transcribed plans with an explicit layout, for the preset picker.

    Only plans carrying ``layout_m`` are listed: a real plan without a
    topology would be silently re-packed and would defeat the point.  The R3
    transcription has a missing corridor; it is repaired here so the loaded
    plan is already closed and connected.
    """
    out = []
    examples = ROOT.parent / "fyp-pipeline" / "examples"
    for plan_id in ("R1", "R2", "R3"):
        path = examples / f"floorplan_{plan_id}_img_flash.json"
        if not path.is_file():
            continue
        ir = json.loads(path.read_text(encoding="utf-8"))
        if not ir.get("layout_m"):
            continue
        ir.setdefault("_build", {})["openings"] = True
        repaired = floorplan.repair_layout_ir(ir)
        rooms = repaired.get("rooms") or []
        layout = repaired.get("layout_m") or {}
        seen = {}
        clean_rooms, clean_layout = [], {}
        for i, r in enumerate(rooms):
            base = str(r.get("name_cn") or r.get("name_en") or f"Room {i}")
            n = seen.get(base, 0) + 1
            seen[base] = n
            name = base if n == 1 else f"{base} {n}"
            clean_rooms.append({
                "name_cn": name,
                "name_en": r.get("name_en") or name,
                "room_type": r.get("room_type") or floorplan.infer_room_type(
                    r.get("name_en"), name),
                "dims_m": list(r.get("dims_m") or [3.0, 3.0]),
            })
            if str(i) in layout:
                clean_layout[name] = list(layout[str(i)])
        qa = floorplan.layout_issues(clean_rooms, clean_layout)
        out.append({
            "id": plan_id,
            "label": f"{plan_id} · {len(clean_rooms)} rooms · {qa['area_m2']:.0f} m²",
            "rooms": clean_rooms,
            "layout_m": clean_layout,
            "area_m2": qa["area_m2"],
            "qa": qa,
            "repair": repaired.get("_layout_repair") or [],
        })
    return out


def resolve_within(root: Path, relative: str) -> Path | None:
    """Resolve a URL path under root, rejecting traversal and hidden paths."""
    relative = relative.replace("\\", "/").lstrip("/")
    if not relative or any(part in ("..", "") for part in relative.split("/")[:-1]):
        return None
    candidate = (root / relative).resolve()
    try:
        candidate.relative_to(root.resolve())
    except ValueError:
        return None
    return candidate if candidate.is_file() else None


class ShowcaseHandler(BaseHTTPRequestHandler):
    server_version = "lego-nova-showcase/1.0"

    # -- helpers ---------------------------------------------------------
    def _send(self, path: Path, *, headers: dict[str, str] | None = None,
              content_type: str | None = None, cache: str = "no-cache") -> None:
        try:
            data = path.read_bytes()
        except OSError:
            self._error(HTTPStatus.NOT_FOUND, "File not found")
            return
        ctype = content_type or mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/json", "application/javascript"):
            ctype += "; charset=utf-8"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", cache)
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def _error(self, status: HTTPStatus, message: str) -> None:
        body = f"{status.value} {status.phrase}\n{message}\n".encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _send_json(self, status: HTTPStatus, obj: dict) -> None:
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _read_json(self, max_bytes: int = 64 * 1024) -> dict:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise ValueError("invalid Content-Length") from None
        if length <= 0 or length > max_bytes:
            raise ValueError(f"request body must be 1-{max_bytes} bytes")
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError("request body must be valid UTF-8 JSON") from None
        if not isinstance(payload, dict):
            raise ValueError("request body must be a JSON object")
        return payload

    def _redirect(self, location: str) -> None:
        self.send_response(HTTPStatus.FOUND)
        self.send_header("Location", location)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _ldraw_id(self, name: str) -> None:
        ldraw: Path = self.server.ldraw_dir  # type: ignore[attr-defined]
        for sub in ("parts", "p", "models"):
            file = resolve_within(ldraw / sub, name)
            if file is not None:
                self._send(file, headers={"X-LDraw-Folder": sub},
                           content_type="text/plain", cache="public, max-age=31536000, immutable")
                return
        self._error(HTTPStatus.NOT_FOUND, f"No LDraw file named {name!r} in parts/, p/ or models/")

    # -- routing ---------------------------------------------------------
    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        path = unquote(parsed.path)

        if path == "/api/presets":
            self._send_json(HTTPStatus.OK, presets_payload())
            return

        if path in ("", "/"):
            self._redirect("/app/")
            return
        if path == "/app":
            self._redirect("/app/")
            return
        if path == "/app/":
            self._send(APP_DIR / "index.html", cache="no-cache")
            return
        if path == "/favicon.ico":
            self._error(HTTPStatus.NOT_FOUND, "No favicon")
            return

        if path.startswith("/ldraw-id/"):
            self._ldraw_id(path[len("/ldraw-id/"):])
            return

        if path.startswith("/ldraw/"):
            ldraw: Path = self.server.ldraw_dir  # type: ignore[attr-defined]
            file = resolve_within(ldraw, path[len("/ldraw/"):])
            if file is None:
                self._error(HTTPStatus.NOT_FOUND, "Not in the LDraw library")
            else:
                self._send(file, cache="public, max-age=31536000, immutable")
            return

        # The showcase itself: /app/* and ../out/* (the browser normalises the
        # latter to /out/*), plus anything else that lives under the repo root.
        relative = path.lstrip("/")
        if relative.startswith(HIDDEN_PREFIXES):
            self._error(HTTPStatus.NOT_FOUND, "Not served")
            return
        file = resolve_within(ROOT, relative)
        if file is None:
            self._error(HTTPStatus.NOT_FOUND, f"No such file: {path}")
        else:
            self._send(file, cache="no-cache")

    def do_POST(self) -> None:  # noqa: N802
        path = unquote(urlparse(self.path).path)
        try:
            if path == "/api/generate":
                payload = self._read_json()
                result = run_generate(payload)
            elif path == "/api/generate-layout":
                payload = self._read_json()
                result = run_generate_layout(payload)
            elif path == "/api/perceive":
                payload = self._read_json(max_bytes=MAX_IMAGE_BYTES + 256 * 1024)
                result = run_perceive(payload)
            else:
                self._error(HTTPStatus.NOT_FOUND,
                            "POST /api/generate, /api/generate-layout or /api/perceive")
                return
        except ValueError as exc:
            self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            return
        except Exception as exc:  # noqa: BLE001 - report, keep the server alive
            sys.stderr.write(f"{path} failed: {type(exc).__name__}: {exc}\n")
            self._send_json(HTTPStatus.INTERNAL_SERVER_ERROR,
                            {"error": f"{type(exc).__name__}: {exc}"})
            return
        self._send_json(HTTPStatus.OK, result)

    def do_HEAD(self) -> None:  # noqa: N802
        self.do_GET()

    def log_message(self, fmt: str, *args) -> None:
        if self.server.quiet:  # type: ignore[attr-defined]
            return
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))


def main() -> int:
    global LIBRARY
    parser = argparse.ArgumentParser(description="Serve the lego-nova gallery-parity showcase.")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--ldraw", default=os.environ.get("LDRAW_DIR", str(DEFAULT_LDRAW)),
                        help="LDraw library root (contains parts/, p/, models/)")
    parser.add_argument("--library", default=None,
                        help="furniture library for generated scenes (default: v1.5 when present)")
    parser.add_argument("--open", action="store_true", help="Open the showcase in the default browser")
    parser.add_argument("--open-workbench", action="store_true",
                        help="Open the interactive Plan2Brick workbench instead of the gallery")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    LIBRARY = Path(args.library).resolve() if args.library else Path(LIBRARY).resolve()
    if not (LIBRARY / "index.json").exists():
        print(f"furniture library not found: {LIBRARY}", file=sys.stderr)
        return 1
    print(f"Furniture library: {LIBRARY}")

    ldraw = Path(args.ldraw)
    if not (ldraw / "parts").is_dir():
        print(f"warning: {ldraw} does not look like an LDraw library (no parts/).", file=sys.stderr)
        print("         The static showcase works; the 3D player will report missing parts.", file=sys.stderr)
    else:
        print(f"LDraw library: {ldraw}")

    try:
        httpd = ThreadingHTTPServer((args.host, args.port), ShowcaseHandler)
    except OSError as exc:
        print(f"Could not listen on {args.host}:{args.port}: {exc}", file=sys.stderr)
        print("Another copy may already be running; try --port 8001.", file=sys.stderr)
        return 1
    httpd.ldraw_dir = ldraw  # type: ignore[attr-defined]
    httpd.quiet = args.quiet  # type: ignore[attr-defined]
    base = f"http://{args.host}:{args.port}"
    url = f"{base}/app/"
    workbench = f"{base}/app/workbench.html"
    print(f"Showcase: {url}")
    print(f"Workbench: {workbench}")
    print("Press Ctrl+C to stop.")
    if args.open_workbench:
        webbrowser.open(workbench)
    elif args.open:
        webbrowser.open(url)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
