# Library v1.6 strict staging

- core v1.5: 340
- v1.6 additions promoted: 16
- review items promoted: 49
- **final items: 405**

## v1.6 additions

- `bed-39127`
- `bed-60630`
- `bed-35036`
- `bookshelf-8919`
- `bookshelf-51617`
- `bookshelf-27566`
- `bookshelf-58901`
- `cabinet-37285`
- `cabinet-14286`
- `chair-20689`
- `desk-10388`
- `desk-62889`
- `lamp-10186`
- `stove-54928`
- `stove-25505`
- `table-55680`

## Review promotions

- `bed-41820`
- `bed-44401`
- `bed-55686`
- `bed-18376`
- `bed-60287`
- `bookshelf-57602`
- `bookshelf-9548`
- `bookshelf-28802`
- `bookshelf-37285`
- `cabinet-2625`
- `cabinet-62800`
- `cabinet-8782`
- `cabinet-8622`
- `cabinet-29382`
- `cabinet-27600`
- `chair-13928`
- `chair-3335`
- `chair-24812`
- `chair-49349`
- `chair-234`
- `desk-63589`
- `desk-59701`
- `desk-60313`
- `desk-24146`
- `desk-10433`
- `lamp-20699`
- `lamp-42665`
- `lamp-32713`
- `plant-18249`
- `plant-20766`
- `plant-14760`
- `plant-48823`
- `plant-53316`
- `plant-52023`
- `plant-6776`
- `sink-21123`
- `stove-19558`
- `stove-12765`
- `table-47990`
- `table-31328`
- `table-33117`
- `toilet-64758`
- `toilet-6888`
- `toilet-24067`
- `toilet-26168`
- `tv-52019`
- `tv-54719`
- `tv-301`
- `washer-22242`
