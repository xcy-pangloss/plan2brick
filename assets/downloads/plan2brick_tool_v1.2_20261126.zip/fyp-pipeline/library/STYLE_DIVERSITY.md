# Library style / colour diversity

- items: 405
- styles: {"modern": 256, "vintage": 86, "industrial": 214, "family": 136, "compact": 322, "classic": 5, "rustic": 53, "colorful": 96}
- colour families: {"warm": 21, "neutral": 364, "cool": 20}
- size classes: {"large": 56, "small": 144, "medium": 205}

| category | items | style tags |
|---|---:|---|
| bath | 5 | {'modern': 5, 'industrial': 3, 'family': 2, 'compact': 5, 'vintage': 2} |
| bed | 39 | {'classic': 2, 'modern': 23, 'rustic': 9, 'compact': 20, 'industrial': 9, 'family': 12, 'vintage': 8, 'colorful': 10} |
| bookshelf | 38 | {'vintage': 10, 'compact': 34, 'colorful': 24, 'industrial': 20, 'modern': 10, 'rustic': 12, 'family': 6} |
| cabinet | 56 | {'modern': 42, 'industrial': 34, 'family': 23, 'compact': 52, 'colorful': 9, 'vintage': 6, 'rustic': 7} |
| chair | 34 | {'industrial': 20, 'compact': 24, 'modern': 27, 'family': 16, 'rustic': 3, 'colorful': 7, 'vintage': 5} |
| desk | 41 | {'modern': 32, 'industrial': 26, 'compact': 31, 'family': 9, 'rustic': 3, 'vintage': 13, 'colorful': 7} |
| fridge | 2 | {'modern': 2, 'industrial': 2, 'family': 2, 'compact': 2} |
| lamp | 19 | {'vintage': 12, 'industrial': 18, 'modern': 8, 'family': 7, 'compact': 12, 'colorful': 3, 'rustic': 1} |
| plant | 31 | {'modern': 11, 'vintage': 4, 'compact': 29, 'colorful': 12, 'family': 8, 'classic': 2, 'industrial': 5, 'rustic': 1} |
| sink | 24 | {'rustic': 1, 'compact': 24, 'modern': 17, 'family': 7, 'industrial': 7, 'colorful': 2, 'vintage': 1} |
| sofa | 26 | {'modern': 24, 'vintage': 3, 'industrial': 11, 'family': 11, 'compact': 17, 'colorful': 10, 'rustic': 2} |
| stove | 16 | {'rustic': 3, 'industrial': 14, 'compact': 15, 'modern': 14, 'vintage': 2, 'family': 5, 'colorful': 1} |
| table | 52 | {'rustic': 9, 'vintage': 11, 'industrial': 27, 'compact': 42, 'modern': 25, 'family': 16, 'colorful': 9, 'classic': 1} |
| toilet | 7 | {'industrial': 5, 'modern': 5, 'compact': 4, 'family': 1} |
| tv | 13 | {'modern': 10, 'rustic': 2, 'vintage': 9, 'industrial': 12, 'family': 9, 'compact': 10, 'colorful': 2} |
| washer | 2 | {'modern': 1, 'industrial': 1, 'family': 2, 'compact': 1} |
