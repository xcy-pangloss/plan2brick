"""FYP 场景管线 v1 · M2 输出校验器（场景 IR 结构检查，零依赖）。

Usage: C:\\Python314\\python.exe check_ir.py <ir.json> [<ir2.json> ...]
Exit : 0 = 无 error（warnings 允许）；1 = 有 error。
"""
import json
import sys
from pathlib import Path

CATS = {"sofa", "bed", "table", "chair", "desk", "cabinet", "bookshelf", "lamp", "tv", "plant",
        "fridge", "stove", "sink", "toilet", "bath", "washer"}


def check(path):
    errors, warnings = [], []
    try:
        ir = json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception as e:
        return [f"parse fail: {e}"], []
    if ir.get("image_type") not in ("floorplan", "photo"):
        errors.append(f"image_type must be floorplan|photo, got {ir.get('image_type')!r}")
    rooms = ir.get("rooms") or []
    if not isinstance(rooms, list) or not rooms:
        errors.append("rooms: non-empty list required")
    names = set()
    for i, r in enumerate(rooms):
        n = r.get("name_cn") or r.get("name_en")
        if not n:
            errors.append(f"rooms[{i}]: name_cn/name_en required")
        else:
            names.add(str(n).lower())
            if r.get("name_en"):
                names.add(str(r["name_en"]).lower())
        d = r.get("dims_m")
        if not (isinstance(d, list) and len(d) >= 2 and all(isinstance(v, (int, float)) and v > 0 for v in d[:2])):
            errors.append(f"rooms[{i}] {n}: dims_m must be [w,d] positive numbers")
    objs = ir.get("objects") or []
    if not isinstance(objs, list) or not objs:
        errors.append("objects: non-empty list required")
    for i, o in enumerate(objs):
        c = o.get("category")
        if c not in CATS and c != "other":
            errors.append(f"objects[{i}]: category {c!r} not in library tokens/other")
        if c == "other":
            warnings.append(f"objects[{i}] {o.get('label')!r}: category 'other' (build_scene will drop: no library)")
        cnt = o.get("count", 1)
        if not (isinstance(cnt, int) and cnt >= 1):
            errors.append(f"objects[{i}]: count must be int >= 1")
        s = o.get("size_est_m")
        if not (isinstance(s, list) and len(s) >= 3 and all(isinstance(v, (int, float)) and v > 0 for v in s[:3])):
            warnings.append(f"objects[{i}] {o.get('label')!r}: size_est_m missing/short (picker falls back to [1,1,0.8])")
        rn = str(o.get("room") or "").lower()
        if names and rn and not any(rn in nm or nm in rn for nm in names if nm):
            warnings.append(f"objects[{i}] {o.get('label')!r}: room {rn!r} matches no IR room")
        cf = o.get("confidence")
        if cf is not None and not (isinstance(cf, (int, float)) and 0 <= cf <= 1):
            warnings.append(f"objects[{i}]: confidence {cf!r} outside 0-1")
    return errors, warnings


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    rc = 0
    for p in sys.argv[1:]:
        e, w = check(p)
        print(f"== {p}")
        for x in e:
            print("  ERROR  ", x)
        for x in w:
            print("  warn   ", x)
        print(f"  -> {'FAIL' if e else 'OK'} ({len(e)} errors, {len(w)} warnings)")
        rc |= 1 if e else 0
    return rc


if __name__ == "__main__":
    sys.exit(main())
