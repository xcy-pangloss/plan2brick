# Examples

- `example_workbench_ir.json` — a checked scene IR from the local workbench.
- `example_brief.txt` — a supported one-line brief.

Workbench: choose a preset, edit rooms, paste the brief, Generate.
CLI: `plan2brick.cmd generate --plan examples/example_workbench_ir.json --brief "Add a desk to the living room." --candidates 6 --diversity fidelity`
