"""Build app/data.js from the gallery-parity run artifacts.

The showcase is a static site.  This script only flattens the machine-readable
results (manifest, parent verification, BOM overlap, per-run checks) plus the
curated content notes from REPORT.md into one JS object.  Re-run after a new
verification pass:

    python app/build_data.py
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PARITY = ROOT / "out" / "gallery-parity"
APP = Path(__file__).resolve().parent

CONTENT = {
    "atlas-crane": {
        "blurb": "A four-axle Technic crane with a lattice boom, outriggers, a working-looking cab and a red engine block.",
        "features": [
            "Four-axle, eight-wheel chassis with a ladder frame and four outriggers",
            "Visible slew ring; lattice main boom, jib, hook block and cable path",
            "Operator cab and chassis cab with three-sided glazing",
            "Red engine block, three cylinder heads, twin stacks and a radiator grille",
            "Counterweight, twin winch drums and a 16-tooth drive gear",
            "Walkway railings; yellow / black / grey palette",
        ],
        "gaps": [
            "Density: 1,082 vs 587 parts",
            "Boom angle is steeper and the chassis shorter than the original",
            "Rigging is a rigid axle section rather than a flexible cable",
            "Outriggers do not telescope; no load or interior",
        ],
        "duration": "48m 39s",
        "tokens": 158461,
    },
    "cathedral": {
        "blurb": "A twin-tower cathedral with a west rose window, pointed portal, nave, clerestory, buttresses and a four-level plaza.",
        "features": [
            "West portal with pointed arch, doors, lintel and gable",
            "Rose window in trans-dark-blue / red / yellow, mounted as a matrix",
            "Two 10x10 towers with belfry, corner pinnacles, spires and gold crosses",
            "Nave, side aisles and clerestory windows",
            "Fourteen stepped buttresses with pinnacles",
            "Pitched roofs, ridge cresting and a crossing spire",
            "Apse with a large east window and corner turrets",
            "Four-level baseplate plaza, steps, lamps and trees",
        ],
        "gaps": [
            "4,174 vs 5,394 parts",
            "Rose window is only 6 studs across",
            "Buttresses are stepped piers, not true flying buttresses",
            "No side porches or interior; windows are flat trans bricks without tracery",
            "Overall palette is cooler and greyer than the original tan / white",
        ],
        "duration": "56m 31s",
        "tokens": 61219,
    },
    "copper-bean": {
        "blurb": "A three-storey tan apartment block over a dark-green coffee shop, with three minifigs at an outdoor cafe table.",
        "features": [
            "Three storeys of tan / cream housing over a dark-green ground-floor cafe",
            "Three-bay shopfront glazing, doors, side windows and a fitted interior (counter, machine, cups, menu)",
            "Green-and-white striped awning and a sign fascia",
            "Three seated minifigs, a cafe table, three cups and a large green umbrella",
            "Two balcony levels with planters and windows",
            "Roof parapet with copper coping, water tank, AC unit and roof garden",
            "Two street lamps, two trees, planters and paving",
        ],
        "gaps": [
            "Parts count overshoots by 15%",
            "Upper facades are flatter and have fewer window openings",
            "The entrance is partly hidden by the umbrella and figures in the front view",
            "No lettering on the sign; small balconies are sparse",
        ],
        "duration": "47m 37s",
        "tokens": 134561,
    },
    "sakura-garden": {
        "blurb": "A five-storey vermilion pagoda in a Japanese garden with cherry trees, a pond, an arched bridge and a torii.",
        "features": [
            "Five-storey vermilion pagoda with double dark-grey eaves, 14 windows and a gold finial",
            "Two cherry trees",
            "Irregular pond with transparent light-blue water",
            "Eight-segment arched bridge with railings and stone piers",
            "Red torii gate; three stone lanterns",
            "Tea pavilion with benches",
            "Nineteen stepping stones with side fences",
            "Eight boulders, nine shrubs, twelve moss patches, forty-one fallen petals and three koi",
        ],
        "gaps": [
            "1,262 vs 2,175 parts",
            "Canopies are stacked leaf pieces; from the front they read pale and spiky and partly hide the pagoda",
            "Bridge is too thick; grey pagoda base and pavilion roof dominate the top view",
            "The original's flower-plate vocabulary (24866 white / dark pink) is not reproduced",
        ],
        "duration": "53m 31s",
        "tokens": 127643,
    },
    "tidal-observatory": {
        "blurb": "A coastal observatory: wet-stone quay, white main building, green Technic dome with telescope, blue-roofed tower and a lighthouse.",
        "features": [
            "Three-level wet-stone quay with paving and coping",
            "Deep-blue water, light-blue shallows, white foam and a buoy",
            "White main building with thirteen dark-blue windows, a door, gold plaque and cornice",
            "Green Technic dome with an external telescope and a gold weather vane",
            "Blue-roofed five-stage square tower with a gold top",
            "Timber jetty with two railing levels and a red-and-white lighthouse",
            "Three-level rocky shore, three reefs, two tide pools, seaweed, lamps and crates",
        ],
        "gaps": [
            "1,345 vs 2,734 parts",
            "The main building is a tall white keep; the original is a lower, wider tan 2-3 storey waterfront building",
            "Water and shore are large plates; the original uses 972 1x1 tiles for texture",
            "The dome has no opening; no boat, seabirds or interior",
        ],
        "duration": "44m 14s",
        "tokens": 156416,
    },
}

PIPELINE = [
    ("Prompt", "Use the gallery's original prompt verbatim, plus a short content checklist for open-ended prompts."),
    ("Design brief", "Subject, silhouette, envelope, palette roles, focal/supporting features, module table and build order."),
    ("Generate", "Python generator emits model.plan.json with sectioned modules; build produces the editable .mpd."),
    ("Validate", "validate --geometry and inspect; repair overlaps and rebuild after each fix."),
    ("Render & review", "Render home / front / top, open the PNGs, write visual-review.md, then iterate at least once."),
    ("BOM & freeze", "bom and compare-bom against the LeoCAD CSV; freeze the 15 artifact types."),
]


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main() -> None:
    manifest = load(PARITY / "manifest.json")
    summary = load(PARITY / "verify" / "summary.json")
    overlap = load(PARITY / "bom-overlap.json")
    overlap_by_key = {item["run"]: item for item in overlap}
    by_key = {item["key"]: item for item in summary}

    models = []
    total_ours = 0
    total_original = 0
    for task in manifest["tasks"]:
        key = task["key"]
        verify = by_key[key]
        metrics = verify["verified"]
        baseline = verify["baseline"]
        bom = overlap_by_key[key]
        comparison = load(PARITY / "runs" / key / "verify" / "bom-comparison.json")
        checks = {name: data["exit"] for name, data in verify["commands"].items()}
        content = CONTENT[key]
        ours = metrics["occurrences"]
        original = baseline["occurrences"]
        total_ours += ours
        total_original += original
        models.append({
            "key": key,
            "title": task["title"],
            "original_credit": task["original"],
            "prompt": task["prompt"],
            "blurb": content["blurb"],
            "features": content["features"],
            "gaps": content["gaps"],
            "ours": ours,
            "original": original,
            "ratio": verify["occurrence_ratio"],
            "checks": checks,
            "checks_passed": metrics["checks_passed"],
            "warnings": metrics["warnings"],
            "errors": metrics["errors"],
            "bom": {
                "coverage": bom["quantity_coverage"],
                "precision": bom["quantity_precision"],
                "jaccard": bom["key_jaccard"],
                "cosine": bom["cosine"],
                "original_total": bom["original_total"],
                "shared_top": bom["shared_top"][:5],
                "matches": comparison["comparison"]["matches"],
                "differences": len(comparison["comparison"]["differences"]),
                "placements": comparison["comparison"]["physical_placements"],
            },
            "duration": content["duration"],
            "tokens": content["tokens"],
            "assets": {
                "home": f"../out/gallery-parity/runs/{key}/renders/home.png",
                "front": f"../out/gallery-parity/runs/{key}/renders/front.png",
                "top": f"../out/gallery-parity/runs/{key}/renders/top.png",
                "compare": f"../out/gallery-parity/compare/{key}.png",
                "mpd": f"../out/gallery-parity/runs/{key}/model.mpd",
                "plan": f"../out/gallery-parity/runs/{key}/model.plan.json",
                "generator": f"../out/gallery-parity/runs/{key}/generate.py",
                "design": f"../out/gallery-parity/runs/{key}/design-brief.md",
                "agent": f"../out/gallery-parity/runs/{key}/AGENT_REPORT.md",
                "review": f"../out/gallery-parity/runs/{key}/visual-review.md",
                "validation": f"../out/gallery-parity/runs/{key}/verify/validation.json",
                "inspection": f"../out/gallery-parity/runs/{key}/verify/inspection.json",
                "bom": f"../out/gallery-parity/runs/{key}/verify/bom.json",
                "bom_compare": f"../out/gallery-parity/runs/{key}/verify/bom-comparison.json",
                "player": f"player.html?model=../out/gallery-parity/runs/{key}/model.mpd&parts={ours}&theme=dark&at=end",
            },
        })

    payload = {
        "generated": "2026-10-18",
        "model": "deepseek-v4-flash",
        "toolkit": "lego-nova 0.2.0",
        "summary": {
            "models": len(models),
            "ours": total_ours,
            "original": total_original,
            "ratio": round(total_ours / total_original, 3),
            "checks": 20,
            "wall": "56 min",
            "tokens": sum(m["tokens"] for m in models),
        },
        "models": models,
        "pipeline": [{"step": i + 1, "title": t, "detail": d} for i, (t, d) in enumerate(PIPELINE)],
        "report": "../out/gallery-parity/REPORT.md",
        "bom_overlap": "../out/gallery-parity/bom-overlap.json",
        "verify_summary": "../out/gallery-parity/verify/summary.json",
    }

    out = APP / "data.js"
    out.write_text("window.GALLERY = " + json.dumps(payload, ensure_ascii=False, indent=2) + ";\n",
                   encoding="utf-8")
    print(f"wrote {out} ({len(models)} models, {total_ours} parts)")


if __name__ == "__main__":
    main()
