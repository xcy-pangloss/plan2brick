window.GALLERY = {
  "generated": "2026-10-18",
  "model": "deepseek-v4-flash",
  "toolkit": "lego-nova 0.2.0",
  "summary": {
    "models": 5,
    "ours": 8547,
    "original": 12407,
    "ratio": 0.689,
    "checks": 20,
    "wall": "56 min",
    "tokens": 638300
  },
  "models": [
    {
      "key": "atlas-crane",
      "title": "Atlas Crane",
      "original_credit": "Opus 5.5 extra high (unfinished)",
      "prompt": "read the instructions.md, and then build me a big machine, an impressive one, Technic style, also with engines and very realistic details.",
      "blurb": "A four-axle Technic crane with a lattice boom, outriggers, a working-looking cab and a red engine block.",
      "features": [
        "Four-axle, eight-wheel chassis with a ladder frame and four outriggers",
        "Visible slew ring; lattice main boom, jib, hook block and cable path",
        "Operator cab and chassis cab with three-sided glazing",
        "Red engine block, three cylinder heads, twin stacks and a radiator grille",
        "Counterweight, twin winch drums and a 16-tooth drive gear",
        "Walkway railings; yellow / black / grey palette"
      ],
      "gaps": [
        "Density: 1,082 vs 587 parts",
        "Boom angle is steeper and the chassis shorter than the original",
        "Rigging is a rigid axle section rather than a flexible cable",
        "Outriggers do not telescope; no load or interior"
      ],
      "ours": 587,
      "original": 1082,
      "ratio": 0.543,
      "checks": {
        "validate": 0,
        "inspect": 0,
        "bom": 0,
        "compare_bom": 0
      },
      "checks_passed": true,
      "warnings": 5,
      "errors": 0,
      "bom": {
        "coverage": 0.1029,
        "precision": 0.1891,
        "jaccard": 0.0674,
        "cosine": 0.212,
        "original_total": 1079,
        "shared_top": [
          {
            "part": "2780",
            "colour": 0,
            "pieces": 28
          },
          {
            "part": "32278",
            "colour": 14,
            "pieces": 25
          },
          {
            "part": "32316",
            "colour": 72,
            "pieces": 22
          },
          {
            "part": "32523",
            "colour": 0,
            "pieces": 14
          },
          {
            "part": "32278",
            "colour": 0,
            "pieces": 8
          }
        ],
        "matches": true,
        "differences": 0,
        "placements": 587
      },
      "duration": "48m 39s",
      "tokens": 158461,
      "assets": {
        "home": "../out/gallery-parity/runs/atlas-crane/renders/home.png",
        "front": "../out/gallery-parity/runs/atlas-crane/renders/front.png",
        "top": "../out/gallery-parity/runs/atlas-crane/renders/top.png",
        "compare": "../out/gallery-parity/compare/atlas-crane.png",
        "mpd": "../out/gallery-parity/runs/atlas-crane/model.mpd",
        "plan": "../out/gallery-parity/runs/atlas-crane/model.plan.json",
        "generator": "../out/gallery-parity/runs/atlas-crane/generate.py",
        "design": "../out/gallery-parity/runs/atlas-crane/design-brief.md",
        "agent": "../out/gallery-parity/runs/atlas-crane/AGENT_REPORT.md",
        "review": "../out/gallery-parity/runs/atlas-crane/visual-review.md",
        "validation": "../out/gallery-parity/runs/atlas-crane/verify/validation.json",
        "inspection": "../out/gallery-parity/runs/atlas-crane/verify/inspection.json",
        "bom": "../out/gallery-parity/runs/atlas-crane/verify/bom.json",
        "bom_compare": "../out/gallery-parity/runs/atlas-crane/verify/bom-comparison.json",
        "player": "player.html?model=../out/gallery-parity/runs/atlas-crane/model.mpd&parts=587&theme=dark&at=end"
      }
    },
    {
      "key": "cathedral",
      "title": "Cathedral",
      "original_credit": "GPT-6 Astra xhigh",
      "prompt": "build me a cathedral",
      "blurb": "A twin-tower cathedral with a west rose window, pointed portal, nave, clerestory, buttresses and a four-level plaza.",
      "features": [
        "West portal with pointed arch, doors, lintel and gable",
        "Rose window in trans-dark-blue / red / yellow, mounted as a matrix",
        "Two 10x10 towers with belfry, corner pinnacles, spires and gold crosses",
        "Nave, side aisles and clerestory windows",
        "Fourteen stepped buttresses with pinnacles",
        "Pitched roofs, ridge cresting and a crossing spire",
        "Apse with a large east window and corner turrets",
        "Four-level baseplate plaza, steps, lamps and trees"
      ],
      "gaps": [
        "4,174 vs 5,394 parts",
        "Rose window is only 6 studs across",
        "Buttresses are stepped piers, not true flying buttresses",
        "No side porches or interior; windows are flat trans bricks without tracery",
        "Overall palette is cooler and greyer than the original tan / white"
      ],
      "ours": 4174,
      "original": 5394,
      "ratio": 0.774,
      "checks": {
        "validate": 0,
        "inspect": 0,
        "bom": 0,
        "compare_bom": 0
      },
      "checks_passed": true,
      "warnings": 2,
      "errors": 0,
      "bom": {
        "coverage": 0.1175,
        "precision": 0.1519,
        "jaccard": 0.1089,
        "cosine": 0.1343,
        "original_total": 5394,
        "shared_top": [
          {
            "part": "3039",
            "colour": 72,
            "pieces": 226
          },
          {
            "part": "3010",
            "colour": 19,
            "pieces": 164
          },
          {
            "part": "3005",
            "colour": 19,
            "pieces": 96
          },
          {
            "part": "3004",
            "colour": 19,
            "pieces": 59
          },
          {
            "part": "3068b",
            "colour": 72,
            "pieces": 20
          }
        ],
        "matches": true,
        "differences": 0,
        "placements": 4174
      },
      "duration": "56m 31s",
      "tokens": 61219,
      "assets": {
        "home": "../out/gallery-parity/runs/cathedral/renders/home.png",
        "front": "../out/gallery-parity/runs/cathedral/renders/front.png",
        "top": "../out/gallery-parity/runs/cathedral/renders/top.png",
        "compare": "../out/gallery-parity/compare/cathedral.png",
        "mpd": "../out/gallery-parity/runs/cathedral/model.mpd",
        "plan": "../out/gallery-parity/runs/cathedral/model.plan.json",
        "generator": "../out/gallery-parity/runs/cathedral/generate.py",
        "design": "../out/gallery-parity/runs/cathedral/design-brief.md",
        "agent": "../out/gallery-parity/runs/cathedral/AGENT_REPORT.md",
        "review": "../out/gallery-parity/runs/cathedral/visual-review.md",
        "validation": "../out/gallery-parity/runs/cathedral/verify/validation.json",
        "inspection": "../out/gallery-parity/runs/cathedral/verify/inspection.json",
        "bom": "../out/gallery-parity/runs/cathedral/verify/bom.json",
        "bom_compare": "../out/gallery-parity/runs/cathedral/verify/bom-comparison.json",
        "player": "player.html?model=../out/gallery-parity/runs/cathedral/model.mpd&parts=4174&theme=dark&at=end"
      }
    },
    {
      "key": "copper-bean",
      "title": "Copper Bean",
      "original_credit": "Opus 5 extra high",
      "prompt": "read instructions.md\nthen, build me 3-storey appartments building, with a coffee shop at the base floor, with three people having coffee under an umbrella, outside the shop",
      "blurb": "A three-storey tan apartment block over a dark-green coffee shop, with three minifigs at an outdoor cafe table.",
      "features": [
        "Three storeys of tan / cream housing over a dark-green ground-floor cafe",
        "Three-bay shopfront glazing, doors, side windows and a fitted interior (counter, machine, cups, menu)",
        "Green-and-white striped awning and a sign fascia",
        "Three seated minifigs, a cafe table, three cups and a large green umbrella",
        "Two balcony levels with planters and windows",
        "Roof parapet with copper coping, water tank, AC unit and roof garden",
        "Two street lamps, two trees, planters and paving"
      ],
      "gaps": [
        "Parts count overshoots by 15%",
        "Upper facades are flatter and have fewer window openings",
        "The entrance is partly hidden by the umbrella and figures in the front view",
        "No lettering on the sign; small balconies are sparse"
      ],
      "ours": 1179,
      "original": 1022,
      "ratio": 1.154,
      "checks": {
        "validate": 0,
        "inspect": 0,
        "bom": 0,
        "compare_bom": 0
      },
      "checks_passed": true,
      "warnings": 16,
      "errors": 0,
      "bom": {
        "coverage": 0.2544,
        "precision": 0.2205,
        "jaccard": 0.2333,
        "cosine": 0.2376,
        "original_total": 1022,
        "shared_top": [
          {
            "part": "3010",
            "colour": 19,
            "pieces": 42
          },
          {
            "part": "3068b",
            "colour": 72,
            "pieces": 41
          },
          {
            "part": "3004",
            "colour": 19,
            "pieces": 24
          },
          {
            "part": "3010",
            "colour": 288,
            "pieces": 23
          },
          {
            "part": "3622",
            "colour": 19,
            "pieces": 14
          }
        ],
        "matches": true,
        "differences": 0,
        "placements": 1179
      },
      "duration": "47m 37s",
      "tokens": 134561,
      "assets": {
        "home": "../out/gallery-parity/runs/copper-bean/renders/home.png",
        "front": "../out/gallery-parity/runs/copper-bean/renders/front.png",
        "top": "../out/gallery-parity/runs/copper-bean/renders/top.png",
        "compare": "../out/gallery-parity/compare/copper-bean.png",
        "mpd": "../out/gallery-parity/runs/copper-bean/model.mpd",
        "plan": "../out/gallery-parity/runs/copper-bean/model.plan.json",
        "generator": "../out/gallery-parity/runs/copper-bean/generate.py",
        "design": "../out/gallery-parity/runs/copper-bean/design-brief.md",
        "agent": "../out/gallery-parity/runs/copper-bean/AGENT_REPORT.md",
        "review": "../out/gallery-parity/runs/copper-bean/visual-review.md",
        "validation": "../out/gallery-parity/runs/copper-bean/verify/validation.json",
        "inspection": "../out/gallery-parity/runs/copper-bean/verify/inspection.json",
        "bom": "../out/gallery-parity/runs/copper-bean/verify/bom.json",
        "bom_compare": "../out/gallery-parity/runs/copper-bean/verify/bom-comparison.json",
        "player": "player.html?model=../out/gallery-parity/runs/copper-bean/model.mpd&parts=1179&theme=dark&at=end"
      }
    },
    {
      "key": "sakura-garden",
      "title": "Sakura Garden",
      "original_credit": "Opus 5.5 extra high",
      "prompt": "read instructions.md and then, build me the most beautiful model that comes to your mind, you choose about any and every feature it should have!",
      "blurb": "A five-storey vermilion pagoda in a Japanese garden with cherry trees, a pond, an arched bridge and a torii.",
      "features": [
        "Five-storey vermilion pagoda with double dark-grey eaves, 14 windows and a gold finial",
        "Two cherry trees",
        "Irregular pond with transparent light-blue water",
        "Eight-segment arched bridge with railings and stone piers",
        "Red torii gate; three stone lanterns",
        "Tea pavilion with benches",
        "Nineteen stepping stones with side fences",
        "Eight boulders, nine shrubs, twelve moss patches, forty-one fallen petals and three koi"
      ],
      "gaps": [
        "1,262 vs 2,175 parts",
        "Canopies are stacked leaf pieces; from the front they read pale and spiky and partly hide the pagoda",
        "Bridge is too thick; grey pagoda base and pavilion roof dominate the top view",
        "The original's flower-plate vocabulary (24866 white / dark pink) is not reproduced"
      ],
      "ours": 1262,
      "original": 2175,
      "ratio": 0.58,
      "checks": {
        "validate": 0,
        "inspect": 0,
        "bom": 0,
        "compare_bom": 0
      },
      "checks_passed": true,
      "warnings": 2,
      "errors": 0,
      "bom": {
        "coverage": 0.0749,
        "precision": 0.1292,
        "jaccard": 0.0728,
        "cosine": 0.1799,
        "original_total": 2175,
        "shared_top": [
          {
            "part": "3005",
            "colour": 4,
            "pieces": 80
          },
          {
            "part": "3941",
            "colour": 70,
            "pieces": 14
          },
          {
            "part": "3941",
            "colour": 4,
            "pieces": 12
          },
          {
            "part": "3062b",
            "colour": 71,
            "pieces": 9
          },
          {
            "part": "3023b",
            "colour": 2,
            "pieces": 7
          }
        ],
        "matches": true,
        "differences": 0,
        "placements": 1262
      },
      "duration": "53m 31s",
      "tokens": 127643,
      "assets": {
        "home": "../out/gallery-parity/runs/sakura-garden/renders/home.png",
        "front": "../out/gallery-parity/runs/sakura-garden/renders/front.png",
        "top": "../out/gallery-parity/runs/sakura-garden/renders/top.png",
        "compare": "../out/gallery-parity/compare/sakura-garden.png",
        "mpd": "../out/gallery-parity/runs/sakura-garden/model.mpd",
        "plan": "../out/gallery-parity/runs/sakura-garden/model.plan.json",
        "generator": "../out/gallery-parity/runs/sakura-garden/generate.py",
        "design": "../out/gallery-parity/runs/sakura-garden/design-brief.md",
        "agent": "../out/gallery-parity/runs/sakura-garden/AGENT_REPORT.md",
        "review": "../out/gallery-parity/runs/sakura-garden/visual-review.md",
        "validation": "../out/gallery-parity/runs/sakura-garden/verify/validation.json",
        "inspection": "../out/gallery-parity/runs/sakura-garden/verify/inspection.json",
        "bom": "../out/gallery-parity/runs/sakura-garden/verify/bom.json",
        "bom_compare": "../out/gallery-parity/runs/sakura-garden/verify/bom-comparison.json",
        "player": "player.html?model=../out/gallery-parity/runs/sakura-garden/model.mpd&parts=1262&theme=dark&at=end"
      }
    },
    {
      "key": "tidal-observatory",
      "title": "The Tidal Observatory",
      "original_credit": "GPT-6 Astra xhigh",
      "prompt": "build me the best building model you can think of; you are totally free to choose about its features!",
      "blurb": "A coastal observatory: wet-stone quay, white main building, green Technic dome with telescope, blue-roofed tower and a lighthouse.",
      "features": [
        "Three-level wet-stone quay with paving and coping",
        "Deep-blue water, light-blue shallows, white foam and a buoy",
        "White main building with thirteen dark-blue windows, a door, gold plaque and cornice",
        "Green Technic dome with an external telescope and a gold weather vane",
        "Blue-roofed five-stage square tower with a gold top",
        "Timber jetty with two railing levels and a red-and-white lighthouse",
        "Three-level rocky shore, three reefs, two tide pools, seaweed, lamps and crates"
      ],
      "gaps": [
        "1,345 vs 2,734 parts",
        "The main building is a tall white keep; the original is a lower, wider tan 2-3 storey waterfront building",
        "Water and shore are large plates; the original uses 972 1x1 tiles for texture",
        "The dome has no opening; no boat, seabirds or interior"
      ],
      "ours": 1345,
      "original": 2734,
      "ratio": 0.492,
      "checks": {
        "validate": 0,
        "inspect": 0,
        "bom": 0,
        "compare_bom": 0
      },
      "checks_passed": true,
      "warnings": 2,
      "errors": 0,
      "bom": {
        "coverage": 0.0128,
        "precision": 0.026,
        "jaccard": 0.0683,
        "cosine": 0.0052,
        "original_total": 2734,
        "shared_top": [
          {
            "part": "3005",
            "colour": 15,
            "pieces": 14
          },
          {
            "part": "3062b",
            "colour": 70,
            "pieces": 3
          },
          {
            "part": "3031",
            "colour": 72,
            "pieces": 3
          },
          {
            "part": "4589",
            "colour": 297,
            "pieces": 2
          },
          {
            "part": "4589",
            "colour": 0,
            "pieces": 2
          }
        ],
        "matches": true,
        "differences": 0,
        "placements": 1345
      },
      "duration": "44m 14s",
      "tokens": 156416,
      "assets": {
        "home": "../out/gallery-parity/runs/tidal-observatory/renders/home.png",
        "front": "../out/gallery-parity/runs/tidal-observatory/renders/front.png",
        "top": "../out/gallery-parity/runs/tidal-observatory/renders/top.png",
        "compare": "../out/gallery-parity/compare/tidal-observatory.png",
        "mpd": "../out/gallery-parity/runs/tidal-observatory/model.mpd",
        "plan": "../out/gallery-parity/runs/tidal-observatory/model.plan.json",
        "generator": "../out/gallery-parity/runs/tidal-observatory/generate.py",
        "design": "../out/gallery-parity/runs/tidal-observatory/design-brief.md",
        "agent": "../out/gallery-parity/runs/tidal-observatory/AGENT_REPORT.md",
        "review": "../out/gallery-parity/runs/tidal-observatory/visual-review.md",
        "validation": "../out/gallery-parity/runs/tidal-observatory/verify/validation.json",
        "inspection": "../out/gallery-parity/runs/tidal-observatory/verify/inspection.json",
        "bom": "../out/gallery-parity/runs/tidal-observatory/verify/bom.json",
        "bom_compare": "../out/gallery-parity/runs/tidal-observatory/verify/bom-comparison.json",
        "player": "player.html?model=../out/gallery-parity/runs/tidal-observatory/model.mpd&parts=1345&theme=dark&at=end"
      }
    }
  ],
  "pipeline": [
    {
      "step": 1,
      "title": "Prompt",
      "detail": "Use the gallery's original prompt verbatim, plus a short content checklist for open-ended prompts."
    },
    {
      "step": 2,
      "title": "Design brief",
      "detail": "Subject, silhouette, envelope, palette roles, focal/supporting features, module table and build order."
    },
    {
      "step": 3,
      "title": "Generate",
      "detail": "Python generator emits model.plan.json with sectioned modules; build produces the editable .mpd."
    },
    {
      "step": 4,
      "title": "Validate",
      "detail": "validate --geometry and inspect; repair overlaps and rebuild after each fix."
    },
    {
      "step": 5,
      "title": "Render & review",
      "detail": "Render home / front / top, open the PNGs, write visual-review.md, then iterate at least once."
    },
    {
      "step": 6,
      "title": "BOM & freeze",
      "detail": "bom and compare-bom against the LeoCAD CSV; freeze the 15 artifact types."
    }
  ],
  "report": "../out/gallery-parity/REPORT.md",
  "bom_overlap": "../out/gallery-parity/bom-overlap.json",
  "verify_summary": "../out/gallery-parity/verify/summary.json"
};
