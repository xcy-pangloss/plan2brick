/* lego-nova gallery parity — static showcase, vanilla JS. */
(function () {
  "use strict";

  const G = window.GALLERY;
  const app = document.getElementById("app");
  const tooltip = document.getElementById("tooltip");
  const CHECK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.3 5.7 9 17l-5.3-5.3 1.4-1.4L9 14.2 18.9 4.3z"/></svg>';
  const fmt = n => Number(n).toLocaleString("en-US");
  const pct = x => (x * 100).toFixed(1) + "%";
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const byKey = key => G.models.find(m => m.key === key);
  const COLOR_NAMES = {
    0: "black", 2: "green", 4: "red", 14: "yellow", 15: "white", 19: "tan",
    70: "reddish brown", 71: "light bluish gray", 72: "dark bluish gray",
    288: "dark green", 297: "pearl gold",
  };
  const colorName = c => COLOR_NAMES[c] || ("colour " + c);
  const maxOriginal = Math.max(...G.models.map(m => m.original));
  const barScale = maxOriginal * 1.12; // headroom for the direct labels
  const checkBadge = (text, cls = "good") => `<span class="badge ${cls}">${CHECK}${esc(text)}</span>`;

  function badgeRow(m) {
    return [
      checkBadge("4/4 checks", "good"),
      m.warnings ? `<span class="badge warn">${m.warnings} warning${m.warnings === 1 ? "" : "s"}</span>` : "",
      `<span class="badge plain">0 errors</span>`,
    ].join("");
  }

  function modelCard(m) {
    return `
      <a class="model-card" href="#/model/${m.key}" aria-label="Open ${esc(m.title)} case study">
        <div class="card-media">
          <img src="${m.assets.home}" alt="${esc(m.title)} — home render" loading="lazy">
          <span class="ratio">${pct(m.ratio)} of original</span>
          <span class="status">${checkBadge("verified", "good")}</span>
        </div>
        <div class="card-body">
          <h3>${esc(m.title)} <span class="arrow" aria-hidden="true">→</span></h3>
          <div class="card-credit">${esc(m.original_credit)}</div>
          <p class="muted" style="margin:0;font-size:12.5px">${esc(m.blurb)}</p>
          <div class="card-stats">
            <span><b>${fmt(m.ours)}</b> parts</span>
            <span><b>${pct(m.bom.coverage)}</b> BOM overlap</span>
          </div>
          <div class="mini-meter" title="BOM material coverage ${pct(m.bom.coverage)}"><span style="width:${Math.max(2, m.bom.coverage * 100)}%"></span></div>
        </div>
      </a>`;
  }

  function barRow(m) {
    const ow = Math.max(0.6, m.ours / barScale * 100);
    const tw = Math.max(0.6, m.original / barScale * 100);
    return `
      <div class="bar-row" role="listitem">
        <div class="bar-name" title="${esc(m.title)}">${esc(m.title)}</div>
        <div class="bar-track">
          <div class="bar original" style="width:${tw}%" data-tip="${esc(m.title)}|gallery original|${m.original}|">
            <span class="bar-val">${fmt(m.original)}</span>
          </div>
          <div class="bar ours" style="width:${ow}%" data-tip="${esc(m.title)}|lego-nova + flash|${m.ours}|${m.original}">
            <span class="bar-val">${fmt(m.ours)}</span>
          </div>
        </div>
      </div>`;
  }

  function metricCell(value, label) {
    return `<div class="metric-cell" title="${esc(label)} ${pct(value)}">
      <div class="meter"><span style="width:${Math.max(1, value * 100)}%"></span></div>
      <b>${pct(value)}</b>
    </div>`;
  }

  function renderOverview() {
    const modelCards = G.models.map(modelCard).join("");
    const bars = G.models.map(barRow).join("");
    const bomRows = G.models.map(m => `
      <tr>
        <td><a href="#/model/${m.key}">${esc(m.title)}</a></td>
        <td>${metricCell(m.bom.coverage, "coverage")}</td>
        <td>${metricCell(m.bom.precision, "precision")}</td>
        <td>${metricCell(m.bom.jaccard, "key Jaccard")}</td>
        <td>${metricCell(m.bom.cosine, "cosine")}</td>
        <td class="num">${fmt(m.bom.placements)}</td>
      </tr>`).join("");
    const scaleRows = G.models.map(m => `
      <tr>
        <td>${esc(m.title)}</td>
        <td class="num">${fmt(m.ours)}</td>
        <td class="num">${fmt(m.original)}</td>
        <td class="num">${pct(m.ratio)}</td>
      </tr>`).join("");
    const runRows = G.models.map(m => `
      <tr>
        <td><a href="#/model/${m.key}">${esc(m.title)}</a></td>
        <td class="num">${esc(m.duration)}</td>
        <td class="num">${fmt(m.tokens)}</td>
        <td><span class="tag">validate</span> <span class="tag">inspect</span> <span class="tag">bom</span> <span class="tag">compare</span></td>
        <td class="num">${m.warnings}</td>
      </tr>`).join("");

    app.innerHTML = `
      <section class="hero">
        <div class="wrap">
          <div class="hero-grid">
            <div class="hero-copy">
              <p class="eyebrow">CSCI4998 · FYP demo · 2026-10-18</p>
              <h1>Five gallery exhibits,<br><span>rebuilt by a downgraded model.</span></h1>
              <p class="lede">A rebuilt LDraw toolchain plus <strong>deepseek-v4-flash</strong> agents, working from the gallery's original prompts. Every model was designed, generated, validated, rendered and iterated end-to-end — then independently re-verified by the parent process.</p>
              <div class="hero-actions">
                <button class="button primary" data-scroll="models">Explore the five builds</button>
                <a class="button ghost" href="../out/gallery-parity/REPORT.md">Read the full report</a>
              </div>
              <div class="hero-badges">
                ${checkBadge("5/5 models delivered", "good")}
                ${checkBadge("20/20 parent checks", "good")}
                <span class="badge plain">0 errors</span>
                <span class="badge plain">5 agents in parallel</span>
              </div>
            </div>
            <div class="hero-figure">
              <div class="big">68.9%</div>
              <div class="cap">of the original total part count — semantic and compositional parity, with a measured material-density gap.</div>
            </div>
          </div>

          <div class="kpi-grid" style="margin-top:34px">
            <div class="stat"><div class="value">5<small>/5</small></div><div class="label">gallery models</div><div class="sub">Atlas Crane · Cathedral · Copper Bean · Sakura Garden · Tidal Observatory</div></div>
            <div class="stat"><div class="value">${fmt(G.summary.ours)}</div><div class="label">reconstructed parts</div><div class="sub">vs ${fmt(G.summary.original)} in the originals</div></div>
            <div class="stat"><div class="value">20<small>/20</small></div><div class="label">parent-side checks</div><div class="sub">validate · inspect · bom · compare-bom</div></div>
            <div class="stat"><div class="value">${fmt(G.summary.tokens)}</div><div class="label">sub-agent tokens</div><div class="sub">${esc(G.summary.wall)} wall clock · 5 parallel agents</div></div>
          </div>
        </div>
      </section>

      <section class="section" id="models">
        <div class="wrap">
          <div class="section-head">
            <div>
              <p class="eyebrow">The builds</p>
              <h2>Five isolated runs, one toolchain</h2>
              <p>Each agent worked only inside its own run directory, with its own cache. The gallery originals and same-named example folders were off-limits.</p>
            </div>
            <div class="aside">Click a card for the case study</div>
          </div>
          <div class="card-grid">${modelCards}</div>
        </div>
      </section>

      <section class="section" id="scale">
        <div class="wrap">
          <div class="section-head">
            <div>
              <p class="eyebrow">Scale</p>
              <h2>What the model actually built</h2>
              <p>Part counts from the parent-side <code>inspect</code> pass. The blue bar is the flash build; the grey bar is the gallery original.</p>
            </div>
            <div class="aside">1 stud = 20 LDU</div>
          </div>
          <div class="panel">
            <div class="legend" aria-label="Chart legend">
              <span><i class="swatch ours"></i> lego-nova + deepseek-v4-flash</span>
              <span><i class="swatch original"></i> gallery original</span>
            </div>
            <div class="bar-chart" role="list" aria-label="Part counts: our builds versus gallery originals">${bars}</div>
            <p class="chart-note">Original counts are inspection occurrences. The BOM-overlap analysis below uses BOM placements; for Atlas Crane the BOM count is 1,079 (vs 1,082 inspected) because a few placements are not BOM-visible.</p>
            <details class="table-view">
              <summary>Table view</summary>
              <table>
                <thead><tr><th>Model</th><th class="num">Our parts</th><th class="num">Original</th><th class="num">Ratio</th></tr></thead>
                <tbody>${scaleRows}</tbody>
              </table>
            </details>
          </div>
        </div>
      </section>

      <section class="section" id="materials">
        <div class="wrap">
          <div class="section-head">
            <div>
              <p class="eyebrow">Materials</p>
              <h2>Semantic parity, not material parity</h2>
              <p>BOM overlap is a construction-vocabulary metric: the same part number and LDraw colour, counted by quantity. It is not a copy-paste check.</p>
            </div>
            <div class="aside">Coverage = shared / original</div>
          </div>
          <div class="panel table-wrap">
            <table>
              <thead><tr><th>Model</th><th class="num">Coverage</th><th class="num">Precision</th><th class="num">Key Jaccard</th><th class="num">Cosine</th><th class="num">BOM placements</th></tr></thead>
              <tbody>${bomRows}</tbody>
            </table>
            <p class="chart-note">Coverage 1.3%–25.4%: flash prefers large bricks and plates to close a surface quickly, while the originals spend many 1×1 tiles, flower plates and slopes on texture. Copper Bean is highest because the building is smaller and both sides share window, glass and 1×N vocabulary.</p>
          </div>
        </div>
      </section>

      <section class="section" id="pipeline">
        <div class="wrap">
          <div class="section-head">
            <div>
              <p class="eyebrow">Workflow</p>
              <h2>What each agent had to do</h2>
              <p>Same six-stage loop for every exhibit, from the original prompt to a frozen artifact set.</p>
            </div>
            <div class="aside">75-minute budget per run</div>
          </div>
          <div class="pipeline-grid">
            ${G.pipeline.map(s => `<div class="step"><div class="step-top"><span class="step-num">${s.step}</span><h3>${esc(s.title)}</h3></div><p>${esc(s.detail)}</p></div>`).join("")}
          </div>
          <div class="panel table-wrap" style="margin-top:14px">
            <table class="run-table">
              <thead><tr><th>Run</th><th class="num">Agent time</th><th class="num">Tokens</th><th>Checks</th><th class="num">Warnings</th></tr></thead>
              <tbody>${runRows}</tbody>
            </table>
            <p class="chart-note">Wall clock for the five parallel agents was about 56 minutes (01:12–02:08). Token counts are sub-agent metering; parent verification and reporting are additional.</p>
          </div>
        </div>
      </section>

      <section class="section" id="method">
        <div class="wrap">
          <div class="section-head">
            <div>
              <p class="eyebrow">Read this before the demo</p>
              <h2>What this proves — and what it doesn't</h2>
            </div>
            <div class="aside"><a href="../out/gallery-parity/REPORT.md">REPORT.md →</a></div>
          </div>
          <div class="split">
            <div class="panel">
              <h3>Demonstrated</h3>
              <ul class="note-list">
                <li><strong>Complete autonomous loop.</strong> Read docs → design brief → Python generator → sectioned plan → build → geometry repair → open renders → visual iteration → BOM → report. 5/5 without the parent editing a model.</li>
                <li><strong>Real geometry repair.</strong> Tidal's first pass had 236 body overlaps; walls, window openings, shared walls and bridge slopes brought it to 0 errors. Cathedral fixed a rose-window tile-pitch overlap.</li>
                <li><strong>Visual iteration.</strong> Agents recorded concrete problems (lamp blocking a door, glass reading as a white hole, shallows looking like ice, canopy too sparse) and changed the model.</li>
                <li><strong>Reproducible artifacts.</strong> Every exhibit ships a <code>generate.py</code>, <code>model.plan.json</code>, editable <code>.mpd</code>, four check JSONs, three renders and a LeoCAD BOM.</li>
              </ul>
            </div>
            <div class="panel">
              <h3>Not proven</h3>
              <ul class="note-list warn">
                <li><strong>Material / density parity.</strong> Part counts are 49%–115%; BOM quantity coverage is 1.3%–25.4%. The builds read as the right subject, not as the same construction.</li>
                <li><strong>Physical validity.</strong> <code>physical_validity</code> is <code>not_proven</code> for all five. Validation is AABB / oriented-box / 15-axis SAT plus connection metadata, not a physics simulation.</li>
                <li><strong>Open-ended subject choice.</strong> Sakura and Tidal prompts do not name a subject; the parent supplied a gallery-title checklist, so this is guided content reproduction, not a blind test.</li>
                <li><strong>Statistical scope.</strong> Five exhibits is an engineering validation of the toolchain, not a statistical claim about the model.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>`;
  }

  function renderDetail(key) {
    const m = byKey(key);
    if (!m) { location.hash = "#/"; return; }
    const checks = [
      ["validate", "geometry / syntax"],
      ["inspect", "contacts / overlaps"],
      ["bom", "BOM extraction"],
      ["compare_bom", "LeoCAD BOM parity"],
    ].map(([id, label]) => {
      const ok = m.checks[id] === 0;
      return `<tr><td><code>${id.replace("_", "-")}</code></td><td>${esc(label)}</td><td class="num">${ok ? '<span class="ok">exit 0</span>' : '<span class="bad">exit ' + esc(m.checks[id]) + "</span>"}</td><td>${ok ? '<span class="tag">passed</span>' : '<span class="tag warn">check</span>'}</td></tr>`;
    }).join("");
    const topParts = m.bom.shared_top.map(p => `<li><span><code>${esc(p.part)}</code> · ${esc(colorName(Number(p.colour)))}</span><span>${fmt(p.pieces)} pcs</span></li>`).join("");
    const downloads = [
      ["model.mpd", m.assets.mpd, true],
      ["model.plan.json", m.assets.plan, true],
      ["generate.py", m.assets.generator, true],
      ["design-brief.md", m.assets.design, false],
      ["AGENT_REPORT.md", m.assets.agent, false],
      ["visual-review.md", m.assets.review, false],
      ["validation.json", m.assets.validation, false],
      ["inspection.json", m.assets.inspection, false],
      ["bom.json", m.assets.bom, false],
      ["bom-comparison.json", m.assets.bom_compare, false],
    ].map(([label, href, dl]) => `<a href="${href}"${dl ? " download" : ""} target="_blank" rel="noopener">${esc(label)}</a>`).join("");

    app.innerHTML = `
      <section class="detail">
        <div class="wrap">
          <button class="back" data-go="overview">← All five builds</button>
          <div class="detail-hero">
            <div>
              <p class="eyebrow">Case study · ${esc(m.key)}</p>
              <h1>${esc(m.title)}</h1>
              <p class="lede">${esc(m.blurb)}</p>
              <div class="detail-meta">
                <span class="badge plain">original: ${esc(m.original_credit)}</span>
                ${checkBadge("4/4 checks", "good")}
                ${m.warnings ? `<span class="badge warn">${m.warnings} warnings</span>` : ""}
                <span class="badge plain">${esc(m.duration)} · ${fmt(m.tokens)} tokens</span>
              </div>
              <blockquote class="quote"><b>Gallery prompt</b>${esc(m.prompt)}</blockquote>
            </div>
            <div class="hero-figure" style="border-left:0;padding-left:0">
              <div class="big">${pct(m.ratio)}</div>
              <div class="cap">of the original part count — ${fmt(m.ours)} vs ${fmt(m.original)} parts.</div>
            </div>
          </div>

          <div class="detail-grid">
            <div class="panel viewer-panel">
              <div class="view-tabs" role="tablist" aria-label="Model views">
                <button class="view-tab" role="tab" aria-selected="true" data-view="home">Home</button>
                <button class="view-tab" role="tab" aria-selected="false" data-view="front">Front</button>
                <button class="view-tab" role="tab" aria-selected="false" data-view="top">Top</button>
                <button class="view-tab" role="tab" aria-selected="false" data-view="compare">Original vs ours</button>
              </div>
              <div class="view-stage"><img id="view-image" src="${m.assets.home}" alt="${esc(m.title)} — home render"></div>
              <div class="view-caption"><span id="view-caption">Home render · lego-nova render, three-view pass</span><span>${fmt(m.ours)} parts</span></div>
            </div>
            <aside class="detail-side">
              <div class="stat"><div class="value">${fmt(m.ours)}</div><div class="label">our parts</div><div class="sub">${fmt(m.original)} in the original</div></div>
              <div class="stat"><div class="value">${pct(m.bom.coverage)}</div><div class="label">BOM coverage</div><div class="sub">same part + colour / original</div></div>
              <div class="stat"><div class="value">${m.checks_passed ? "4/4" : "—"}</div><div class="label">checks passed</div><div class="sub">${m.warnings} warnings · ${m.errors} errors</div></div>
              <div class="panel player-cta">
                <div>
                  <h3 style="margin-bottom:4px">Open 3D build</h3>
                  <p>Interactive LDraw player: orbit, zoom, walk and replay the actual <code>.mpd</code> part by part. Needs WebGL2; the first load takes a few seconds.</p>
                </div>
                <div style="display:flex;gap:7px;flex-wrap:wrap">
                  <button class="button primary small" data-player="${m.key}">Open 3D</button>
                  <a class="button ghost small" href="${m.assets.player}" target="_blank" rel="noopener">New tab</a>
                </div>
              </div>
            </aside>
          </div>

          <div class="detail-columns">
            <div class="panel">
              <h3>What was built</h3>
              <ul class="note-list">${m.features.map(f => `<li>${esc(f)}</li>`).join("")}</ul>
            </div>
            <div class="panel">
              <h3>Known gaps vs the original</h3>
              <ul class="note-list warn">${m.gaps.map(f => `<li>${esc(f)}</li>`).join("")}</ul>
            </div>
          </div>

          <div class="detail-columns">
            <div class="panel table-wrap">
              <h3>Validation</h3>
              <table class="check-table">
                <thead><tr><th>Command</th><th>What it checks</th><th class="num">Result</th><th>Status</th></tr></thead>
                <tbody>${checks}</tbody>
              </table>
              <p class="chart-note">Warnings are coverage and library-metadata notes (e.g. <code>connection.invalid_transform</code> from offLibShadow, <code>coverage.contacts_skipped</code>), not errors. <code>physical_validity</code> remains <code>not_proven</code>.</p>
            </div>
            <div class="panel">
              <h3>Material overlap</h3>
              <div class="bom-main">
                <div><div class="big">${pct(m.bom.coverage)}</div><div class="cap">coverage</div></div>
                <div><div class="big">${pct(m.bom.precision)}</div><div class="cap">precision</div></div>
                <div><div class="big">${pct(m.bom.jaccard)}</div><div class="cap">key Jaccard</div></div>
                <div><div class="big">${pct(m.bom.cosine)}</div><div class="cap">cosine</div></div>
              </div>
              <p class="muted" style="font-size:12px">BOM ${m.bom.matches ? "matches" : "has differences"} · ${fmt(m.bom.placements)} placements · ${m.bom.differences} differences vs LeoCAD.</p>
              <h3 style="font-size:14px;margin-top:14px">Top shared part / colour</h3>
              <ul class="top-parts">${topParts}</ul>
            </div>
          </div>

          <div class="panel" style="margin-top:14px">
            <h3>Artifacts</h3>
            <p class="muted" style="font-size:12.5px">Everything is editable and reproducible. The <code>.mpd</code> is the build; <code>generate.py</code> + <code>model.plan.json</code> regenerate it; the check JSONs are the evidence used above.</p>
            <div class="downloads">${downloads}</div>
          </div>
        </div>
      </section>`;
  }

  function route() {
    const hash = location.hash || "#/";
    const m = hash.match(/^#\/model\/([a-z0-9-]+)$/);
    if (m) renderDetail(m[1]); else renderOverview();
    window.scrollTo(0, 0);
  }

  function goSection(id) {
    if (!location.hash || location.hash === "#/" ) {
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
    } else {
      location.hash = "#/";
      requestAnimationFrame(() => requestAnimationFrame(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
      }));
    }
  }

  function openPlayer(key) {
    const m = byKey(key);
    if (!m) return;
    const modal = document.getElementById("viewer-modal");
    document.getElementById("modal-title").textContent = m.title + " · 3D build";
    document.getElementById("modal-sub").textContent = m.ours + " parts · interactive LDraw player";
    const ext = document.getElementById("modal-external");
    ext.href = m.assets.player;
    const body = document.getElementById("modal-body");
    body.innerHTML = '<div class="modal-loading">Loading the LDraw player — the WASM renderer and part library can take a few seconds…</div>';
    const iframe = document.createElement("iframe");
    iframe.title = m.title + " 3D build";
    iframe.src = m.assets.player;
    iframe.allow = "fullscreen";
    // Keep the iframe hidden until it has loaded, so the modal shows progress.
    iframe.style.visibility = "hidden";
    iframe.addEventListener("load", () => {
      iframe.style.visibility = "visible";
      const loading = body.querySelector(".modal-loading");
      if (loading) loading.remove();
    });
    body.appendChild(iframe);
    modal.hidden = false;
    document.body.style.overflow = "hidden";
  }

  function closeModal() {
    const modal = document.getElementById("viewer-modal");
    modal.hidden = true;
    document.getElementById("modal-body").innerHTML = "";
    document.body.style.overflow = "";
  }

  // --- theme -----------------------------------------------------------------
  function effectiveTheme() {
    const stamped = document.documentElement.dataset.theme;
    if (stamped === "light" || stamped === "dark") return stamped;
    const stored = localStorage.getItem("lego-nova-theme");
    if (stored === "light" || stored === "dark") return stored;
    return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  function toggleTheme() {
    const next = effectiveTheme() === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    localStorage.setItem("lego-nova-theme", next);
  }

  // --- tooltip ---------------------------------------------------------------
  function showTip(el, ev) {
    const [model, series, value, total] = el.dataset.tip.split("|");
    const share = total ? (Number(value) / Number(total) * 100).toFixed(1) + "% of its original" : "";
    tooltip.innerHTML = `<strong>${esc(model)}</strong><div class="row"><span>${esc(series)}</span><span>${fmt(value)} parts</span></div>${share ? `<div class="row muted"><span>${esc(share)}</span></div>` : ""}`;
    tooltip.hidden = false;
    const r = el.getBoundingClientRect();
    tooltip.style.left = Math.min(window.innerWidth - 20, Math.max(20, r.left + r.width / 2)) + "px";
    tooltip.style.top = r.top + "px";
  }
  function hideTip() { tooltip.hidden = true; }

  // --- events ----------------------------------------------------------------
  document.addEventListener("click", e => {
    const go = e.target.closest("[data-go]");
    if (go) {
      e.preventDefault();
      if (!location.hash || location.hash === "#/") {
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else {
        location.hash = "#/";
      }
      return;
    }
    const scroll = e.target.closest("[data-scroll]");
    if (scroll) { e.preventDefault(); goSection(scroll.dataset.scroll); return; }
    const player = e.target.closest("[data-player]");
    if (player) { e.preventDefault(); openPlayer(player.dataset.player); return; }
    if (e.target.closest("[data-close-modal]")) { closeModal(); return; }
    const view = e.target.closest("[data-view]");
    if (view) {
      const key = location.hash.split("/").pop();
      const m = byKey(key);
      if (!m) return;
      document.querySelectorAll(".view-tab").forEach(t => t.setAttribute("aria-selected", String(t === view)));
      const img = document.getElementById("view-image");
      const label = view.dataset.view;
      if (label === "compare") {
        img.src = m.assets.compare;
        img.alt = m.title + " — original versus our build";
        document.getElementById("view-caption").textContent = "Original + our home / front / top views";
      } else {
        img.src = m.assets[label];
        img.alt = m.title + " — " + label + " render";
        document.getElementById("view-caption").textContent = label[0].toUpperCase() + label.slice(1) + " render · lego-nova three-view pass";
      }
    }
  });
  document.getElementById("theme-toggle").addEventListener("click", toggleTheme);
  document.addEventListener("keydown", e => {
    if (e.key === "Escape" && !document.getElementById("viewer-modal").hidden) closeModal();
  });
  document.addEventListener("mouseover", e => {
    const bar = e.target.closest(".bar[data-tip]");
    if (bar) showTip(bar, e);
  });
  document.addEventListener("mousemove", e => {
    const bar = e.target.closest(".bar[data-tip]");
    if (bar) showTip(bar, e); else hideTip();
  });
  document.addEventListener("mouseout", e => {
    if (e.target.closest(".bar[data-tip]")) hideTip();
  });
  window.addEventListener("hashchange", route);

  // Initial theme: only stamp when the user has an explicit preference; otherwise
  // let the prefers-color-scheme media query decide.
  const query = new URLSearchParams(location.search);
  const queryTheme = query.get("theme");
  if (queryTheme === "light" || queryTheme === "dark") document.documentElement.dataset.theme = queryTheme;
  const stored = localStorage.getItem("lego-nova-theme");
  if (!queryTheme && (stored === "light" || stored === "dark")) document.documentElement.dataset.theme = stored;
  const queryModel = query.get("model");
  if (queryModel && byKey(queryModel) && !location.hash) history.replaceState(null, "", "#/model/" + queryModel);

  route();

  // ?player=<key> opens the 3D modal directly, for demos and deep links.
  const queryPlayer = query.get("player");
  if (queryPlayer && byKey(queryPlayer)) setTimeout(() => openPlayer(queryPlayer), 80);
})();
