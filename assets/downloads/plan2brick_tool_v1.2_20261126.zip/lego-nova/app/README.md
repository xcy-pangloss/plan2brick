# Gallery-parity showcase

A static, no-build demo of the five gallery reconstructions in
`../out/gallery-parity/`. It is plain HTML/CSS/JS: the only generated file is
`data.js`, built from the frozen run artifacts.

## Launch

From the repository root:

```powershell
.\start-app.cmd
```

or, without opening a browser:

```powershell
.\.venv\Scripts\python.exe app\serve.py --port 8000
```

Then open <http://127.0.0.1:8000/app/>. Press Ctrl+C in the console to stop.

`serve.py` also serves the two endpoints the optional 3D player needs:

| Route | What it serves |
|---|---|
| `/ldraw/<path>` | the local LDraw library (`parts/`, `p/`, `models/`) |
| `/ldraw-id/<name>` | the same name resolved as LDraw does: `parts/`, then `p/`, then `models/`, with `X-LDraw-Folder` |

The LDraw root defaults to `C:\Users\XCY\Desktop\bricknet\ldraw\ldraw`.
Override it with `--ldraw PATH` or the `LDRAW_DIR` environment variable. If the
library is missing, the static showcase still works; the 3D player reports the
missing parts.

## Demo tour

1. **Overview** — five KPI tiles, the five build cards, the parts comparison,
   BOM overlap, the six-stage agent loop and the caveats panel.
2. **A model card** — home / front / top renders, the compare sheet, what the
   agent built and what it missed, validation exits, material overlap and every
   downloadable artifact.
3. **Open 3D build** — the actual `.mpd` in the vendored ldraw-player (WebGL2),
   opened at the finished build. Orbit with drag, zoom with the wheel, walk with
   the Walk camera.
4. **Read this before the demo** — the boundary between “the loop works” and
   “material parity is not solved”; useful if a supervisor asks what is proven.

## Deep links

| URL | Result |
|---|---|
| `?theme=dark` | dark theme (also available from the header toggle) |
| `?model=copper-bean` | opens that case study directly |
| `?player=copper-bean` | opens the 3D modal directly |

Model keys: `atlas-crane`, `cathedral`, `copper-bean`, `sakura-garden`,
`tidal-observatory`.

`screenshots/` holds the verification captures (light/dark overview, a case
study, the 3D player at step 1 and at the finished build, and a 600px narrow
layout) if a live browser is not available during the demo.

## Regenerating data.js

After a new parent verification pass:

```powershell
.\.venv\Scripts\python.exe app\build_data.py
```

It reads `out/gallery-parity/manifest.json`, `verify/summary.json`,
`bom-overlap.json` and each run's `verify/bom-comparison.json`, then writes
`data.js`. Curated wording (blurbs, feature/gap lists, durations, tokens) lives
in `build_data.py`; the numbers come from the artifacts.

## Files

| File | Role |
|---|---|
| `index.html` | shell, header, footer, modal, tooltip |
| `app.js` | overview / detail rendering, hash routing, tabs, theme, tooltips, 3D modal |
| `styles.css` | light and dark themes, charts, cards, responsive layout |
| `data.js` | generated metrics and asset paths (`window.GALLERY`) |
| `build_data.py` | artifact → `data.js` |
| `serve.py` | static server + LDraw resolver |
| `player.html` | vendored ldraw-player page (added `at=end` / `autoplay=1`) |
| `player-vendor/` | ldraw-player 0.8.1 JS + WASM (MIT) |

The showcase uses relative paths into `../out/gallery-parity/`, so keep the
`app/` and `out/` folders side by side. Opening `index.html` directly through
`file://` shows the charts, but the 3D player needs the HTTP server for its
WASM and part fetches.
