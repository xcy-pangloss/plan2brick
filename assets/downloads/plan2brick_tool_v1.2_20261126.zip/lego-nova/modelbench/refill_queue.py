"""Automatically refill the modelbench queue when it runs low.

Run this from a scheduled task (or manually) when the worker is alive.  It
keeps the prepaid Claude/GPT quota busy without touching the default library:

* if pending >= 120, do nothing;
* otherwise enqueue two more replication variants for asset_library (until
  max rep 60) and asset_plan (until max rep 30).

The plan command is idempotent: existing job hashes are not duplicated.
"""
from __future__ import annotations

import sqlite3
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CFG = ROOT / "modelbench" / "config.local.json"
DB = ROOT / "modelbench" / "state" / "queue.sqlite3"
LOW = 120
LIB_CAP = 60
PLAN_CAP = 30


def query(sql: str):
    con = sqlite3.connect(DB)
    try:
        return con.execute(sql).fetchone()[0]
    finally:
        con.close()


def pending() -> int:
    return int(query("select count(*) from jobs where status='pending'") or 0)


def max_rep(kind: str) -> int:
    return int(query(f"select coalesce(max(rep), -1) from jobs where kind='{kind}'") or -1)


def enqueue(kind: str, reps: int) -> None:
    cmd = [sys.executable, "-m", "modelbench", "plan",
           "--tasks", kind, "--models", "claude,gpt",
           "--reps", str(reps), "--config", str(CFG)]
    print("run:", " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=str(ROOT), check=False)


def main() -> int:
    n = pending()
    print(f"pending={n}", flush=True)
    if n >= LOW:
        print("queue above threshold; no refill", flush=True)
        return 0
    lib = max_rep("asset_library")
    plan = max_rep("asset_plan")
    print(f"max reps: asset_library={lib}, asset_plan={plan}", flush=True)
    if lib < LIB_CAP:
        enqueue("asset_library", lib + 3)  # adds two new rep values
    if plan < PLAN_CAP:
        enqueue("asset_plan", plan + 3)
    print(f"after: pending={pending()}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
