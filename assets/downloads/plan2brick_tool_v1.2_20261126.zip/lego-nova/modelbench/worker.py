"""Quota-aware scheduler.

The scheduler keeps at most ``concurrency`` requests in flight and reserves a
quota slot before each request.  When the quota is full it waits until the
oldest call leaves the window (sliding) or the next window opens (fixed), then
dispatches again.  A filler generator extends the replication tail whenever
the queue drops below a low watermark, so every quota window has work.

All database access is on the scheduler thread; worker threads only perform
HTTP calls and return results.
"""
from __future__ import annotations

import json
import logging
import threading
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from pathlib import Path

from . import scoring, tasks, transport
from .config import BenchConfig, ConfigError
from .store import Store

log = logging.getLogger("modelbench.worker")


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


class Worker:
    def __init__(self, cfg: BenchConfig, store: Store, models: list[str],
                 concurrency: int = 4, max_reps: int = 8,
                 low_watermark: int | None = None,
                 judge_run: str | Path | None = None, judge_pairs: int | None = None,
                 build: bool | None = None, auto_fill: bool = True,
                 pace_s: float = 0.0):
        self.cfg = cfg
        self.store = store
        self.models = list(models)
        self.concurrency = max(1, int(concurrency))
        self.max_reps = max(1, int(max_reps))
        self.low_watermark = int(low_watermark or max(cfg.quota.limit,
                                                      self.concurrency * 4))
        self.judge_run = judge_run
        self.judge_pairs = judge_pairs
        self.build = bool(cfg.defaults.get("build_llm_direct", True)) if build is None else build
        self.auto_fill = auto_fill
        self.pace_s = max(0.0, float(pace_s))
        self._next_dispatch = 0.0
        self.call_log = cfg.state_dir / "calls.log"
        self._filler_lock = threading.Lock()
        self._last_fill = 0.0
        self._stop = threading.Event()
        self._seen_errors: set[str] = set()

    # ------------------------------------------------------------------ run
    def run(self, max_calls: int | None = None, once: bool = False,
            idle_sleep: float = 10.0) -> dict:
        started = time.time()
        calls_made = 0
        inflight: dict = {}
        executor = ThreadPoolExecutor(max_workers=self.concurrency,
                                      thread_name_prefix="mb-call")
        self.store.reset_stale()
        try:
            while not self._stop.is_set():
                now = time.time()
                done = [f for f in inflight if f.done()]
                for fut in done:
                    job, call_id = inflight.pop(fut)
                    calls_made += 1
                    self._handle_future(fut, job, call_id)
                if max_calls is not None and calls_made >= max_calls and not inflight:
                    break
                # Keep the replication tail ahead of the queue: top up every
                # 30 s when pending falls below the low watermark, not only
                # when it reaches zero.
                if self.auto_fill:
                    self._ensure_filler(now)
                budget_left = (max_calls is None
                               or calls_made + len(inflight) < max_calls)
                if len(inflight) < self.concurrency and budget_left:
                    if self.pace_s > 0 and now < self._next_dispatch:
                        self._wait(inflight, min(self._next_dispatch - now, 5.0))
                        continue
                    job = self.store.pick_job(
                        {m: self.cfg.model(m).weight for m in self.models}, now=now)
                    if job is None:
                        inserted = self._ensure_filler(now)
                        if inserted:
                            continue
                        if not inflight:
                            if once:
                                break
                            time.sleep(idle_sleep)
                            continue
                    else:
                        call_id, next_slot, used = self.store.try_reserve(
                            job["id"], job["model"], now)
                        if call_id is None and not self.store.policy.separate(job["model"]):
                            # The paid-provider window is full; keep a
                            # separate-token backend (e.g. DeepSeek) moving.
                            alt = self.store.pick_exempt_job()
                            if alt is not None and alt["id"] != job["id"]:
                                a_call, a_slot, a_used = self.store.try_reserve(
                                    alt["id"], alt["model"], now)
                                if a_call is not None:
                                    job, call_id, next_slot, used = alt, a_call, a_slot, a_used
                        if call_id is not None:
                            self._next_dispatch = now + self.pace_s
                            fut = executor.submit(self._execute, job)
                            inflight[fut] = (job, call_id)
                            if max_calls is not None and calls_made + len(inflight) >= max_calls:
                                pass
                            continue
                        wait_s = max(0.0, next_slot - now)
                        if not inflight:
                            log.info("quota full: %d/%d used, next slot in %.0fs",
                                     used, self.cfg.quota.limit, wait_s)
                            self._sleep(wait_s)
                        else:
                            self._wait(inflight, min(wait_s, 5.0))
                        continue
                if inflight:
                    self._wait(inflight, 1.0)
                elif once:
                    break
                else:
                    time.sleep(1.0)
        finally:
            executor.shutdown(wait=True)
        return {"calls": calls_made,
                "seconds": round(time.time() - started, 2),
                "counts": self.store.counts()}

    def _wait(self, inflight: dict, timeout: float) -> None:
        if inflight:
            wait(list(inflight.keys()), timeout=timeout, return_when=FIRST_COMPLETED)
        else:
            time.sleep(max(0.0, timeout))

    def _sleep(self, seconds: float) -> None:
        end = time.time() + max(0.0, seconds)
        while time.time() < end and not self._stop.is_set():
            time.sleep(min(5.0, end - time.time()))

    # --------------------------------------------------------------- worker
    def _execute(self, job: dict) -> dict:
        payload = json.loads(job["payload"])
        kind = job["kind"]
        prompt, images = tasks.prompt_and_images(kind, payload)
        started = time.time()
        try:
            temperature = None
            if job.get("rep", 0) > 0:
                temperature = float(self.cfg.defaults.get("replication_temperature", 0.4))
            max_tokens = 4096 if kind in ("perception_compact", "raw_ldraw") else None
            res = transport.call_model(
                self.cfg, job["model"], prompt, images,
                temperature=temperature, max_output_tokens=max_tokens,
                mock_kind=("judge" if kind == "judge" else "ir"))
            return {"ok": True, "result": res, "prompt": prompt,
                    "elapsed": round(time.time() - started, 3)}
        except transport.TransportError as exc:
            return {"ok": False, "error": str(exc), "status": exc.status,
                    "retryable": exc.retryable, "release_slot": exc.release_slot,
                    "retry_after": exc.retry_after,
                    "reported_used": exc.reported_used,
                    "prompt": prompt, "elapsed": round(time.time() - started, 3)}
        except (ConfigError, FileNotFoundError) as exc:
            # No request reached the provider: do not spend a quota slot.
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}",
                    "status": None, "retryable": False, "release_slot": True,
                    "prompt": prompt, "elapsed": round(time.time() - started, 3)}
        except Exception as exc:  # keep the scheduler alive
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}",
                    "status": None, "retryable": True, "release_slot": False,
                    "prompt": prompt, "elapsed": round(time.time() - started, 3)}

    def _log_call(self, job: dict, payload: dict, status: str,
                  latency: float | None = None, usage: dict | None = None,
                  error: str | None = None) -> None:
        """Append one human-readable line per call (tail this file live)."""
        usage = usage or {}
        parts = [
            time.strftime("%Y-%m-%d %H:%M:%S"),
            f"{job.get('model','?'):8s}",
            f"{job.get('kind','?'):18s}",
            f"plan={payload.get('plan_id','-'):8s}",
            f"brief={payload.get('brief_id') or '-':4s}",
            f"rep={job.get('rep',0)}",
            f"status={status}",
        ]
        if latency is not None:
            parts.append(f"latency={float(latency):.1f}s")
        if usage.get("in") is not None or usage.get("out") is not None:
            parts.append(f"tok={usage.get('in')}/{usage.get('out')}")
        if error:
            parts.append("error=" + " ".join(str(error).split())[:300])
        try:
            self.call_log.parent.mkdir(parents=True, exist_ok=True)
            with self.call_log.open("a", encoding="utf-8") as fh:
                fh.write(" ".join(parts) + "\n")
        except OSError:
            pass

    def _handle_future(self, fut, job: dict, call_id: int) -> None:
        try:
            out = fut.result()
        except Exception as exc:  # should not happen; _execute catches
            out = {"ok": False, "error": f"{type(exc).__name__}: {exc}",
                   "retryable": True, "release_slot": False, "elapsed": 0}
        job_id = job["id"]
        payload = json.loads(job["payload"])
        if not out.get("ok"):
            err = out.get("error", "unknown error")
            released = bool(out.get("release_slot"))
            self.store.finish_call(call_id, "error", http_status=out.get("status"),
                                   latency_s=out.get("elapsed"), released=released)
            if released:
                self.store.release_call(call_id, "preflight")
            err_l = err.lower()
            if any(tag in err_l for tag in (
                    "connection error", "getaddrinfo", "timed out", "timeout",
                    "connection reset", "temporarily unavailable", "tls", "ssl",
                    "proxy")):
                # DNS/network failures are not model failures; pause shortly and
                # requeue without consuming an attempt (prevents retry storms
                # that previously killed 1k+ asset jobs).
                until = time.time() + 30.0
                self.store.set_network_block(until)
                self.store.requeue_without_attempt(job_id, err)
                log.warning("network/DNS failure; pausing dispatch for 30s: %s",
                            err[:200])
                self._log_call(job, payload, "network_error", out.get("elapsed"),
                               None, err)
                return
            if out.get("status") == 429:
                # The provider is authoritative: pause the whole worker until
                # the window recovers, and do not consume an attempt.  This
                # also covers quota used by interactive sessions on the same key.
                retry_after = float(out.get("retry_after") or 60.0)
                until = time.time() + max(5.0, retry_after)
                if not self.store.policy.separate(job["model"]):
                    self.store.set_quota_block(until, out.get("reported_used"))
                self.store.requeue_without_attempt(job_id, err)
                log.warning("429 quota exhausted; pausing dispatch until %s "
                            "(provider reports used=%s, model=%s)",
                            time.strftime("%H:%M:%S", time.localtime(until)),
                            out.get("reported_used"), job["model"])
                self._log_call(job, payload, "429", out.get("elapsed"), None, err)
                return
            status = self.store.fail_job(job_id, err,
                                         retryable=bool(out.get("retryable", True)))
            self._log_error(job, err, status)
            self._log_call(job, payload, status, out.get("elapsed"), None, err)
            return
        res: transport.CallResult = out["result"]
        text = res.text or ""
        self.store.finish_call(call_id, "ok", http_status=res.http_status,
                               latency_s=res.latency_s,
                               in_tokens=(res.usage or {}).get("in"),
                               out_tokens=(res.usage or {}).get("out"))
        if job["kind"] == "raw_ldraw":
            # Raw LDraw is not JSON; score the rendered LDraw text directly.
            rdir = self.cfg.out_dir / job_id
            rdir.mkdir(parents=True, exist_ok=True)
            (rdir / "prompt.txt").write_text(out.get("prompt", ""), encoding="utf-8")
            (rdir / "response.txt").write_text(text, encoding="utf-8")
            metrics = scoring.score_raw_ldraw(text, rdir)
            metrics.update({
                "usage": res.usage or {}, "latency_s": res.latency_s,
                "http_status": res.http_status,
                "prompt_hash": job.get("prompt_hash"),
                "model": job["model"], "kind": job["kind"],
                "plan_id": payload.get("plan_id"),
                "brief_id": payload.get("brief_id"),
                "rep": job.get("rep", 0), "scored_at": _now_iso(),
            })
            (rdir / "result.json").write_text(
                json.dumps({"job": {k: job.get(k) for k in
                                    ("id", "kind", "model", "rep", "priority",
                                     "prompt_hash")},
                            "payload": payload, "metrics": metrics,
                            "response_text": text}, ensure_ascii=False, indent=2),
                encoding="utf-8")
            self.store.finish_job(job_id, "done", metrics=metrics,
                                  result_path=str(rdir / "result.json"))
            self._log_call(job, payload, "ok", res.latency_s, res.usage)
            return
        parsed = scoring.extract_json(text)
        if parsed is None:
            self._save_attempt(job, out.get("prompt", ""), text, "json_parse")
            status = self.store.retry_job(job_id, "response is not a JSON object")
            self._log_error(job, "response is not a JSON object", status)
            self._log_call(job, payload, "parse_error", res.latency_s, res.usage,
                           "response is not a JSON object")
            return
        try:
            metrics = self._score(job, payload, parsed)
        except Exception as exc:
            status = self.store.retry_job(job_id, f"scoring error: {exc}")
            self._log_error(job, f"scoring error: {exc}", status)
            self._log_call(job, payload, "scoring_error", res.latency_s, res.usage,
                           str(exc))
            return
        metrics.update({
            "usage": res.usage or {},
            "latency_s": res.latency_s,
            "http_status": res.http_status,
            "prompt_hash": job.get("prompt_hash"),
            "model": job["model"],
            "kind": job["kind"],
            "plan_id": payload.get("plan_id"),
            "brief_id": payload.get("brief_id"),
            "rep": job.get("rep", 0),
            "scored_at": _now_iso(),
        })
        rdir = self.cfg.out_dir / job_id
        rdir.mkdir(parents=True, exist_ok=True)
        (rdir / "prompt.txt").write_text(out.get("prompt", ""), encoding="utf-8")
        (rdir / "response.txt").write_text(text, encoding="utf-8")
        (rdir / "result.json").write_text(
            json.dumps({"job": {k: job.get(k) for k in
                                ("id", "kind", "model", "rep", "priority", "prompt_hash")},
                        "payload": payload, "metrics": metrics,
                        "response_text": text}, ensure_ascii=False, indent=2),
            encoding="utf-8")
        self.store.finish_job(job_id, "done", metrics=metrics,
                              result_path=str(rdir / "result.json"))
        self._log_call(job, payload, "ok", res.latency_s, res.usage)

    def _score(self, job: dict, payload: dict, parsed: dict) -> dict:
        kind = job["kind"]
        errs, warns = (scoring.check_ir_obj(parsed)
                       if kind in ("perception", "perception_compact",
                                   "llm_direct", "asset_plan")
                       else ([], []))
        if kind in ("perception", "perception_compact"):
            plan = {
                "path": payload["gt_ir"], "gt_ir": payload["gt_ir"],
                "gt_rooms": payload.get("gt_rooms"),
                "gt_source": payload.get("gt_source"),
            }
            scores = scoring.score_perception(parsed, plan, errs, warns)
            if self.build and scores.get("schema_ok"):
                rdir = self.cfg.out_dir / job["id"]
                scores["build"] = scoring.build_prediction(parsed, job["id"], rdir)
            return scores
        if kind == "llm_direct":
            rdir = self.cfg.out_dir / job["id"] if self.build else None
            return scoring.score_llm_direct(parsed, payload, errs, warns,
                                            job["id"], rdir)
        if kind == "asset_plan":
            return scoring.score_asset_plan(parsed, payload, errs, warns,
                                            job["id"], self.cfg.out_dir / "assets")
        if kind == "asset_library":
            return scoring.score_asset_library(parsed, payload, job["id"],
                                               self.cfg.out_dir / "assets")
        if kind == "judge":
            return scoring.score_judge(parsed)
        return {"unknown_kind": kind}

    def _save_attempt(self, job: dict, prompt: str, text: str, tag: str) -> None:
        rdir = self.cfg.out_dir / job["id"]
        rdir.mkdir(parents=True, exist_ok=True)
        n = int(job.get("attempts", 0) or 0) + 1
        (rdir / f"attempt-{n}-{tag}.txt").write_text(
            f"PROMPT\n{prompt}\n\nRESPONSE\n{text}", encoding="utf-8")

    def _log_error(self, job: dict, error: str, status: str) -> None:
        key = f"{job['kind']}:{job['model']}:{status}:{error[:60]}"
        if key not in self._seen_errors:
            self._seen_errors.add(key)
            log.warning("[%s %s/%s] %s -> %s", job["id"][:8], job["kind"],
                        job["model"], error[:240], status)

    # --------------------------------------------------------------- filler
    def _ensure_filler(self, now: float) -> int:
        with self._filler_lock:
            if now - self._last_fill < 30:
                return 0
            self._last_fill = now
            pending = self.store.counts().get("pending", 0)
            if pending >= self.low_watermark:
                return 0
            inserted = 0
            pending_by_kind = self.store.counts_by_kind("pending")
            for kind in ("perception", "perception_compact", "llm_direct",
                         "asset_plan", "asset_library"):
                pending_kind = pending_by_kind.get(kind, 0)
                if pending_kind >= 20:
                    continue
                # Do not enqueue the entire corpus when only a small deficit
                # exists; cap the top-up to the watermark deficit.
                deficit = max(0, self.low_watermark - pending_kind)
                if deficit <= 0:
                    continue
                try:
                    specs, _skip = tasks.make_jobs(kind, self.cfg, self.models,
                                                   reps=self.max_reps)
                    if len(specs) > deficit:
                        specs = specs[:deficit]
                    new, _old = self.store.enqueue(specs)
                    inserted += new
                    pending_by_kind[kind] = pending_kind + new
                except Exception as exc:
                    log.warning("filler %s failed: %s", kind, exc)
            if inserted == 0 and self.judge_run:
                try:
                    specs, _skip = tasks.make_jobs("judge", self.cfg, self.models,
                                                   reps=1, judge_run=self.judge_run,
                                                   judge_pairs=self.judge_pairs)
                    new, _old = self.store.enqueue(specs)
                    inserted += new
                except Exception as exc:
                    log.warning("filler judge failed: %s", exc)
            if inserted:
                log.info("filler added %d jobs (pending was %d)", inserted, pending)
            return inserted

    def stop(self) -> None:
        self._stop.set()
