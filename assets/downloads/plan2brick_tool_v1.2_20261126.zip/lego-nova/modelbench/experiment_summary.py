"""Summarize the tool-vs-native-AI pilot into one markdown table.

- Arm A (raw LDraw) and DeepSeek B/P come from out_experiment/results.jsonl.
- Claude/GPT B are aggregated from the live modelbench llm_direct queue
  (same prompt, same plans/briefs, rep 0..7), because those calls were already
  running when the pilot was started.
"""
from __future__ import annotations

import json
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys_path = ROOT
import sys
sys.path.insert(0, str(sys_path))

from modelbench.quota import QuotaPolicy  # noqa: E402
from modelbench.store import Store  # noqa: E402

OUT = ROOT / "modelbench" / "out_experiment"
RESULTS = OUT / "results.jsonl"
CASES = {("R2", "B1"), ("R4", "B1"), ("R6", "B1"), ("R6", "B4")}


def load_results() -> list[dict]:
    out = []
    if RESULTS.exists():
        for line in RESULTS.read_text(encoding="utf-8").splitlines():
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return out


def b_from_queue() -> dict:
    s = Store(ROOT / "modelbench" / "state" / "queue.sqlite3",
              QuotaPolicy(150, 10800, "sliding"))
    groups = defaultdict(list)
    for j in s.jobs(kind="llm_direct"):
        p = json.loads(j["payload"])
        key = (p.get("plan_id"), p.get("brief_id"))
        if key in CASES and j["model"] in ("claude", "gpt") and j["status"] == "done":
            m = json.loads(j["metrics"] or "{}")
            b = m.get("build") or {}
            groups[(j["model"], key)].append({
                "cov": b.get("coverage_ratio"),
                "build": b.get("build_ok"),
                "brief": (m.get("brief_effect") or {}).get("ok"),
                "overlaps": b.get("overlaps"),
            })
    s.close()
    return groups


def mean(vals):
    vals = [v for v in vals if isinstance(v, (int, float))]
    return round(statistics.mean(vals), 3) if vals else None


def main() -> int:
    results = load_results()
    bq = b_from_queue()
    lines = ["# Tool vs native AI — pilot summary", "",
             "Controlled subset: R2-B1, R4-B1, R6-B1, R6-B4. "
             "Arm A = raw LDraw; B = LLM scene IR + deterministic builder; "
             "P = Plan2Brick deterministic (no model).", ""]
    # P
    p_rows = [r for r in results if r.get("arm") == "P"]
    p_cov = [r.get("coverage") for r in p_rows]
    p_brief = [bool((r.get("brief_effect") or {}).get("ok")) for r in p_rows]
    lines += ["## Plan2Brick (P, deterministic)", "",
              "| case | build | coverage | overlaps | brief |",
              "|---|---|---:|---:|---|"]
    for r in p_rows:
        b = r.get("brief_effect") or {}
        lines.append(f"| {r['case']} | {r.get('build_ok')} | {r.get('coverage')} "
                     f"| {r.get('overlaps')} | {b.get('ok')} |")
    lines += ["", f"- build: **{sum(1 for r in p_rows if r.get('build_ok'))}/{len(p_rows)}**; "
              f"mean coverage **{mean(p_cov)}**; brief **{sum(p_brief)}/{len(p_brief)}**; "
              f"0 model calls, 0 tokens.", ""]
    # B deepseek from results, claude/gpt from queue
    lines += ["## Arm B — AI scene IR + deterministic builder", "",
              "| model | reps | build | mean coverage | brief effect | mean overlaps |",
              "|---|---:|---:|---:|---:|---:|"]
    ds_b = [r for r in results if r.get("arm") == "B" and r.get("model") == "deepseek"]
    if ds_b:
        lines.append(f"| deepseek | {len(ds_b)} | "
                     f"{sum(1 for r in ds_b if r.get('build_ok'))}/{len(ds_b)} | "
                     f"{mean([r.get('coverage') for r in ds_b])} | "
                     f"{sum(1 for r in ds_b if (r.get('brief_effect') or {}).get('ok'))}/{len(ds_b)} | "
                     f"{mean([r.get('overlaps') for r in ds_b])} |")
    for model in ("claude", "gpt"):
        rows = [x for (m, _k), vals in bq.items() if m == model for x in vals]
        if rows:
            lines.append(f"| {model} | {len(rows)} | "
                         f"{sum(1 for x in rows if x['build'])}/{len(rows)} | "
                         f"{mean([x['cov'] for x in rows])} | "
                         f"{sum(1 for x in rows if x['brief'])}/{len(rows)} | "
                         f"{mean([x['overlaps'] for x in rows])} |")
    lines += ["", "B4 (`Use the dining room as a study`) is the failure mode: "
              "all three model families fail the room-type assertion, while P passes "
              "it deterministically. B1 (`Add a desk to the living room`) passes in all arms.", ""]
    # A
    a_rows = [r for r in results if r.get("arm") == "A"]
    lines += ["## Arm A — raw LDraw generation", "",
              "| model | attempts | valid LDraw | status |",
              "|---|---:|---:|---|"]
    for model in ("deepseek", "claude", "gpt"):
        rows = [r for r in a_rows if r.get("model") == model]
        if not rows:
            continue
        valid = sum(1 for r in rows if r.get("valid"))
        status = ", ".join(sorted({str(r.get("status")) for r in rows}))
        lines.append(f"| {model} | {len(rows)} | {valid}/{len(rows)} | {status} |")
    lines += ["", "DeepSeek raw attempts returned empty content after consuming the "
              "full 8192-token output budget; Claude R2 returned upstream HTTP 500 "
              "after ~8 minutes. GPT raw was not completed because the shared quota "
              "window was exhausted; B/P GPT results are complete.", ""]
    lines += ["## Reading", "",
              "- Raw LDraw (A) is not usable in one shot: empty/truncated output or "
              "provider failure; no model produced a valid model.",
              "- AI planning + our builder (B) is buildable, but model planning loses "
              "coverage and fails room-programme replacement (B4) in every family.",
              "- The deterministic tool (P) is buildable, has the best coverage, passes "
              "all briefs, 0 overlaps, and uses 0 model calls/tokens.",
              "- Caveat: B already uses the deterministic builder; it is the *best case* "
              "for AI + furniture parts, not a fully free-form placement baseline. "
              "A is the fully raw baseline. The subset is a 4-cell pilot, not the final "
              "18-plan benchmark.", ""]
    (OUT / "SUMMARY.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"wrote {OUT / 'SUMMARY.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
