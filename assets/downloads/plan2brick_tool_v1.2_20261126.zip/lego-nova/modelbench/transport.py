"""Provider transports for the multi-model comparison.

Three wire protocols are implemented with the standard library only:

``openai``     OpenAI-compatible ``/chat/completions`` (covers most relay
               vendors that expose Claude/GPT/Gemini behind one endpoint).
``anthropic``  Anthropic Messages API.
``gemini``     Google Generative Language ``generateContent``.
``mock``       deterministic local output for tests and dry runs.

Images are sent as base64 data; oversized images are downscaled with Pillow
when available.  API keys are read from the environment by ``BenchConfig`` and
are never logged or written to disk.
"""
from __future__ import annotations

import base64
import io
import json
import mimetypes
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

from .config import BenchConfig, ModelConfig, ProviderConfig

MOCK_IR = {
    "source": "mock",
    "image_type": "floorplan",
    "rooms": [
        {"name_cn": "客厅", "name_en": "Living room", "dims_m": [4.0, 3.0],
         "notes": "mock"},
    ],
    "objects": [
        {"category": "sofa", "label": "sofa", "count": 1, "room": "客厅",
         "size_est_m": [2.0, 1.0, 0.8], "placement": "against wall", "confidence": 0.5},
        {"category": "table", "label": "coffee table", "count": 1, "room": "客厅",
         "size_est_m": [1.0, 0.6, 0.4], "placement": "center", "confidence": 0.5},
    ],
    "uncertain": [],
    "notes": "mock transport output",
}


@dataclass
class CallResult:
    text: str
    usage: dict = field(default_factory=dict)
    latency_s: float = 0.0
    http_status: int | None = None
    raw: dict | None = None


class TransportError(RuntimeError):
    def __init__(self, message: str, status: int | None = None,
                 retryable: bool = True, release_slot: bool = False,
                 body: str = "", retry_after: float | None = None,
                 reported_used: int | None = None):
        super().__init__(message)
        self.status = status
        self.retryable = retryable
        self.release_slot = release_slot
        self.body = body
        self.retry_after = retry_after
        self.reported_used = reported_used


def _retry_hint(raw: str, headers) -> tuple[float | None, int | None]:
    """Parse Retry-After and the provider's Chinese rate-limit message."""
    retry_after = None
    try:
        hdr = headers.get("Retry-After") if headers else None
        if hdr:
            retry_after = float(hdr)
    except (TypeError, ValueError):
        pass
    if retry_after is None:
        m = re.search(r"预计\s*(\d+)\s*分钟后", raw)
        if m:
            retry_after = int(m.group(1)) * 60.0
        else:
            m = re.search(r"(\d+)\s*分钟后", raw)
            if m:
                retry_after = int(m.group(1)) * 60.0
    used = None
    m = re.search(r"已使用\s*(\d+)\s*次", raw)
    if m:
        used = int(m.group(1))
    return retry_after, used


def _json_request(url: str, headers: dict, body: dict, timeout: float) -> tuple[dict, int]:
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    for k, v in headers.items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = resp.read()
            return json.loads(payload.decode("utf-8")), resp.status
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")[:4000]
        retryable = exc.code == 429 or 500 <= exc.code < 600
        release = exc.code == 429
        retry_after, reported_used = _retry_hint(raw, exc.headers)
        raise TransportError(
            f"HTTP {exc.code}: {raw[:500]}", status=exc.code,
            retryable=retryable, release_slot=release, body=raw,
            retry_after=retry_after, reported_used=reported_used) from exc
    except urllib.error.URLError as exc:
        raise TransportError(f"connection error: {exc.reason}", retryable=True,
                             release_slot=True) from exc
    except TimeoutError as exc:
        raise TransportError(f"timeout: {exc}", retryable=True) from exc
    except json.JSONDecodeError as exc:
        raise TransportError(f"invalid JSON response: {exc}", retryable=True) from exc


def _usage(data: dict) -> dict:
    u = data.get("usage") or data.get("usageMetadata") or {}
    in_tok = u.get("prompt_tokens", u.get("input_tokens", u.get("promptTokenCount")))
    out_tok = u.get("completion_tokens", u.get("output_tokens", u.get("candidatesTokenCount")))
    return {"in": in_tok, "out": out_tok}


def _content_text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                if item.get("type") in (None, "text", "output_text"):
                    parts.append(str(item.get("text", "")))
        return "".join(parts)
    return str(content or "")


def encode_image(path: str | Path, max_side: int = 1800, quality: int = 90) -> tuple[str, str]:
    """Return ``(mime, base64)`` for an image, downscaling if Pillow is present."""
    p = Path(path)
    raw = p.read_bytes()
    mime = mimetypes.guess_type(p.name)[0] or "image/png"
    try:
        from PIL import Image
    except ImportError:
        return mime, base64.b64encode(raw).decode("ascii")
    try:
        im = Image.open(io.BytesIO(raw))
        im.load()
        if im.mode not in ("RGB", "L"):
            im = im.convert("RGB")
        if max(im.size) > max_side:
            im.thumbnail((max_side, max_side), Image.Resampling.LANCZOS)
        buf = io.BytesIO()
        # JPEG for photos/webp, PNG for small diagrams (text stays crisp).
        if p.suffix.lower() == ".png" and len(raw) < 1_500_000:
            im.save(buf, format="PNG", optimize=True)
            mime = "image/png"
        else:
            im.convert("RGB").save(buf, format="JPEG", quality=quality, optimize=True)
            mime = "image/jpeg"
        return mime, base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception:
        return mime, base64.b64encode(raw).decode("ascii")


def _openai_payload(model: ModelConfig, provider: ProviderConfig, prompt: str,
                    images: list[tuple[str, str]], system: str | None,
                    temperature: float | None, max_tokens: int) -> dict:
    content: list[dict] = [{"type": "text", "text": prompt}]
    for mime, b64 in images:
        content.append({"type": "image_url",
                        "image_url": {"url": f"data:{mime};base64,{b64}"}})
    messages = []
    if system and provider.supports_system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": content})
    body = {"model": model.model, "messages": messages,
            (model.max_tokens_field or provider.max_tokens_field): max_tokens}
    if temperature is not None:
        body["temperature"] = temperature
    return body


def _anthropic_payload(model: ModelConfig, prompt: str,
                       images: list[tuple[str, str]], system: str | None,
                       temperature: float | None, max_tokens: int) -> dict:
    content: list[dict] = [{"type": "text", "text": prompt}]
    for mime, b64 in images:
        content.append({"type": "image",
                        "source": {"type": "base64", "media_type": mime, "data": b64}})
    body = {"model": model.model, "max_tokens": max_tokens,
            "messages": [{"role": "user", "content": content}]}
    if temperature is not None:
        body["temperature"] = temperature
    if system:
        body["system"] = system
    return body


def _gemini_payload(prompt: str, images: list[tuple[str, str]],
                    system: str | None, temperature: float | None, max_tokens: int) -> dict:
    parts: list[dict] = [{"text": prompt}]
    for mime, b64 in images:
        parts.append({"inline_data": {"mime_type": mime, "data": b64}})
    gen = {"maxOutputTokens": max_tokens}
    if temperature is not None:
        gen["temperature"] = temperature
    body = {"contents": [{"role": "user", "parts": parts}],
            "generationConfig": gen}
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    return body


def call_model(cfg: BenchConfig, model_name: str, prompt: str,
               image_paths: list[str | Path] | None = None,
               system: str | None = None, temperature: float | None = None,
               max_output_tokens: int | None = None, mock_kind: str = "ir") -> CallResult:
    model = cfg.model(model_name)
    provider = cfg.provider(model.provider)
    temperature = model.temperature if temperature is None else temperature
    max_tokens = model.max_output_tokens if max_output_tokens is None else max_output_tokens
    images = []
    if image_paths:
        if not model.vision:
            raise TransportError(
                f"model {model_name} is configured vision=false but the task has images",
                retryable=False)
        for p in image_paths:
            images.append(encode_image(p, max_side=int(cfg.defaults.get("perception_max_side", 1800)),
                                       quality=int(cfg.defaults.get("perception_jpeg_quality", 90))))
    started = time.time()
    if provider.protocol == "mock":
        if mock_kind == "judge":
            text = json.dumps({"winner": "A", "criteria": {"mock": True},
                               "rationale": "mock transport"}, ensure_ascii=False)
        else:
            text = json.dumps(MOCK_IR, ensure_ascii=False)
        return CallResult(text=text, usage={"in": 0, "out": 0},
                          latency_s=round(time.time() - started, 3), http_status=200,
                          raw={"mock": True})
    key = cfg.api_key(model.provider)
    try:
        if provider.protocol == "openai":
            base = provider.base_url.rstrip("/")
            if base.endswith("/chat/completions"):
                url = base
            elif base.endswith("/v1"):
                url = base + "/chat/completions"
            else:
                url = base + "/v1/chat/completions"
            headers = {"Authorization": f"Bearer {key}"}
            headers.update(provider.extra_headers)
            data, status = _json_request(
                url, headers,
                _openai_payload(model, provider, prompt, images, system,
                                temperature, max_tokens),
                provider.timeout_s)
            try:
                msg = data["choices"][0]["message"]
                text = _content_text(msg.get("content"))
                if not text:
                    text = str(msg.get("reasoning_content") or "")
            except (KeyError, IndexError, TypeError) as exc:
                raise TransportError(f"unexpected OpenAI response: {str(data)[:500]}",
                                     retryable=True) from exc
        elif provider.protocol == "anthropic":
            base = provider.base_url.rstrip("/")
            if base.endswith("/messages"):
                url = base
            elif base.endswith("/v1"):
                url = base + "/messages"
            else:
                url = base + "/v1/messages"
            headers = {"x-api-key": key, "anthropic-version": provider.api_version}
            headers.update(provider.extra_headers)
            data, status = _json_request(
                url, headers,
                _anthropic_payload(model, prompt, images, system, temperature, max_tokens),
                provider.timeout_s)
            blocks = data.get("content") or []
            text = "".join(str(b.get("text", "")) for b in blocks
                           if isinstance(b, dict) and b.get("type") == "text")
        elif provider.protocol == "gemini":
            base = provider.base_url.rstrip("/")
            if base.endswith("/v1beta"):
                url = f"{base}/models/{model.model}:generateContent?key={key}"
            else:
                url = f"{base}/v1beta/models/{model.model}:generateContent?key={key}"
            headers = dict(provider.extra_headers)
            data, status = _json_request(
                url, headers,
                _gemini_payload(prompt, images, system, temperature, max_tokens),
                provider.timeout_s)
            try:
                cands = data["candidates"][0]["content"]["parts"]
                text = "".join(str(p.get("text", "")) for p in cands)
            except (KeyError, IndexError, TypeError) as exc:
                raise TransportError(f"unexpected Gemini response: {str(data)[:500]}",
                                     retryable=True) from exc
        else:  # pragma: no cover - config validates this
            raise TransportError(f"unsupported protocol {provider.protocol}", retryable=False)
    except TransportError:
        raise
    except Exception as exc:  # urllib wrappers should have caught these
        raise TransportError(f"{type(exc).__name__}: {exc}", retryable=True) from exc
    return CallResult(text=text, usage=_usage(data),
                      latency_s=round(time.time() - started, 3),
                      http_status=status, raw=data)
