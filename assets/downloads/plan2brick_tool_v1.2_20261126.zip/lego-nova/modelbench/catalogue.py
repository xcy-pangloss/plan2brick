"""Plan catalogue and image/GT mapping for the model comparison.

The 18-plan benchmark catalogue is reused unchanged.  Perception jobs use the
12 plans that have a source image; R4-R9 are the manual transcriptions added on
2026-11-04, and their source images live in the download-candidate batch.

Ground truth is labelled honestly:

* R4-R9: manual transcription (rooms, dims and objects all human-read).
* R1-R3: room dimensions from the hand-read `*_gt.json`; objects from the
  previously cached M2 flash IR (not human object GT).
* A/B/C: cached M2 flash IR for both rooms and objects.
"""
from __future__ import annotations

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
NOVA = HERE.parent
ROOT = NOVA.parent

PLANS_FILE = NOVA / "bench" / "plans_v13.json"
BRIEFS_FILE = NOVA / "bench" / "briefs.json"

IMAGE_PLANS = {
    "R1": {
        "image": "fyp-pipeline/inputs/real/floorplan_R1.png",
        "gt_rooms": "fyp-pipeline/inputs/real/R1_gt.json",
        "gt_ir": "fyp-pipeline/examples/floorplan_R1_img_flash.json",
        "gt_source": "rooms_manual_objects_cached_m2",
    },
    "R2": {
        "image": "fyp-pipeline/inputs/real/floorplan_R2.png",
        "gt_rooms": "fyp-pipeline/inputs/real/R2_gt.json",
        "gt_ir": "fyp-pipeline/examples/floorplan_R2_img_flash.json",
        "gt_source": "rooms_manual_objects_cached_m2",
    },
    "R3": {
        "image": "fyp-pipeline/inputs/real/floorplan_R3.png",
        "gt_rooms": "fyp-pipeline/inputs/real/R3_gt.json",
        "gt_ir": "fyp-pipeline/examples/floorplan_R3_img_flash.json",
        "gt_source": "rooms_manual_objects_cached_m2",
    },
    "R4": {
        "image": "fyp-pipeline/inputs/real/candidates_1104/q1_03_1390e6ffb4ac.jpeg",
        "gt_ir": "fyp-pipeline/examples/floorplan_R4_txt_manual.json",
        "gt_source": "manual",
    },
    "R5": {
        "image": "fyp-pipeline/inputs/real/candidates_1104/q0_03_e48e977b0e43.jpeg",
        "gt_ir": "fyp-pipeline/examples/floorplan_R5_txt_manual.json",
        "gt_source": "manual",
    },
    "R6": {
        "image": "fyp-pipeline/inputs/real/candidates_1104/q0_00_abda8a743d05.webp",
        "gt_ir": "fyp-pipeline/examples/floorplan_R6_txt_manual.json",
        "gt_source": "manual",
    },
    "R7": {
        "image": "fyp-pipeline/inputs/real/candidates_1104/q1_04_1b7b437d3930.jpeg",
        "gt_ir": "fyp-pipeline/examples/floorplan_R7_txt_manual.json",
        "gt_source": "manual",
    },
    "R8": {
        "image": "fyp-pipeline/inputs/real/candidates_1104/q1_05_c03f75e04951.webp",
        "gt_ir": "fyp-pipeline/examples/floorplan_R8_txt_manual.json",
        "gt_source": "manual",
    },
    "R9": {
        "image": "fyp-pipeline/inputs/real/candidates_1104/q1_01_b940da6a942c.webp",
        "gt_ir": "fyp-pipeline/examples/floorplan_R9_txt_manual.json",
        "gt_source": "manual",
    },
    "A": {
        "image": "fyp-pipeline/inputs/floorplan_synth.png",
        "gt_ir": "fyp-pipeline/examples/floorplan_flash_v11.json",
        "gt_source": "cached_m2",
    },
    "B": {
        "image": "fyp-pipeline/inputs/floorplan_B.png",
        "gt_ir": "fyp-pipeline/examples/floorplan_B_flash.json",
        "gt_source": "cached_m2",
    },
    "C": {
        "image": "fyp-pipeline/inputs/floorplan_C.png",
        "gt_ir": "fyp-pipeline/examples/floorplan_C_flash.json",
        "gt_source": "cached_m2",
    },
}


def _abs(rel: str) -> Path:
    p = Path(rel)
    return p if p.is_absolute() else (ROOT / p)


def load_plans(only_images: bool = True) -> list[dict]:
    data = json.loads(PLANS_FILE.read_text(encoding="utf-8"))
    plans = []
    for p in data["plans"]:
        entry = dict(p)
        entry["path"] = str(_abs(p["path"]))
        img = IMAGE_PLANS.get(p["id"])
        if only_images and not img:
            continue
        if img:
            entry["image"] = str(_abs(img["image"]))
            entry["gt_ir"] = str(_abs(img["gt_ir"]))
            entry["gt_rooms"] = str(_abs(img["gt_rooms"])) if img.get("gt_rooms") else None
            entry["gt_source"] = img["gt_source"]
        plans.append(entry)
    return plans


def load_all_plans() -> list[dict]:
    data = json.loads(PLANS_FILE.read_text(encoding="utf-8"))
    out = []
    for p in data["plans"]:
        entry = dict(p)
        entry["path"] = str(_abs(p["path"]))
        out.append(entry)
    return out


def load_briefs() -> list[dict]:
    return json.loads(BRIEFS_FILE.read_text(encoding="utf-8"))["briefs"]


def load_plan_ir(plan: dict) -> dict:
    return json.loads(Path(plan["path"]).read_text(encoding="utf-8"))


def _to_metres(w: float, h: float) -> list[float]:
    """The R1-R3 hand-read GT stores millimetres; manual IRs store metres."""
    if max(abs(w), abs(h)) > 100:
        return [w / 1000.0, h / 1000.0]
    return [w, h]


def load_gt_rooms(plan: dict) -> list[dict]:
    """Return [{'name': ..., 'dims': [w,d] | None}] for the plan's room GT."""
    if plan.get("gt_rooms"):
        data = json.loads(Path(plan["gt_rooms"]).read_text(encoding="utf-8"))
        out = []
        for name, value in (data.get("rooms") or {}).items():
            if value is None:
                out.append({"name": name, "dims": None})
            elif isinstance(value[0], (int, float)):
                out.append({"name": name, "dims": _to_metres(float(value[0]), float(value[1]))})
            else:
                for dims in value:
                    out.append({"name": name,
                                "dims": _to_metres(float(dims[0]), float(dims[1]))})
        return out
    ir = load_plan_ir(plan)
    out = []
    for r in ir.get("rooms") or []:
        dims = r.get("dims_m")
        out.append({
            "name": r.get("name_cn") or r.get("name_en") or "",
            "name_en": r.get("name_en"),
            "dims": [float(dims[0]), float(dims[1])] if dims and len(dims) >= 2 else None,
        })
    return out


def validate_images(plans: list[dict]) -> list[str]:
    missing = []
    for p in plans:
        for key in ("image", "gt_ir", "gt_rooms"):
            path = p.get(key)
            if path and not Path(path).exists():
                missing.append(f"{p['id']}:{key}:{path}")
    return missing
