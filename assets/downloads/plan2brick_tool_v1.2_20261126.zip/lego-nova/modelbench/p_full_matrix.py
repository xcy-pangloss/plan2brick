"""Run the deterministic Plan2Brick arm (P) over the full 18-plan x 4-brief matrix.

No model calls and no quota.  This is the reliability reference for the
tool-vs-native-AI argument: same standard programme + brief patch + deterministic
solver/assembly as the 4-cell pilot, but over every applicable cell.
"""
from __future__ import annotations

import json
import statistics
import sys
import time
from collections import Counter
from pathlib import Path

NOVA = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NOVA))

from modelbench import catalogue, tool_vs_ai  # noqa: E402

OUT = NOVA / "modelbench" / "out_experiment" / "p_full_matrix"


def log(msg: str) -> None:
    print(f"{time.strftime('%H:%M:%S')} {msg}", flush=True)


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    plans = catalogue.load_all_plans()
    briefs = catalogue.load_briefs()
    rows = []
    for plan in plans:
        for brf in briefs:
            cid = f"{plan['id']}_{brf['id']}"
            try:
                m = tool_vs_ai.run_arm_p(plan, brf, OUT / cid)
                rows.append({"case": cid, "plan": plan["id"],
                             "brief": brf["id"], "provenance": plan.get("provenance"),
                             "topology": plan.get("topology"), **m})
                log(f"{cid}: {m.get('status')} build={m.get('build_ok')} "
                    f"cov={m.get('coverage')}")
            except Exception as exc:
                rows.append({"case": cid, "plan": plan["id"], "brief": brf["id"],
                             "status": "exception", "error": f"{type(exc).__name__}: {exc}",
                             "build_ok": False})
                log(f"{cid}: EXCEPTION {exc}")
    (OUT / "results.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2),
                                      encoding="utf-8")
    ran = [r for r in rows if r.get("status") == "ok"]
    skipped = [r for r in rows if r.get("status") == "not_applicable"]
    build = sum(1 for r in ran if r.get("build_ok"))
    brief = sum(1 for r in ran if (r.get("brief_effect") or {}).get("ok"))
    cov = [r.get("coverage") for r in ran if isinstance(r.get("coverage"), (int, float))]
    overlaps = sum(int(r.get("overlaps") or 0) for r in ran)
    lines = ["# Plan2Brick deterministic arm — full matrix", "",
             f"- cells: {len(rows)}; ran: {len(ran)}; not applicable: {len(skipped)}; exceptions: {len(rows)-len(ran)-len(skipped)}",
             f"- build success: **{build}/{len(ran)}**",
             f"- brief effect: **{brief}/{len(ran)}**",
             f"- mean coverage: **{round(statistics.mean(cov), 4) if cov else None}**",
             f"- total overlap errors: **{overlaps}**",
             "", "| provenance | cells | build | brief | mean coverage |", "|---|---:|---:|---:|---:|"]
    by = {}
    for r in ran:
        by.setdefault(r.get("provenance"), []).append(r)
    for prov, vals in sorted(by.items()):
        vc = [v.get("coverage") for v in vals if isinstance(v.get("coverage"), (int, float))]
        lines.append(f"| {prov} | {len(vals)} | "
                     f"{sum(1 for v in vals if v.get('build_ok'))}/{len(vals)} | "
                     f"{sum(1 for v in vals if (v.get('brief_effect') or {}).get('ok'))}/{len(vals)} | "
                     f"{round(statistics.mean(vc), 4) if vc else None} |")
    lines += ["", "| case | build | coverage | overlaps | brief |", "|---|---|---:|---:|---|"]
    for r in ran:
        b = r.get("brief_effect") or {}
        lines.append(f"| {r['case']} | {r.get('build_ok')} | {r.get('coverage')} "
                     f"| {r.get('overlaps')} | {b.get('ok')} |")
    lines.append("")
    (OUT / "SUMMARY.md").write_text("\n".join(lines), encoding="utf-8")
    log(f"wrote {OUT / 'SUMMARY.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
