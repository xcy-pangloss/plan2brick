"""Status display and model-comparison report."""
from __future__ import annotations

import json
import time
from collections import defaultdict
from pathlib import Path

from .config import BenchConfig
from .store import Store

PERCEPTION_METRICS = [
    ("room_recall", "higher"),
    ("dims_mae_m", "lower"),
    ("object_f1", "higher"),
    ("build.coverage_ratio", "higher"),
    ("build.overlaps", "lower"),
]
DIRECT_METRICS = [
    ("brief_effect.ok", "higher"),
    ("room_recall", "higher"),
    ("dims_mae_m", "lower"),
    ("build.coverage_ratio", "higher"),
    ("build.overlaps", "lower"),
]


def _get(m: dict, dotted: str):
    cur = m
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def _num(v):
    if isinstance(v, bool):
        return 1.0 if v else 0.0
    return float(v) if isinstance(v, (int, float)) else None


def _mean(vals):
    vals = [v for v in vals if v is not None]
    return round(sum(vals) / len(vals), 4) if vals else None


def _rate(vals):
    vals = [bool(v) for v in vals if v is not None]
    return round(sum(vals) / len(vals), 4) if vals else None


def status_text(store: Store, cfg: BenchConfig | None = None) -> str:
    q = store.quota_status()
    c = store.counts()
    pm = store.counts_by_model()
    pk = store.counts_by_kind()
    next_s = max(0, int(q["next_slot"] - time.time()))
    lines = [
        f"Quota : {q['mode']} {q['window_hours']:.2f} h | used {q['used']}/{q['limit']} "
        f"({q['utilization']*100:.1f}%) | next slot in {next_s}s",
    ]
    if q.get("blocked_until"):
        resume = time.strftime("%H:%M:%S", time.localtime(q["blocked_until"]))
        lines.append(
            f"Blocked: provider quota exhausted (reported used={q.get('reported_used') or '?'}); "
            f"resume at {resume} (in {next_s}s)")
    if q.get("network_blocked_until"):
        resume = time.strftime("%H:%M:%S", time.localtime(q["network_blocked_until"]))
        lines.append(f"Network: DNS/connection cooldown; resume at {resume}")
    for name, w in (q.get("model_windows") or {}).items():
        nxt = max(0, int(w.get("next_slot", time.time()) - time.time()))
        lines.append(f"Quota[{name}]: {w['used']}/{w['limit']} in "
                     f"{w['window_hours']:.2f} h | next slot in {nxt}s")
    lines += [
        f"Queue : pending {c['pending']} "
        f"({', '.join(f'{k} {v}' for k, v in sorted(pm.items())) or '-'}) "
        f"| running {c['running']} | done {c['done']} | dead {c['dead']}",
        f"Tasks : " + (", ".join(f"{k} {v}" for k, v in sorted(pk.items())) or "-"),
    ]
    hist = store.history(buckets=8)
    lines.append("Windows: " + " ".join(
        f"[{h['used']}/{h['limit']}]" + ("*" if h["current"] else "")
        for h in hist))
    if c["pending"]:
        rate_per_h = q["limit"] / max(q["window_hours"], 1e-9)
        eta_h = c["pending"] / rate_per_h
        lines.append(f"ETA   : {eta_h:.1f} h at full rate "
                     f"({eta_h / max(q['window_hours'], 1e-9):.1f} windows, "
                     f"{c['pending']} pending)")
    return "\n".join(lines)


def _done(store: Store) -> list[dict]:
    out = []
    for job in store.done_jobs():
        try:
            m = json.loads(job.get("metrics") or "{}")
        except json.JSONDecodeError:
            m = {}
        out.append({"job": job, "m": m})
    return out


def _perception_metrics(items: list[dict]) -> dict:
    return {
        "json_ok": _rate([it.get("json_ok") for it in items]),
        "schema_ok": _rate([it.get("schema_ok") for it in items]),
        "image_type_ok": _rate([it.get("image_type_ok") for it in items]),
        "room_recall": _mean([_num(it.get("room_recall")) for it in items]),
        "room_precision": _mean([_num(it.get("room_precision")) for it in items]),
        "dims_mae_m": _mean([_num(it.get("dims_mae_m")) for it in items]),
        "area_mae_m2": _mean([_num(it.get("area_mae_m2")) for it in items]),
        "object_f1": _mean([_num(it.get("object_f1")) for it in items]),
        "object_set_f1": _mean([_num(it.get("object_set_f1")) for it in items]),
        "build_ok": _rate([_get(it, "build.build_ok") for it in items]),
        "coverage": _mean([_num(_get(it, "build.coverage_ratio")) for it in items]),
        "overlaps": _mean([_num(_get(it, "build.overlaps")) for it in items]),
    }


def build_report(store: Store, cfg: BenchConfig | None = None) -> dict:
    rows = _done(store)
    counts = store.counts()
    q = store.quota_status()
    by_model_kind = defaultdict(list)
    for r in rows:
        by_model_kind[(r["m"].get("model") or r["job"]["model"],
                       r["m"].get("kind") or r["job"]["kind"])].append(r["m"])

    summary = {}
    for (model, kind), items in sorted(by_model_kind.items()):
        entry = {"n": len(items)}
        if kind in ("perception", "perception_compact"):
            entry.update(_perception_metrics(items))
            groups = defaultdict(list)
            for it in items:
                groups[it.get("gt_source") or "unknown"].append(it)
            entry["by_gt_source"] = {
                src: {"n": len(vals), **_perception_metrics(vals)}
                for src, vals in sorted(groups.items())
            }
        elif kind == "llm_direct":
            entry.update({
                "json_ok": _rate([it.get("json_ok") for it in items]),
                "schema_ok": _rate([it.get("schema_ok") for it in items]),
                "brief_effect": _rate([_get(it, "brief_effect.ok") for it in items]),
                "room_recall": _mean([_num(it.get("room_recall")) for it in items]),
                "room_precision": _mean([_num(it.get("room_precision")) for it in items]),
                "dims_mae_m": _mean([_num(it.get("dims_mae_m")) for it in items]),
                "object_total": _mean([_num(it.get("object_total")) for it in items]),
                "build_ok": _rate([_get(it, "build.build_ok") for it in items]),
                "coverage": _mean([_num(_get(it, "build.coverage_ratio")) for it in items]),
                "overlaps": _mean([_num(_get(it, "build.overlaps")) for it in items]),
            })
        elif kind == "judge":
            winners = [it.get("winner") for it in items if it.get("valid_winner")]
            entry.update({
                "json_ok": _rate([it.get("json_ok") for it in items]),
                "valid_winner": _rate([it.get("valid_winner") for it in items]),
                "A": winners.count("A"), "B": winners.count("B"),
                "tie": winners.count("tie"),
            })
        elif kind == "asset_plan":
            entry.update({
                "json_ok": _rate([it.get("json_ok") for it in items]),
                "schema_ok": _rate([it.get("schema_ok") for it in items]),
                "accepted": _rate([it.get("accepted") for it in items]),
                "accepted_n": sum(1 for it in items if it.get("accepted")),
                "rooms_n": _mean([_num(it.get("rooms_n")) for it in items]),
                "area_m2": _mean([_num(it.get("area_m2")) for it in items]),
                "area_in_range": _rate([it.get("area_in_range") for it in items]),
                "build_ok": _rate([_get(it, "build.build_ok") for it in items]),
                "coverage": _mean([_num(_get(it, "build.coverage_ratio")) for it in items]),
                "overlaps": _mean([_num(_get(it, "build.overlaps")) for it in items]),
            })
        elif kind == "asset_library":
            entry.update({
                "json_ok": _rate([it.get("json_ok") for it in items]),
                "items_n": _mean([_num(it.get("items_n")) for it in items]),
                "valid_n": _mean([_num(it.get("valid_n")) for it in items]),
                "accepted_n": sum(int(it.get("accepted_n") or 0) for it in items),
                "duplicate_n": _mean([_num(it.get("duplicate_n")) for it in items]),
                "alias_valid_n": sum(int(it.get("alias_valid_n") or 0) for it in items),
                "focus_count": _mean([_num(it.get("focus_count")) for it in items]),
            })
        elif kind == "raw_ldraw":
            entry.update({
                "n": len(items),
                "valid": _rate([it.get("valid") for it in items]),
                "build_ok": _rate([it.get("build_ok") for it in items]),
                "parts": _mean([_num(it.get("parts")) for it in items]),
                "overlaps": _mean([_num(it.get("overlaps")) for it in items]),
                "statuses": sorted({str(it.get("status")) for it in items}),
            })
        summary[f"{model}/{kind}"] = entry

    # paired comparisons on the same (kind, plan, brief, rep)
    grouped = defaultdict(dict)
    for r in rows:
        m = r["m"]
        key = (m.get("kind"), m.get("plan_id"), m.get("brief_id"), m.get("rep", 0))
        grouped[key][m.get("model") or r["job"]["model"]] = m
    models = sorted({r["m"].get("model") or r["job"]["model"] for r in rows})
    paired = {}
    for i in range(len(models)):
        for j in range(i + 1, len(models)):
            a, b = models[i], models[j]
            res = {}
            for kind, specs in (("perception", PERCEPTION_METRICS),
                                ("perception_compact", PERCEPTION_METRICS),
                                ("llm_direct", DIRECT_METRICS)):
                for metric, direction in specs:
                    wins = losses = ties = 0
                    deltas = []
                    for key, by_model in grouped.items():
                        if key[0] != kind or a not in by_model or b not in by_model:
                            continue
                        va, vb = _num(_get(by_model[a], metric)), _num(_get(by_model[b], metric))
                        if va is None or vb is None:
                            continue
                        if direction == "lower":
                            va, vb = -va, -vb
                        d = va - vb
                        deltas.append(d)
                        if abs(d) < 1e-9:
                            ties += 1
                        elif d > 0:
                            wins += 1
                        else:
                            losses += 1
                    if wins + losses + ties:
                        res[f"{kind}.{metric}"] = {
                            "n": wins + losses + ties, "wins": wins,
                            "losses": losses, "ties": ties,
                            "mean_delta": round(sum(deltas) / len(deltas), 4) if deltas else None,
                            "direction": direction,
                        }
            # judge agreement (not accuracy: there is no human label yet)
            agree = disagree = 0
            for key, by_model in grouped.items():
                if key[0] != "judge" or a not in by_model or b not in by_model:
                    continue
                wa, wb = by_model[a].get("winner"), by_model[b].get("winner")
                if wa and wb:
                    agree += int(wa == wb)
                    disagree += int(wa != wb)
            if agree + disagree:
                res["judge.agreement"] = {"n": agree + disagree, "agree": agree,
                                          "disagree": disagree,
                                          "rate": round(agree / (agree + disagree), 4)}
            paired[f"{a} vs {b}"] = res

    usage = defaultdict(lambda: {"calls": 0, "in": 0, "out": 0, "latency": []})
    for r in rows:
        m = r["m"]
        model = m.get("model") or r["job"]["model"]
        u = m.get("usage") or {}
        usage[model]["calls"] += 1
        usage[model]["in"] += int(u.get("in") or 0)
        usage[model]["out"] += int(u.get("out") or 0)
        if isinstance(m.get("latency_s"), (int, float)):
            usage[model]["latency"].append(float(m["latency_s"]))
    for model, u in usage.items():
        u["latency_mean_s"] = _mean(u.pop("latency"))
        if cfg and cfg.models.get(model):
            mc = cfg.models[model]
            if mc.price_in is not None and mc.price_out is not None:
                u["cost_usd"] = round(u["in"] / 1e6 * mc.price_in
                                      + u["out"] / 1e6 * mc.price_out, 4)
    return {
        "counts": counts,
        "quota": q,
        "windows": store.history(buckets=12),
        "summary": summary,
        "paired": paired,
        "usage": dict(usage),
        "dead": [{"kind": j["kind"], "model": j["model"], "error": j["error"]}
                 for j in store.jobs(status="dead")][:50],
    }


def report_markdown(rep: dict) -> str:
    lines = [
        "# Plan2Brick multi-model comparison",
        "",
        f"- Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"- Jobs: {rep['counts']['total']} total · {rep['counts']['done']} done · "
        f"{rep['counts']['pending']} pending · {rep['counts']['running']} running · "
        f"{rep['counts']['dead']} dead",
        f"- Quota: {rep['quota']['mode']} {rep['quota']['window_hours']:.2f} h, "
        f"{rep['quota']['used']}/{rep['quota']['limit']} in the current window",
        "",
        "## Per-model metrics",
        "",
    ]
    for key, s in sorted(rep["summary"].items()):
        lines.append(f"### {key}")
        lines.append("")
        lines.append("| metric | value |")
        lines.append("|---|---:|")
        for k, v in s.items():
            if k == "by_gt_source":
                continue
            lines.append(f"| {k} | {v} |")
        if s.get("by_gt_source"):
            lines.append("")
            lines.append("| GT source | n | room recall | dims MAE | object F1 | build ok | coverage |")
            lines.append("|---|---:|---:|---:|---:|---:|---:|")
            for src, sm in s["by_gt_source"].items():
                lines.append(f"| {src} | {sm['n']} | {sm['room_recall']} | "
                             f"{sm['dims_mae_m']} | {sm['object_f1']} | "
                             f"{sm['build_ok']} | {sm['coverage']} |")
        lines.append("")
    lines += ["## Paired comparisons", ""]
    if not rep["paired"]:
        lines.append("_No paired results yet._")
    for pair, metrics in sorted(rep["paired"].items()):
        lines.append(f"### {pair}")
        lines.append("")
        lines.append("| metric | n | wins | losses | ties | mean Δ | better |")
        lines.append("|---|---:|---:|---:|---:|---:|---|")
        for name, s in metrics.items():
            if "wins" in s:
                lines.append(f"| {name} | {s['n']} | {s['wins']} | {s['losses']} | "
                             f"{s['ties']} | {s['mean_delta']} | {s['direction']} |")
            else:
                lines.append(f"| {name} | {s['n']} | — | — | — | "
                             f"agreement {s['rate']} | same winner |")
        lines.append("")
    lines += ["## Token usage and latency", ""]
    lines.append("| model | calls | input tok | output tok | mean latency (s) | cost (USD) |")
    lines.append("|---|---:|---:|---:|---:|---:|")
    for model, u in sorted(rep["usage"].items()):
        lines.append(f"| {model} | {u['calls']} | {u['in']} | {u['out']} | "
                     f"{u['latency_mean_s']} | {u.get('cost_usd', 'n/a')} |")
    lines += ["", "## Quota windows", ""]
    for w in rep["windows"]:
        ts = time.strftime("%m-%d %H:%M", time.localtime(w["start"]))
        lines.append(f"- {ts}: {w['used']}/{w['limit']}"
                     + (" (current)" if w["current"] else ""))
    if rep.get("dead"):
        lines += ["", "## Dead jobs (first 50)", ""]
        for d in rep["dead"]:
            lines.append(f"- `{d['kind']}` / `{d['model']}`: {d['error']}")
    lines.append("")
    return "\n".join(lines)


def write_report(store: Store, cfg: BenchConfig, out_dir: Path | None = None) -> Path:
    rep = build_report(store, cfg)
    out = Path(out_dir) if out_dir else cfg.out_dir
    out.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    md = out / f"model_compare_{stamp}.md"
    js = out / f"model_compare_{stamp}.json"
    md.write_text(report_markdown(rep), encoding="utf-8")
    js.write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
    return md
