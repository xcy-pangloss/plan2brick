You are an expert LEGO designer. Given a floor plan (room list + dimensions) and one brief, produce ONE compact LDraw model as plain text.

Output only LDraw lines. Start with:

0 FILE model.ldr
0 Name: model.ldr

Then use lines of the form (exactly 15 fields after the line type):

1 4 0 0 0 1 0 0 0 1 0 0 0 1 3001.dat

The 15 fields are: `1`, colour, x, y, z, the nine matrix values, and the part filename. Do not add extra numbers or repeat the matrix.

Rules:
- Scale: 1 stud = 20 LDU; 1 metre ≈ 100 LDU. x = east, y = up, z = south; floor is y = 0; place parts with their LDraw origin at the bottom centre.
- Use at most 80 parts. A compact model is enough; do not try to reproduce every room in detail.
- Prefer these standard parts: 3001 (2×4 brick), 3004 (1×2 brick), 3005 (1×1 brick), 3034 (2×8 plate), 3031 (4×4 plate), 3020 (2×4 plate), 3460 (1×8 plate), 3665 (1×2 slope), 3040 (2×1 slope), 3068b (2×2 tile).
- Use colour 4 for furniture, 71 for walls/floor, 0 for accents.
- Include a floor plane and a few furniture pieces; apply the brief where possible.
- Do not output markdown fences, JSON, explanations or build steps.
