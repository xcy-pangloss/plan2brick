"""Retry native-AI direct conversion with several output formats.

Formats:
  ldr   complete LDraw text
  json  structured part list -> local JSON-to-LDraw converter
  csv   structured part list -> local CSV-to-LDraw converter

Every candidate is converted to .ldr and validated by lego_nova.cli validate
(--geometry).  DeepSeek uses a separate ledger (different provider quota);
Claude/GPT use the shared aipro ledger.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

NOVA = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NOVA))

from modelbench import catalogue, scoring, transport  # noqa: E402
from modelbench.config import ModelConfig, load_config  # noqa: E402
from modelbench.quota import QuotaPolicy, parse_anchor  # noqa: E402
from modelbench.store import Store  # noqa: E402

OUT = NOVA / "modelbench" / "out_experiment" / "raw_formats"
PROMPTS = NOVA / "modelbench" / "prompts"
VENV_PY = NOVA / ".venv" / "Scripts" / "python.exe"
CASE = ("R2", "B1")

ALLOWED = {"3001", "3004", "3005", "3034", "3031", "3020", "3460", "3665",
           "3040", "3068b"}
ROT = {
    0: "1 0 0 0 1 0 0 0 1",
    90: "0 0 1 0 1 0 -1 0 0",
    180: "-1 0 0 0 1 0 0 0 -1",
    270: "0 0 -1 0 1 0 1 0 0",
}


def log(msg: str) -> None:
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}"
    print(line, flush=True)
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "run.log").open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def load_case():
    plans = {p["id"]: p for p in catalogue.load_all_plans()}
    briefs = {b["id"]: b for b in catalogue.load_briefs()}
    return plans[CASE[0]], briefs[CASE[1]]


def plan_rooms(plan: dict) -> list[dict]:
    ir = catalogue.load_plan_ir(plan)
    return [{"name_cn": r.get("name_cn") or r.get("name_en"),
             "name_en": r.get("name_en") or r.get("name_cn"),
             "room_type": r.get("room_type"), "dims_m": r.get("dims_m")}
            for r in ir.get("rooms") or []]


def prompt(fmt: str, plan: dict, brf: dict) -> str:
    name = {"ldr": "raw_ldraw_v2.md", "json": "raw_parts_json_v1.md",
            "csv": "raw_parts_csv_v1.md"}[fmt]
    base = (PROMPTS / name).read_text(encoding="utf-8")
    data = {"plan": {"id": plan["id"], "rooms": plan_rooms(plan)},
            "brief": {"id": brf["id"], "text": brf["text"]}}
    return (base + "\n\nInput:\n```json\n"
            + json.dumps(data, ensure_ascii=False, indent=2) + "\n```\n")


def parts_to_ldr(parts: list[dict]) -> str:
    lines = ["0 FILE model.ldr", "0 Name: model.ldr",
             "0 Native AI structured part list -> LDraw"]
    for p in parts:
        try:
            part = str(p.get("part") or "").strip()
            if not part:
                continue
            if not part.endswith(".dat"):
                part += ".dat"
            color = int(p.get("color", 4) or 4)
            x = float(p.get("x", 0) or 0)
            y = float(p.get("y", 0) or 0)
            z = float(p.get("z", 0) or 0)
            rot = int(p.get("rot", 0) or 0) % 360
            if rot not in ROT:
                rot = 0
            lines.append(f"1 {color} {x:g} {y:g} {z:g} {ROT[rot]} {part}")
        except (TypeError, ValueError):
            continue
    return "\n".join(lines) + "\n"


def parse_ldr(text: str) -> str:
    text = (text or "").strip()
    if "```" in text:
        import re
        blocks = re.findall(r"```(?:ldraw|ldr|mpd)?\s*(.*?)```", text, re.S | re.I)
        if blocks:
            text = max(blocks, key=len)
    lines = [ln.rstrip() for ln in text.splitlines()
             if ln.strip() and (ln.startswith("0 ") or ln.startswith("1 "))]
    if not lines:
        return ""
    if not lines[0].startswith("0 FILE"):
        lines = ["0 FILE model.ldr", "0 Name: model.ldr", *lines]
    return "\n".join(lines) + "\n"


def parse_json(text: str) -> list[dict]:
    obj = scoring.extract_json(text)
    if not isinstance(obj, dict):
        return []
    parts = obj.get("parts")
    return parts if isinstance(parts, list) else []


def parse_csv(text: str) -> list[dict]:
    text = (text or "").strip()
    if "```" in text:
        import re
        blocks = re.findall(r"```(?:csv)?\s*(.*?)```", text, re.S | re.I)
        if blocks:
            text = max(blocks, key=len)
    out = []
    for i, line in enumerate(text.splitlines()):
        line = line.strip()
        if not line or line.lower().startswith("part,"):
            continue
        cols = [c.strip() for c in line.split(",")]
        if len(cols) < 6:
            continue
        try:
            out.append({"part": cols[0], "color": int(cols[1]),
                        "x": float(cols[2]), "y": float(cols[3]),
                        "z": float(cols[4]), "rot": int(cols[5])})
        except ValueError:
            continue
    return out


def validate_ldr(ldr: str, case_dir: Path) -> dict:
    out = {"converted": bool(ldr), "valid": False, "build_ok": False,
           "parts": 0, "overlaps": None, "status": "no_ldraw"}
    if not ldr:
        return out
    case_dir.mkdir(parents=True, exist_ok=True)
    path = case_dir / "converted.ldr"
    path.write_text(ldr, encoding="utf-8")
    report = case_dir / "validate.json"
    out["ldr_path"] = str(path)
    try:
        subprocess.run([str(VENV_PY), "-m", "lego_nova.cli", "validate",
                        str(path), "--geometry", "--report", str(report)],
                       cwd=str(NOVA), capture_output=True, text=True, timeout=180)
    except Exception as exc:
        out["status"] = f"validate_exception: {exc}"[:250]
        return out
    if not report.exists():
        out["status"] = "no_validate_report"
        return out
    try:
        rep = json.loads(report.read_text(encoding="utf-8"))
    except Exception as exc:
        out["status"] = f"report_error: {exc}"[:250]
        return out
    diag = rep.get("diagnostics") or []
    errors = [d for d in diag if str(d.get("severity")).lower() == "error"]
    geom = rep.get("geometry") or {}
    out.update({
        "valid": bool(rep.get("checks_passed")) and not errors,
        "build_ok": bool(rep.get("checks_passed")) and not errors,
        "parts": int(geom.get("occurrence_count") or 0),
        "overlaps": len(errors),
        "diagnostics": [f"{d.get('severity')}:{d.get('code')}" for d in diag][:20],
        "status": "ok" if rep.get("checks_passed") else "validate_failed",
        "bbox": geom.get("bounds"),
    })
    return out


def call_quota(cfg, store: Store, model: str, text: str,
               max_tokens: int) -> transport.CallResult | None:
    while True:
        cid, nxt, used = store.reserve_call_raw(model)
        if cid is None:
            wait = max(0.0, float(nxt) - time.time())
            log(f"quota full ({used}); wait {min(wait,60):.0f}s")
            time.sleep(min(wait, 60) if wait > 0 else 5)
            continue
        try:
            res = transport.call_model(cfg, model, text, None,
                                       max_output_tokens=max_tokens)
            store.finish_call(cid, "ok", http_status=res.http_status,
                              latency_s=res.latency_s,
                              in_tokens=(res.usage or {}).get("in"),
                              out_tokens=(res.usage or {}).get("out"))
            return res
        except transport.TransportError as exc:
            released = bool(exc.release_slot)
            store.finish_call(cid, "error", http_status=exc.status, released=released)
            if released:
                store.release_call(cid, "rawformats")
            if exc.status == 429:
                until = time.time() + max(5.0, float(exc.retry_after or 60.0))
                store.set_quota_block(until, exc.reported_used)
                log(f"429; wait until {time.strftime('%H:%M:%S', time.localtime(until))}")
                continue
            log(f"call error {model}: {exc.status} {str(exc)[:200]}")
            return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--formats", default="ldr,json,csv")
    ap.add_argument("--models", default="deepseek,claude,gpt")
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    cfg = load_config()
    cfg.models["deepseek_chat"] = ModelConfig(
        name="deepseek_chat", provider="deepseek", model="deepseek-chat",
        vision=False, max_output_tokens=4096, temperature=0.0)
    main_store = Store(cfg.state_dir / "queue.sqlite3",
                       QuotaPolicy(cfg.quota.limit, cfg.quota.window_s,
                                   cfg.quota.mode, parse_anchor(cfg.quota.anchor)))
    ds_store = Store(cfg.state_dir / "queue_deepseek.sqlite3",
                     QuotaPolicy(cfg.quota.limit, cfg.quota.window_s,
                                 cfg.quota.mode, parse_anchor(cfg.quota.anchor)))
    plan, brf = load_case()
    formats = [x.strip() for x in a.formats.split(",") if x.strip()]
    models = [x.strip() for x in a.models.split(",") if x.strip()]
    results_path = OUT / "results.jsonl"
    existing = set()
    if results_path.exists() and not a.force:
        for line in results_path.read_text(encoding="utf-8").splitlines():
            try:
                r = json.loads(line)
                existing.add((r.get("format"), r.get("model")))
            except json.JSONDecodeError:
                pass
    OUT.mkdir(parents=True, exist_ok=True)
    for fmt in formats:
        for model in models:
            if (fmt, model) in existing:
                log(f"skip {fmt} {model}")
                continue
            actual = "deepseek_chat" if model == "deepseek" else model
            store = ds_store if model == "deepseek" else main_store
            text = prompt(fmt, plan, brf)
            max_tokens = 4096 if fmt in ("ldr", "json") else 2048
            log(f"{fmt} {model}: calling ({actual})")
            res = call_quota(cfg, store, actual, text, max_tokens)
            rec = {"format": fmt, "model": model, "case": "R2_B1"}
            if res is None:
                rec.update({"status": "call_error", "converted": False,
                            "valid": False})
            else:
                cdir = OUT / f"{fmt}_{model}"
                cdir.mkdir(parents=True, exist_ok=True)
                (cdir / "response.txt").write_text(res.text or "", encoding="utf-8")
                if fmt == "ldr":
                    ldr = parse_ldr(res.text or "")
                elif fmt == "json":
                    parts = parse_json(res.text or "")
                    (cdir / "parts.json").write_text(
                        json.dumps(parts, ensure_ascii=False, indent=2), encoding="utf-8")
                    ldr = parts_to_ldr(parts)
                else:
                    parts = parse_csv(res.text or "")
                    (cdir / "parts.json").write_text(
                        json.dumps(parts, ensure_ascii=False, indent=2), encoding="utf-8")
                    ldr = parts_to_ldr(parts)
                rec.update(validate_ldr(ldr, cdir))
                rec.update({"latency_s": res.latency_s, "usage": res.usage,
                            "response_chars": len(res.text or "")})
            with results_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            existing.add((fmt, model))
            log(f"{fmt} {model}: status={rec.get('status')} valid={rec.get('valid')} "
                f"parts={rec.get('parts')}")
    rows = []
    if results_path.exists():
        for line in results_path.read_text(encoding="utf-8").splitlines():
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    lines = ["# Raw native AI output-format comparison (R2-B1)", "",
             "| format | model | converted | valid | parts | overlaps | status | latency s |",
             "|---|---|---|---|---:|---:|---|---:|"]
    for r in rows:
        lines.append(f"| {r.get('format')} | {r.get('model')} | {r.get('converted')} "
                     f"| {r.get('valid')} | {r.get('parts')} | {r.get('overlaps')} "
                     f"| {r.get('status')} | {r.get('latency_s')} |")
    lines += ["", "Reference: Plan2Brick P on R2-B1: build true, coverage 1.0, "
              "0 overlaps, 0 model calls. B (AI IR + builder): build true, "
              "coverage ~0.88-1.0 depending on model. Raw formats above are "
              "**convertibility** tests, not full-scene coverage tests.", ""]
    (OUT / "SUMMARY.md").write_text("\n".join(lines), encoding="utf-8")
    log(f"wrote {OUT / 'SUMMARY.md'}")
    main_store.close()
    ds_store.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
