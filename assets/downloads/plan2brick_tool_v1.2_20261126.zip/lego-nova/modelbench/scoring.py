"""Scoring for model-comparison jobs.

Every model output is scored with deterministic, model-independent code:

* JSON extraction and the existing ``check_ir`` structure checker;
* perception: room matching against the manual GT, dimension MAE, object
  category precision/recall/F1 (against the labelled GT where available);
* LLM-direct: room preservation, brief-effect assertions, and a deterministic
  assembly pass that reports requested/placed coverage and overlaps;
* judge: winner parsing only (this is an LLM-as-judge proxy, not human data).

The scoring code never calls a model.
"""
from __future__ import annotations

import importlib.util
import json
import re
import subprocess
import tempfile
from difflib import SequenceMatcher
from pathlib import Path

from . import catalogue

HERE = Path(__file__).resolve().parent
NOVA = HERE.parent
ROOT = NOVA.parent
CHECK_IR = ROOT / "fyp-pipeline" / "check_ir.py"
LIBRARY = ROOT / "fyp-pipeline" / "library"
VENV_PY = NOVA / ".venv" / "Scripts" / "python.exe"

CATEGORIES = ["sofa", "bed", "table", "chair", "desk", "cabinet", "bookshelf",
              "lamp", "tv", "plant", "fridge", "stove", "sink", "toilet",
              "bath", "washer"]

_CHECKER = None


def _checker():
    global _CHECKER
    if _CHECKER is None:
        spec = importlib.util.spec_from_file_location("modelbench_check_ir", CHECK_IR)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _CHECKER = mod
    return _CHECKER


# ------------------------------------------------------------------ parsing
def extract_json(text: str) -> dict | None:
    if not text:
        return None
    text = text.strip()
    blocks = re.findall(r"```(?:json)?\s*(.*?)```", text, re.S | re.I)
    candidates = [*blocks, text]
    decoder = json.JSONDecoder()
    for cand in candidates:
        cand = cand.strip()
        try:
            obj = json.loads(cand)
            if isinstance(obj, dict):
                return obj
        except json.JSONDecodeError:
            pass
        for i, ch in enumerate(cand):
            if ch != "{":
                continue
            try:
                obj, _end = decoder.raw_decode(cand[i:])
                if isinstance(obj, dict):
                    return obj
            except json.JSONDecodeError:
                continue
    return None


def check_ir_obj(ir: dict) -> tuple[list[str], list[str]]:
    tmp = None
    try:
        fd, tmp = tempfile.mkstemp(suffix=".json", prefix="modelbench_ir_")
        with open(fd, "w", encoding="utf-8") as fh:
            json.dump(ir, fh, ensure_ascii=False)
        return _checker().check(tmp)
    finally:
        if tmp:
            try:
                Path(tmp).unlink()
            except OSError:
                pass


# -------------------------------------------------------------- room names
ROOM_WORDS = {
    "起居室": "living", "客厅": "living", "客餐厅": "living", "living room": "living",
    "lounge": "living", "family room": "living",
    "主卧": "bedroom", "卧室": "bedroom", "次卧": "bedroom", "儿童房": "bedroom",
    "master bedroom": "bedroom", "bedroom": "bedroom", "kids room": "bedroom",
    "书房": "study", "study": "study", "office": "study", "工作间": "study",
    "厨房": "kitchen", "kitchen": "kitchen",
    "餐厅": "dining", "dining room": "dining", "dining": "dining",
    "卫生间": "bathroom", "主卫生间": "bathroom", "厕所": "bathroom", "浴室": "bathroom",
    "bathroom": "bathroom", "toilet": "bathroom", "wc": "bathroom", "shower": "bathroom",
    "阳台": "balcony", "生活阳台": "balcony", "balcony": "balcony", "terrace": "balcony",
    "玄关": "hallway", "走廊": "hallway", "过道": "hallway", "hall": "hallway",
    "entrance": "hallway", "foyer": "hallway", "corridor": "hallway", "hallway": "hallway",
    "衣帽间": "closet", "closet": "closet", "walk-in closet": "closet", "wardrobe": "closet",
    "储物间": "storage", "storage": "storage", "utility": "storage", "laundry": "storage",
    "可变空间": "flex", "flex": "flex", "multipurpose": "flex",
}


def canonical_room(name: str | None) -> str:
    if not name:
        return ""
    s = str(name).strip().lower().replace("_", " ")
    for key, val in ROOM_WORDS.items():
        if key in s:
            return val
    return re.sub(r"[\s\-_/]+", " ", s).strip()


def name_similarity(a: str | None, b: str | None) -> float:
    ca, cb = canonical_room(a), canonical_room(b)
    if not ca or not cb:
        return 0.0
    if ca == cb:
        return 1.0
    if ca in cb or cb in ca:
        return 0.85
    return round(SequenceMatcher(None, ca, cb).ratio(), 4)


def _dims(d) -> tuple[float, float] | None:
    try:
        if isinstance(d, (list, tuple)) and len(d) >= 2:
            w, h = float(d[0]), float(d[1])
            if w > 0 and h > 0:
                return w, h
    except (TypeError, ValueError):
        pass
    return None


def _dims_error(pred: tuple[float, float], gt: tuple[float, float]) -> tuple[float, bool]:
    direct = (abs(pred[0] - gt[0]) + abs(pred[1] - gt[1])) / 2.0
    swapped = (abs(pred[1] - gt[0]) + abs(pred[0] - gt[1])) / 2.0
    return (swapped, True) if swapped < direct else (direct, False)


def match_rooms(gt_rooms: list[dict], pred_rooms: list[dict]) -> list[dict]:
    """Greedy one-to-one match; name first, dimensions break ties."""
    pairs = []
    for i, g in enumerate(gt_rooms):
        gd = _dims(g.get("dims"))
        for j, p in enumerate(pred_rooms):
            ns = name_similarity(g.get("name"), p.get("name_cn") or p.get("name_en"))
            pd = _dims(p.get("dims_m"))
            ds = 0.0
            if gd and pd:
                err, _ = _dims_error(pd, gd)
                ds = max(0.0, 1.0 - err / max(1.0, (gd[0] + gd[1]) / 2.0))
            score = 0.75 * ns + 0.25 * ds
            if ns >= 0.55 or (gd and pd and ds >= 0.6):
                pairs.append((score, i, j))
    pairs.sort(reverse=True)
    used_g, used_p, out = set(), set(), []
    for score, i, j in pairs:
        if i in used_g or j in used_p:
            continue
        used_g.add(i)
        used_p.add(j)
        out.append({"gt_index": i, "pred_index": j, "score": round(score, 4),
                    "name_score": round(name_similarity(
                        gt_rooms[i].get("name"),
                        pred_rooms[j].get("name_cn") or pred_rooms[j].get("name_en")), 4)})
    return out


def _pred_rooms(ir: dict) -> list[dict]:
    out = []
    for r in ir.get("rooms") or []:
        if not isinstance(r, dict):
            continue
        out.append({
            "name": r.get("name_cn") or r.get("name_en") or "",
            "name_cn": r.get("name_cn"),
            "name_en": r.get("name_en"),
            "dims_m": r.get("dims_m"),
            "room_type": r.get("room_type"),
        })
    return out


# --------------------------------------------------------------- perception
def score_perception(ir: dict | None, plan: dict, schema_errors: list[str],
                     warnings: list[str]) -> dict:
    out = {
        "json_ok": ir is not None,
        "schema_ok": not schema_errors,
        "schema_errors": schema_errors[:20],
        "warnings": warnings[:20],
        "image_type_ok": bool(ir and ir.get("image_type") == "floorplan"),
        "gt_source": plan.get("gt_source"),
    }
    if not isinstance(ir, dict):
        return out
    pred_rooms = _pred_rooms(ir)
    gt_rooms = catalogue.load_gt_rooms(plan)
    matches = match_rooms(gt_rooms, pred_rooms)
    out["rooms_pred"] = len(pred_rooms)
    out["rooms_gt"] = len(gt_rooms)
    out["rooms_matched"] = len(matches)
    out["room_recall"] = round(len(matches) / max(1, len(gt_rooms)), 4)
    out["room_precision"] = round(len(matches) / max(1, len(pred_rooms)), 4)
    errs, swaps, area_errs = [], 0, []
    for m in matches:
        gd = _dims(gt_rooms[m["gt_index"]].get("dims"))
        pd = _dims(pred_rooms[m["pred_index"]].get("dims_m"))
        if not gd or not pd:
            continue
        err, swapped = _dims_error(pd, gd)
        errs.append(err)
        swaps += int(swapped)
        area_errs.append(abs(pd[0] * pd[1] - gd[0] * gd[1]))
    out["dims_mae_m"] = round(sum(errs) / len(errs), 4) if errs else None
    out["area_mae_m2"] = round(sum(area_errs) / len(area_errs), 4) if area_errs else None
    out["axis_swapped"] = swaps
    out["dims_n"] = len(errs)

    gt_ir = catalogue.load_plan_ir({"path": plan["gt_ir"]})
    gt_counts, pred_counts = _category_counts(gt_ir), _category_counts(ir)
    out.update(_object_metrics(gt_counts, pred_counts))
    out["gt_objects"] = sum(gt_counts.values())
    out["pred_objects"] = sum(pred_counts.values())
    out["object_source"] = plan.get("gt_source")
    return out


# ---------------------------------------------------------------- llm-direct
def _category_counts(ir: dict) -> dict[str, int]:
    counts = {c: 0 for c in CATEGORIES}
    for o in ir.get("objects") or []:
        if not isinstance(o, dict):
            continue
        c = o.get("category")
        try:
            n = int(o.get("count", 1) or 1)
        except (TypeError, ValueError):
            n = 1
        if c in counts:
            counts[c] += max(1, n)
        elif c == "other":
            counts.setdefault("other", 0)
            counts["other"] += max(1, n)
    return counts


def _object_metrics(gt: dict[str, int], pred: dict[str, int]) -> dict:
    cats = [c for c in CATEGORIES if gt.get(c, 0) or pred.get(c, 0)]
    tp = sum(min(gt.get(c, 0), pred.get(c, 0)) for c in cats)
    fp = sum(max(0, pred.get(c, 0) - gt.get(c, 0)) for c in cats)
    fn = sum(max(0, gt.get(c, 0) - pred.get(c, 0)) for c in cats)
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    present_gt = {c for c in cats if gt.get(c, 0)}
    present_pred = {c for c in cats if pred.get(c, 0)}
    set_tp = len(present_gt & present_pred)
    set_p = set_tp / len(present_pred) if present_pred else 0.0
    set_r = set_tp / len(present_gt) if present_gt else 0.0
    return {
        "object_precision": round(precision, 4),
        "object_recall": round(recall, 4),
        "object_f1": round(f1, 4),
        "object_set_f1": round(2 * set_p * set_r / (set_p + set_r), 4) if set_p + set_r else 0.0,
        "category_counts_gt": {k: v for k, v in gt.items() if v},
        "category_counts_pred": {k: v for k, v in pred.items() if v},
    }


def _count_in_room(ir: dict, category: str, room_canonical: str) -> int:
    total = 0
    for o in ir.get("objects") or []:
        if not isinstance(o, dict) or o.get("category") != category:
            continue
        if room_canonical not in ("", "all") and canonical_room(o.get("room")) != room_canonical:
            continue
        try:
            total += max(1, int(o.get("count", 1) or 1))
        except (TypeError, ValueError):
            total += 1
    return total


def _room_type(ir: dict, room_canonical: str) -> str | None:
    for r in ir.get("rooms") or []:
        if canonical_room(r.get("name_cn") or r.get("name_en")) == room_canonical:
            return str(r.get("room_type") or "").lower() or None
    return None


def brief_effect(ir: dict, base_ir: dict, payload: dict) -> dict:
    from novalib import brief as brief_lib
    patched = brief_lib.apply_brief(base_ir, payload["brief_text"])
    actions = patched.get("actions") or []
    checks = []
    if actions:
        act = actions[0]
        room = canonical_room(act.get("room"))
        cat = act.get("category")
        old = act.get("old_category")
        if payload["brief_id"] == "B1":
            checks.append(("added category present",
                           _count_in_room(ir, cat, room) > _count_in_room(base_ir, cat, room)))
        elif payload["brief_id"] == "B2":
            before = _count_in_room(base_ir, cat, room)
            checks.append(("target existed", before > 0))
            checks.append(("removed category absent", _count_in_room(ir, cat, room) == 0))
        elif payload["brief_id"] == "B3":
            checks.append(("replacement present",
                           _count_in_room(ir, cat, room) > 0))
            checks.append(("old category removed",
                           _count_in_room(ir, old, room) == 0))
        elif payload["brief_id"] == "B4":
            rt = _room_type(ir, room)
            checks.append(("room type is study", rt == "study"))
            checks.append(("study programme present",
                           all(_count_in_room(ir, c, room) > 0
                               for c in ("desk", "chair", "bookshelf"))))
    return {"ok": bool(checks) and all(v for _l, v in checks),
            "checks": [{"check": l, "pass": bool(v)} for l, v in checks],
            "actions": actions}


def build_prediction(ir: dict, job_id: str, outroot: Path) -> dict:
    try:
        from novalib import variants
        pl, pl_path, _ = variants.build_ir(ir, job_id, outroot, LIBRARY)
        try:
            requested = int(pl.get("requested_count") or 0)
            placed = int(pl.get("placed_count") or 0)
        except (TypeError, ValueError):
            return {"build_ok": False, "counts_ok": False,
                    "build_error": "non-numeric requested/placed counts"}
        counts_ok = (requested >= 0 and placed >= 0
                     and ((requested == 0 and placed == 0)
                          or (0 < placed <= requested)))
        if requested > 0 and placed >= 0:
            coverage = round(placed / requested, 4) if counts_ok else None
        else:
            coverage = 1.0 if (requested == 0 and placed == 0) else None
        pl_path = Path(pl_path)
        artifact_ok = pl_path.exists() and pl_path.is_file()
        return {
            "build_ok": bool(artifact_ok and counts_ok),
            "counts_ok": counts_ok,
            "requested": requested,
            "placed": placed,
            "coverage_ratio": coverage,
            "overlaps": len(pl.get("cross_room_overlaps") or []),
            "wall_furniture_overlaps": len(pl.get("wall_furniture_overlaps") or []),
            "parts": pl.get("parts_total"),
            "rooms": len(pl.get("rooms") or []),
            "placement_file": str(pl_path),
            "artifact_ok": artifact_ok,
        }
    except Exception as exc:
        return {"build_ok": False, "counts_ok": False,
                "build_error": f"{type(exc).__name__}: {exc}"[:500]}


def score_llm_direct(ir: dict | None, payload: dict, schema_errors: list[str],
                     warnings: list[str], job_id: str, outroot: Path) -> dict:
    out = {
        "json_ok": ir is not None,
        "schema_ok": not schema_errors,
        "schema_errors": schema_errors[:20],
        "warnings": warnings[:20],
    }
    if not isinstance(ir, dict):
        return out
    try:
        base_ir = catalogue.load_plan_ir({"path": payload["base_ir"]})
    except Exception as exc:
        out["score_error"] = f"base_ir: {type(exc).__name__}: {exc}"[:300]
        return out
    base_rooms = _pred_rooms(base_ir)
    pred_rooms = _pred_rooms(ir)
    matches = match_rooms(base_rooms, pred_rooms)
    out["rooms_gt"] = len(base_rooms)
    out["rooms_pred"] = len(pred_rooms)
    out["rooms_kept"] = len(matches)
    out["room_recall"] = round(len(matches) / max(1, len(base_rooms)), 4)
    out["room_precision"] = round(len(matches) / max(1, len(pred_rooms)), 4)
    errs = []
    for m in matches:
        gd = _dims(base_rooms[m["gt_index"]].get("dims_m"))
        pd = _dims(pred_rooms[m["pred_index"]].get("dims_m"))
        if gd and pd:
            errs.append(_dims_error(pd, gd)[0])
    out["dims_mae_m"] = round(sum(errs) / len(errs), 4) if errs else None
    out["dims_n"] = len(errs)
    out["brief_effect"] = brief_effect(ir, base_ir, payload)
    counts = _category_counts(ir)
    out["object_counts"] = {k: v for k, v in counts.items() if v}
    out["object_total"] = sum(counts.values())
    out["room_types"] = {r["name"]: r.get("room_type") for r in pred_rooms
                         if r.get("room_type")}
    if outroot:
        if out["schema_ok"]:
            out["build"] = build_prediction(ir, job_id, Path(outroot))
        else:
            out["build"] = {"build_ok": False, "counts_ok": False,
                            "build_skipped": "schema_errors"}
    return out


# ---------------------------------------------------------- raw LDraw output
def score_raw_ldraw(text: str, outdir: Path) -> dict:
    """Extract LDraw lines, write a .ldr and validate it with lego_nova."""
    text = (text or "").strip()
    if "```" in text:
        blocks = re.findall(r"```(?:ldraw|ldr|mpd)?\s*(.*?)```", text, re.S | re.I)
        if blocks:
            text = max(blocks, key=len)
    lines = [ln.rstrip() for ln in text.splitlines()
             if ln.strip() and (ln.startswith("0 ") or ln.startswith("1 "))]
    out = {"json_ok": bool(lines), "valid": False, "build_ok": False,
           "parts": 0, "overlaps": None, "status": "no_ldraw_lines",
           "response_chars": len(text)}
    if not lines:
        return out
    if not lines[0].startswith("0 FILE"):
        lines = ["0 FILE model.ldr", "0 Name: model.ldr", *lines]
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    ldr_path = outdir / "raw.ldr"
    ldr_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    report = outdir / "validate.json"
    out["ldr_path"] = str(ldr_path)
    try:
        subprocess.run(
            [str(VENV_PY), "-m", "lego_nova.cli", "validate", str(ldr_path),
             "--geometry", "--report", str(report)],
            cwd=str(NOVA), capture_output=True, text=True, timeout=180)
    except Exception as exc:
        out["status"] = f"validate_exception: {type(exc).__name__}: {exc}"[:300]
        return out
    if not report.exists():
        out["status"] = "validate_no_report"
        return out
    try:
        rep = json.loads(report.read_text(encoding="utf-8"))
    except Exception as exc:
        out["status"] = f"report_parse_error: {exc}"[:300]
        return out
    diag = rep.get("diagnostics") or []
    errors = [d for d in diag if str(d.get("severity")).lower() == "error"]
    geom = rep.get("geometry") or {}
    out.update({
        "valid": bool(rep.get("checks_passed")) and not errors,
        "build_ok": bool(rep.get("checks_passed")) and not errors,
        "parts": int(geom.get("occurrence_count") or 0),
        "overlaps": len(errors),
        "diagnostics": [f"{d.get('severity')}:{d.get('code')}" for d in diag][:20],
        "status": "ok" if rep.get("checks_passed") else "validate_failed",
        "bbox": geom.get("bounds"),
    })
    return out


# ---------------------------------------------------------- asset generation
_LIB_TERMS = None


def _library_terms() -> tuple[set[str], set[str], dict[str, list[str]]]:
    global _LIB_TERMS
    if _LIB_TERMS is None:
        terms, ids, aliases = set(), set(), {}
        for meta_path in sorted(LIBRARY.glob("*.meta.json")):
            data = json.loads(meta_path.read_text(encoding="utf-8"))
            item_id = meta_path.name.replace(".meta.json", "")
            ids.add(item_id)
            terms.add(item_id.lower())
            for cap in (data.get("captions") or [])[:3]:
                terms.add(str(cap).lower().strip())
        apath = LIBRARY / "aliases.json"
        if apath.exists():
            aliases = json.loads(apath.read_text(encoding="utf-8")).get("categories") or {}
            for vals in aliases.values():
                terms.update(str(v).lower().strip() for v in vals)
        _LIB_TERMS = (terms, ids, aliases)
    return _LIB_TERMS


def _append_jsonl(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(obj, ensure_ascii=False) + "\n")


def score_asset_plan(ir: dict | None, payload: dict, schema_errors: list[str],
                     warnings: list[str], job_id: str, outroot: Path) -> dict:
    out = {
        "json_ok": ir is not None,
        "schema_ok": not schema_errors,
        "schema_errors": schema_errors[:20],
        "warnings": warnings[:20],
        "asset_id": payload.get("asset_id"),
        "constraints": payload.get("constraints"),
    }
    if not isinstance(ir, dict):
        return out
    rooms = _pred_rooms(ir)
    dims = [d for d in (_dims(r.get("dims_m")) for r in rooms) if d]
    area = sum(w * d for w, d in dims)
    target = float((payload.get("constraints") or {}).get("target_area_m2") or 0)
    out.update({
        "rooms_n": len(rooms),
        "rooms_with_dims": len(dims),
        "area_m2": round(area, 3),
        "target_area_m2": target,
        "area_ratio": round(area / target, 4) if target else None,
        "area_in_range": bool(target and 0.85 <= area / target <= 1.15),
        "object_total": sum(_category_counts(ir).values()),
        "categories": sorted({r.get("room_type") for r in rooms if r.get("room_type")}),
        "room_types": {r["name"]: r.get("room_type") for r in rooms if r.get("room_type")},
    })
    out["build"] = build_prediction(ir, job_id, Path(outroot))
    out["accepted"] = bool(
        out["schema_ok"] and out["area_in_range"]
        and out["build"].get("build_ok") and len(rooms) >= 3)
    if out["accepted"]:
        plans = Path(outroot) / "plans"
        plans.mkdir(parents=True, exist_ok=True)
        plan_path = plans / f"{job_id}.json"
        plan_path.write_text(json.dumps(ir, ensure_ascii=False, indent=2), encoding="utf-8")
        out["plan_path"] = str(plan_path)
        try:
            from novalib import floorplan
            png = floorplan.schematic_png(
                ir, plans / f"{job_id}.png",
                title=f'{payload.get("asset_id")} · {job_id[:8]}')
            out["plan_png"] = str(png)
        except Exception as exc:
            out["plan_png_error"] = f"{type(exc).__name__}: {exc}"[:200]
        _append_jsonl(plans / "index.jsonl",
                      {"job_id": job_id, "asset_id": payload.get("asset_id"),
                       "constraints": payload.get("constraints"),
                       "metrics": {k: out.get(k) for k in
                                   ("rooms_n", "area_m2", "area_ratio", "object_total",
                                    "accepted")},
                       "plan_path": out["plan_path"], "plan_png": out.get("plan_png")})
    return out


def score_asset_library(ir: dict | None, payload: dict, job_id: str,
                        outroot: Path) -> dict:
    out = {
        "json_ok": ir is not None,
        "focus_category": payload.get("focus_category"),
        "style": payload.get("style"),
    }
    if not isinstance(ir, dict):
        return out
    terms, ids, aliases = _library_terms()
    items = ir.get("items") if isinstance(ir.get("items"), list) else []
    alias_updates = ir.get("alias_updates") if isinstance(ir.get("alias_updates"), list) else []
    accepted, seen = [], set()
    valid = duplicates = 0
    for item in items:
        if not isinstance(item, dict):
            continue
        cat = item.get("category")
        label = str(item.get("label") or "").strip()
        size = item.get("size_m")
        valid_item = (cat in CATEGORIES and label and isinstance(size, list)
                      and len(size) >= 3
                      and all(isinstance(v, (int, float)) and v > 0 for v in size[:3]))
        if not valid_item:
            continue
        valid += 1
        key = label.lower()
        if key in terms or key in seen:
            duplicates += 1
            continue
        seen.add(key)
        accepted.append(item)
    alias_ok = 0
    valid_aliases = []
    for upd in alias_updates:
        if not isinstance(upd, dict) or upd.get("item_id") not in ids:
            continue
        add = [str(a).strip() for a in (upd.get("add_aliases") or [])
               if str(a).strip().lower() not in terms]
        if add:
            alias_ok += 1
            valid_aliases.append({"item_id": upd["item_id"], "add_aliases": add})
    out.update({
        "items_n": len(items),
        "valid_n": valid,
        "duplicate_n": duplicates,
        "accepted_n": len(accepted),
        "accepted_labels": [i.get("label") for i in accepted],
        "alias_updates_n": len(alias_updates),
        "alias_valid_n": alias_ok,
        "focus_count": (payload.get("inventory") or {}).get("count"),
    })
    if accepted or valid_aliases:
        libdir = Path(outroot) / "library"
        libdir.mkdir(parents=True, exist_ok=True)
        (libdir / f"{job_id}.json").write_text(
            json.dumps({"job_id": job_id, "focus": payload.get("focus_category"),
                        "style": payload.get("style"), "items": accepted,
                        "alias_updates": valid_aliases, "notes": ir.get("notes")},
                       ensure_ascii=False, indent=2), encoding="utf-8")
        _append_jsonl(libdir / "index.jsonl",
                      {"job_id": job_id, "focus": payload.get("focus_category"),
                       "style": payload.get("style"),
                       "items": accepted, "alias_updates": valid_aliases})
    return out

def score_judge(ir: dict | None) -> dict:
    if not isinstance(ir, dict):
        return {"json_ok": False}
    winner = str(ir.get("winner", "")).strip().lower()
    if winner not in ("a", "b", "tie"):
        return {"json_ok": True, "winner": None, "valid_winner": False,
                "criteria": ir.get("criteria"), "rationale": str(ir.get("rationale", ""))[:1000]}
    return {"json_ok": True, "winner": winner.upper(), "valid_winner": True,
            "criteria": ir.get("criteria"),
            "rationale": str(ir.get("rationale", ""))[:1000]}
