@echo off
REM Live completed-call terminal: prints every finished model call.
cd /d "%~dp0.."
title modelbench calls
C:\Python314\python.exe -u modelbench\logsync.py
echo.
echo logsync exited; press any key to close.
pause >nul
