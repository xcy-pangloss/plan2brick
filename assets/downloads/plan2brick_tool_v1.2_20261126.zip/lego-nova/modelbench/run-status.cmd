@echo off
REM Status terminal: refreshed every 60 s.
cd /d "%~dp0.."
title modelbench status
:loop
cls
echo %DATE% %TIME%
C:\Python314\python.exe -m modelbench status
timeout /t 60 /nobreak >nul
goto loop
