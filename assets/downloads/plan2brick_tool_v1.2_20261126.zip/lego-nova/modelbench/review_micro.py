"""Micro code reviews: selected high-risk functions only, 1024 output tokens.

The provider currently fails 4k-token reviews with upstream 500; this keeps
each request small enough to complete while still covering the critical paths.
"""
from __future__ import annotations

import argparse
import ast
import json
import sys
import time
from pathlib import Path

NOVA = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NOVA))

from modelbench import transport  # noqa: E402
from modelbench.config import load_config  # noqa: E402
from modelbench.quota import QuotaPolicy, parse_anchor  # noqa: E402
from modelbench.store import Store  # noqa: E402

OUT = NOVA / "modelbench" / "out_review"
TARGETS = {
    "novalib/assembly.py": ["try_place", "global_overlaps"],
    "novalib/diversity.py": ["qd_select", "_filter_dedup"],
    "modelbench/worker.py": ["_handle_future", "_ensure_filler"],
    "modelbench/scoring.py": ["score_llm_direct", "build_prediction"],
    "bench/run.py": ["run_cell"],
    "novalib/brief.py": ["apply_brief"],
}

PROMPT = """You are a senior reviewer for Plan2Brick, a floor-plan -> IR ->
deterministic LEGO pipeline. Review only the functions below for correctness,
buildability, reliability and performance. Be concrete and high-impact; no
style comments. Return ONLY JSON:

{{"file":"{file}","issues":[{{"severity":"high|medium|low","function":"...","issue":"...","why":"...","fix":"..."}}],"overall":"one paragraph"}}

Functions:
{code}
"""


def extract(path: Path, names: list[str]) -> str:
    src = path.read_text(encoding="utf-8", errors="replace")
    tree = ast.parse(src)
    segments = []
    # Include top-level functions and class methods (Worker._handle_future etc.).
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in names:
            seg = ast.get_source_segment(src, node)
            if seg and not any(seg in old for old in segments):
                segments.append(f"### {node.name}\n```python\n{seg}\n```")
    return "\n\n".join(segments)


def log(msg: str) -> None:
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}"
    print(line, flush=True)
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "run.log").open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def call_quota(cfg, store: Store, model: str, prompt: str) -> str | None:
    while True:
        cid, nxt, used = store.reserve_call_raw(model)
        if cid is None:
            wait = max(0.0, float(nxt) - time.time())
            log(f"quota full ({used}); wait {min(wait,60):.0f}s")
            time.sleep(min(wait, 60) if wait > 0 else 5)
            continue
        try:
            res = transport.call_model(cfg, model, prompt, None,
                                       max_output_tokens=1024)
            store.finish_call(cid, "ok", http_status=res.http_status,
                              latency_s=res.latency_s,
                              in_tokens=(res.usage or {}).get("in"),
                              out_tokens=(res.usage or {}).get("out"))
            return res.text or ""
        except transport.TransportError as exc:
            released = bool(exc.release_slot)
            store.finish_call(cid, "error", http_status=exc.status,
                              released=released)
            if released:
                store.release_call(cid, "review")
            if exc.status == 429:
                until = time.time() + max(5.0, float(exc.retry_after or 60.0))
                store.set_quota_block(until, exc.reported_used)
                log(f"429; wait until {time.strftime('%H:%M:%S', time.localtime(until))}")
                continue
            log(f"{model} error {exc.status}: {str(exc)[:240]}")
            return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default="claude,gpt")
    a = ap.parse_args()
    cfg = load_config()
    store = Store(cfg.state_dir / "queue.sqlite3",
                  QuotaPolicy(cfg.quota.limit, cfg.quota.window_s,
                              cfg.quota.mode, parse_anchor(cfg.quota.anchor)))
    models = [m.strip() for m in a.models.split(",") if m.strip()]
    OUT.mkdir(parents=True, exist_ok=True)
    for rel, names in TARGETS.items():
        path = NOVA / rel
        if not path.exists():
            continue
        code = extract(path, names)
        if not code:
            continue
        prompt = PROMPT.format(file=rel, code=code)
        for model in models:
            out = OUT / f"micro_{Path(rel).stem}_{model}.md"
            if out.exists():
                log(f"skip existing {out.name}")
                continue
            log(f"micro-review {rel} with {model} ({len(prompt)} chars)")
            text = call_quota(cfg, store, model, prompt)
            if text is None:
                continue
            out.write_text(text, encoding="utf-8")
            log(f"wrote {out}")
    store.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
