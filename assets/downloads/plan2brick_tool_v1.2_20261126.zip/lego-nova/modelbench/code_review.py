"""Send focused code reviews of Plan2Brick to Claude and GPT.

This is a supplemental review task, not part of the benchmark queue.  It sends
three coherent file groups (core solver / diversity+benchmark / modelbench) to
each model and stores the responses under ``modelbench/out_review``.  Calls go
through the same quota ledger and 429 handling.

Run from ``lego-nova``:

    C:\\Python314\\python.exe modelbench\\code_review.py --models claude,gpt
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

NOVA = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NOVA))

from modelbench import transport  # noqa: E402
from modelbench.config import load_config  # noqa: E402
from modelbench.quota import QuotaPolicy, parse_anchor  # noqa: E402
from modelbench.store import Store  # noqa: E402

OUT = NOVA / "modelbench" / "out_review"

GROUPS = {
    "core_solver": [
        "novalib/assembly.py",
        "novalib/brief.py",
        "novalib/walls.py",
        "novalib/floors.py",
    ],
    "diversity_bench": [
        "novalib/diversity.py",
        "novalib/variants.py",
        "bench/run.py",
    ],
    "modelbench_orchestration": [
        "modelbench/worker.py",
        "modelbench/store.py",
        "modelbench/scoring.py",
        "modelbench/tasks.py",
        "modelbench/transport.py",
    ],
}

SYSTEM = (
    "You are a senior reviewer for Plan2Brick, a floor-plan -> scene-IR -> "
    "deterministic LEGO assembly pipeline. Focus on correctness, buildability, "
    "reliability, performance and protocol mismatch. Return concrete, "
    "high-impact issues only; no style-only comments and no invented line "
    "numbers. Quote code when referring to it."
)

INSTRUCTIONS = """
Review the files below as one coherent component. Return ONLY a JSON object:

{"issues":[{"severity":"high|medium|low","file":"...","location":"function or quoted code","issue":"...","why":"...","fix":"..."}],"strengths":["..."],"overall":"one paragraph"}

Prioritise:
- bugs that can produce invalid/overlapping/unsafe geometry or wrong metrics;
- silent failure paths, non-determinism, quota/retry bugs;
- mismatches with the documented protocol (18 plans x 4 briefs, K=6, pool=24);
- performance or memory traps in the hot path.

Files:
"""


def log(msg: str) -> None:
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}"
    print(line, flush=True)
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "run.log").open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def call_quota(cfg, store: Store, model: str, prompt: str) -> str | None:
    while True:
        cid, nxt, used = store.reserve_call_raw(model)
        if cid is None:
            wait = max(0.0, float(nxt) - time.time())
            log(f"quota full ({used}); wait {min(wait,60):.0f}s")
            time.sleep(min(wait, 60) if wait > 0 else 5)
            continue
        try:
            res = transport.call_model(cfg, model, prompt, None,
                                       max_output_tokens=4096)
            store.finish_call(cid, "ok", http_status=res.http_status,
                              latency_s=res.latency_s,
                              in_tokens=(res.usage or {}).get("in"),
                              out_tokens=(res.usage or {}).get("out"))
            return res.text or ""
        except transport.TransportError as exc:
            released = bool(exc.release_slot)
            store.finish_call(cid, "error", http_status=exc.status,
                              released=released)
            if released:
                store.release_call(cid, "review")
            if exc.status == 429:
                until = time.time() + max(5.0, float(exc.retry_after or 60.0))
                store.set_quota_block(until, exc.reported_used)
                log(f"429; wait until {time.strftime('%H:%M:%S', time.localtime(until))}")
                continue
            log(f"{model} error {exc.status}: {str(exc)[:240]}")
            return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default="claude,gpt")
    ap.add_argument("--groups", default=",".join(GROUPS))
    a = ap.parse_args()
    cfg = load_config()
    store = Store(cfg.state_dir / "queue.sqlite3",
                  QuotaPolicy(cfg.quota.limit, cfg.quota.window_s,
                              cfg.quota.mode, parse_anchor(cfg.quota.anchor)))
    OUT.mkdir(parents=True, exist_ok=True)
    models = [m.strip() for m in a.models.split(",") if m.strip()]
    groups = [g.strip() for g in a.groups.split(",") if g.strip()]
    for group in groups:
        if group not in GROUPS:
            log(f"unknown group {group}")
            continue
        parts = [INSTRUCTIONS]
        for rel in GROUPS[group]:
            path = NOVA / rel
            if not path.exists():
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
            parts.append(f"\n### FILE: {rel}\n```python\n{text}\n```\n")
        prompt = "\n".join(parts)
        for model in models:
            path = OUT / f"{group}_{model}.md"
            if path.exists():
                log(f"skip existing {path.name}")
                continue
            log(f"review {group} with {model} ({len(prompt)} chars)")
            text = call_quota(cfg, store, model, prompt)
            if text is None:
                continue
            path.write_text(text, encoding="utf-8")
            log(f"wrote {path}")
    store.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
