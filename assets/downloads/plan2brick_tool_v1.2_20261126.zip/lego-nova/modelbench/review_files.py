"""Per-file Claude/GPT review of the highest-risk Plan2Brick files.

Small prompts complete reliably under the provider's upstream limits, unlike
the whole-group bundle.  Results go to ``modelbench/out_review``.

    C:\\Python314\\python.exe modelbench\\review_files.py --models claude,gpt
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

NOVA = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NOVA))

from modelbench import transport  # noqa: E402
from modelbench.config import load_config  # noqa: E402
from modelbench.quota import QuotaPolicy, parse_anchor  # noqa: E402
from modelbench.store import Store  # noqa: E402

OUT = NOVA / "modelbench" / "out_review"
FILES = [
    "novalib/assembly.py",
    "novalib/diversity.py",
    "modelbench/worker.py",
    "modelbench/scoring.py",
    "bench/run.py",
    "novalib/brief.py",
]

PROMPT = """You are a senior reviewer for Plan2Brick, a floor-plan -> scene-IR ->
deterministic LEGO pipeline. Review the single file below for correctness,
buildability, reliability, performance and protocol mismatch. Focus on
high-impact, concrete issues; do not give style-only comments or invent line
numbers.

Return ONLY a JSON object:
{{"file":"{file}","issues":[{{"severity":"high|medium|low","location":"function or quoted code","issue":"...","why":"...","fix":"..."}}],"strengths":["..."],"overall":"one paragraph"}}

File:
```python
{code}
```
"""


def log(msg: str) -> None:
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}"
    print(line, flush=True)
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "run.log").open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def call_quota(cfg, store: Store, model: str, prompt: str) -> str | None:
    while True:
        cid, nxt, used = store.reserve_call_raw(model)
        if cid is None:
            wait = max(0.0, float(nxt) - time.time())
            log(f"quota full ({used}); wait {min(wait,60):.0f}s")
            time.sleep(min(wait, 60) if wait > 0 else 5)
            continue
        try:
            res = transport.call_model(cfg, model, prompt, None,
                                       max_output_tokens=4096)
            store.finish_call(cid, "ok", http_status=res.http_status,
                              latency_s=res.latency_s,
                              in_tokens=(res.usage or {}).get("in"),
                              out_tokens=(res.usage or {}).get("out"))
            return res.text or ""
        except transport.TransportError as exc:
            released = bool(exc.release_slot)
            store.finish_call(cid, "error", http_status=exc.status,
                              released=released)
            if released:
                store.release_call(cid, "review")
            if exc.status == 429:
                until = time.time() + max(5.0, float(exc.retry_after or 60.0))
                store.set_quota_block(until, exc.reported_used)
                log(f"429; wait until {time.strftime('%H:%M:%S', time.localtime(until))}")
                continue
            log(f"{model} error {exc.status}: {str(exc)[:240]}")
            return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default="claude,gpt")
    ap.add_argument("--files", default=",".join(FILES))
    a = ap.parse_args()
    cfg = load_config()
    store = Store(cfg.state_dir / "queue.sqlite3",
                  QuotaPolicy(cfg.quota.limit, cfg.quota.window_s,
                              cfg.quota.mode, parse_anchor(cfg.quota.anchor)))
    models = [m.strip() for m in a.models.split(",") if m.strip()]
    files = [x.strip() for x in a.files.split(",") if x.strip()]
    OUT.mkdir(parents=True, exist_ok=True)
    for rel in files:
        path = NOVA / rel
        if not path.exists():
            log(f"missing {rel}")
            continue
        code = path.read_text(encoding="utf-8", errors="replace")
        prompt = PROMPT.format(file=rel, code=code)
        for model in models:
            out = OUT / f"file_{Path(rel).stem}_{model}.md"
            if out.exists():
                log(f"skip existing {out.name}")
                continue
            log(f"review {rel} with {model} ({len(prompt)} chars)")
            text = call_quota(cfg, store, model, prompt)
            if text is None:
                continue
            out.write_text(text, encoding="utf-8")
            log(f"wrote {out}")
    store.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
