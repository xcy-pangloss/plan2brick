@echo off
REM One visible worker terminal. Argument 1 = concurrency (default 1).
cd /d "%~dp0.."
setlocal
set CONC=%~1
if "%CONC%"=="" set CONC=1
set CFG=%~dp0config.local.json
title modelbench worker - concurrency %CONC%
echo ============================================================
echo  modelbench worker
echo  config:      %CFG%
echo  concurrency: %CONC%
echo  state:       %~dp0state\queue.sqlite3
echo  calls log:   %~dp0state\calls.log
echo ============================================================
:loop
C:\Python314\python.exe -u -m modelbench run --config "%CFG%" --concurrency %CONC% --max-reps 8 --status-every 300
echo.
echo worker exited with %ERRORLEVEL%; restarting in 10 s (close this window to stop).
timeout /t 10 /nobreak >nul
goto loop
