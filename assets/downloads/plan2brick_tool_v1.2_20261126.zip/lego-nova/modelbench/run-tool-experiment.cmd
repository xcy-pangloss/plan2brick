@echo off
REM Controlled tool-vs-native-AI experiment (DeepSeek / Claude / GPT).
cd /d "%~dp0.."
title tool vs native AI
echo ============================================================
echo  Tool vs native AI
echo  arms: A raw LDraw / B LLM IR + builder / P Plan2Brick
echo  cases: R2-B1, R4-B1, R6-B1, R6-B4
echo  results: modelbench\out_experiment\results.md
echo ============================================================
C:\Python314\python.exe -u modelbench\tool_vs_ai.py %*
echo.
echo experiment finished; press any key to close.
pause >nul
