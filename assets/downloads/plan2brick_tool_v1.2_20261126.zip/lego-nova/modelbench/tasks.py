"""Task matrix, prompt rendering and stable job ids.

Job ids are content hashes of ``(kind, model, payload, prompt hash, rep)``.
Re-running ``plan`` is therefore idempotent, and editing a prompt creates new
jobs instead of silently mixing old and new results.
"""
from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path

from . import catalogue

HERE = Path(__file__).resolve().parent
NOVA = HERE.parent
PROMPTS = HERE / "prompts"

PROMPT_FILES = {
    "perception": "perception_v1.md",
    "perception_compact": "perception_compact_v1.md",
    "llm_direct": "llm_direct_v1.md",
    "judge": "judge_v1.md",
    "asset_plan": "asset_plan_v1.md",
    "asset_library": "asset_library_v1.md",
    "raw_ldraw": "raw_ldraw_v2.md",
}


def prompt_text(kind: str) -> str:
    return (PROMPTS / PROMPT_FILES[kind]).read_text(encoding="utf-8")


def prompt_hash(kind: str) -> str:
    return hashlib.sha256(prompt_text(kind).encode("utf-8")).hexdigest()[:16]


def _canonical(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def job_id(kind: str, model: str, payload: dict, rep: int) -> str:
    raw = _canonical({"kind": kind, "model": model, "payload": payload, "rep": rep,
                      "prompt": prompt_hash(kind)})
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]


def _spec(kind: str, model: str, payload: dict, rep: int, priority: int,
          max_attempts: int = 3) -> dict:
    return {
        "id": job_id(kind, model, payload, rep),
        "kind": kind,
        "model": model,
        "payload": payload,
        "rep": rep,
        "priority": priority,
        "prompt_hash": prompt_hash(kind),
        "max_attempts": max_attempts,
    }


def _applicable(brief_id: str, result: dict) -> bool:
    if result.get("unmatched"):
        return False
    actions = result.get("actions") or []
    if brief_id == "B1":
        return any(a["action"] == "add" for a in actions)
    if brief_id == "B2":
        return any(a["action"] == "remove" and a.get("removed", 0) > 0 for a in actions)
    if brief_id == "B3":
        return any(a["action"] == "replace" and a.get("removed", 0) > 0 for a in actions)
    if brief_id == "B4":
        return any(a["action"] == "use" and a.get("objects", 0) > 0 for a in actions)
    return bool(actions)


def _rooms_for_prompt(ir: dict) -> list[dict]:
    rooms = []
    for r in ir.get("rooms") or []:
        entry = {
            "name_cn": r.get("name_cn") or r.get("name_en"),
            "name_en": r.get("name_en") or r.get("name_cn"),
            "dims_m": r.get("dims_m"),
        }
        if r.get("room_type"):
            entry["room_type"] = r["room_type"]
        rooms.append(entry)
    return rooms


def make_jobs(kind: str, cfg, models: list[str], reps: int = 1,
              judge_run: str | Path | None = None, judge_pairs: int | None = None,
              max_attempts: int = 3,
              categories: list[str] | None = None) -> tuple[list[dict], list[str]]:
    if kind == "perception":
        return _perception_jobs(cfg, models, reps, max_attempts)
    if kind == "perception_compact":
        return _perception_jobs(cfg, models, reps, max_attempts,
                                kind="perception_compact",
                                prompt_id="perception_compact_v1")
    if kind == "llm_direct":
        return _llm_direct_jobs(cfg, models, reps, max_attempts)
    if kind == "judge":
        return _judge_jobs(cfg, models, judge_run, judge_pairs, max_attempts)
    if kind == "asset_plan":
        return _asset_plan_jobs(cfg, models, reps, max_attempts)
    if kind == "asset_library":
        return _asset_library_jobs(cfg, models, reps, max_attempts, categories=categories)
    if kind == "raw_ldraw":
        return _raw_ldraw_jobs(cfg, models, reps, max_attempts)
    raise ValueError(f"unknown task kind {kind!r}")


def _perception_jobs(cfg, models: list[str], reps: int, max_attempts: int,
                     kind: str = "perception",
                     prompt_id: str = "perception_v1"
                     ) -> tuple[list[dict], list[str]]:
    plans = catalogue.load_plans(only_images=True)
    missing = catalogue.validate_images(plans)
    if missing:
        raise FileNotFoundError("missing perception inputs: " + "; ".join(missing))
    specs = []
    for plan in plans:
        payload = {
            "plan_id": plan["id"],
            "split": plan.get("split"),
            "provenance": plan.get("provenance"),
            "topology": plan.get("topology"),
            "image": plan["image"],
            "gt_ir": plan["gt_ir"],
            "gt_rooms": plan.get("gt_rooms"),
            "gt_source": plan.get("gt_source"),
            "prompt_id": prompt_id,
        }
        for model in models:
            if not cfg.model(model).vision:
                continue
            for rep in range(reps):
                specs.append(_spec(kind, model, payload, rep,
                                   priority=10 + rep,
                                   max_attempts=max_attempts))
    return specs, []


def _llm_direct_jobs(cfg, models: list[str], reps: int, max_attempts: int
                     ) -> tuple[list[dict], list[str]]:
    from novalib import brief as brief_lib

    plans = catalogue.load_all_plans()
    briefs = catalogue.load_briefs()
    specs = []
    skipped = []
    for plan in plans:
        ir = catalogue.load_plan_ir(plan)
        rooms = _rooms_for_prompt(ir)
        for brf in briefs:
            patched = brief_lib.apply_brief(ir, brf["text"])
            if not _applicable(brf["id"], patched):
                skipped.append(f"{plan['id']}x{brf['id']}")
                continue
            payload = {
                "plan_id": plan["id"],
                "split": plan.get("split"),
                "provenance": plan.get("provenance"),
                "topology": plan.get("topology"),
                "area_m2": plan.get("area_m2"),
                "base_ir": plan["path"],
                "rooms": rooms,
                "brief_id": brf["id"],
                "brief_type": brf["type"],
                "brief_text": brf["text"],
                "prompt_id": "llm_direct_v1",
            }
            for model in models:
                for rep in range(reps):
                    specs.append(_spec("llm_direct", model, payload, rep,
                                       priority=20 + rep,
                                       max_attempts=max_attempts))
    return specs, skipped


def _candidate_summary(c: dict) -> dict:
    return {
        "name": c.get("name"),
        "style": c.get("style"),
        "palette": c.get("palette"),
        "wall_profile": c.get("wall_profile"),
        "topology_mode": c.get("topology_mode"),
        "coverage": c.get("coverage_ratio"),
        "rooms": c.get("rooms"),
        "rooms_targeted": c.get("rooms_targeted"),
        "rooms_furnished": c.get("rooms_furnished"),
        "parts": c.get("parts"),
        "overlaps": c.get("overlaps"),
        "program": c.get("program"),
        "quality": c.get("quality"),
        "valid": c.get("valid"),
    }


def _judge_jobs(cfg, models: list[str], judge_run: str | Path | None,
                judge_pairs: int | None, max_attempts: int
                ) -> tuple[list[dict], list[str]]:
    if not judge_run:
        raise ValueError("judge tasks need --judge-run pointing at a bench run directory")
    run = Path(judge_run).resolve()
    cells = sorted((run / "cells").glob("*/manifest.json"))
    if not cells:
        raise FileNotFoundError(f"no cell manifests under {run / 'cells'}")
    specs = []
    skipped = []
    for mpath in cells:
        manifest = json.loads(mpath.read_text(encoding="utf-8"))
        pool = {c["name"]: c for c in manifest.get("pool") or []}
        selected = [pool[n] for n in manifest.get("selected") or [] if n in pool]
        if len(selected) < 2:
            skipped.append(mpath.parent.name)
            continue
        pairs = list(itertools.combinations(selected, 2))
        if judge_pairs:
            pairs = pairs[:int(judge_pairs)]
        plan_id = (manifest.get("bench") or {}).get("plan", {}).get("id") \
            or mpath.parent.name.split("__")[0]
        brief = (manifest.get("bench") or {}).get("brief") or {}
        for a, b in pairs:
            payload = {
                "plan_id": plan_id,
                "brief_id": brief.get("id"),
                "brief_text": brief.get("text"),
                "cell": mpath.parent.name,
                "candidate_a": _candidate_summary(a),
                "candidate_b": _candidate_summary(b),
                "prompt_id": "judge_v1",
            }
            for model in models:
                specs.append(_spec("judge", model, payload, 0, priority=100,
                                   max_attempts=max_attempts))
    return specs, skipped


# ---------------------------------------------------------- asset generation
ASSET_TOPOLOGIES = [
    {"topology": "studio", "room_budget": 4, "base_area": 40},
    {"topology": "1-bed", "room_budget": 5, "base_area": 50},
    {"topology": "2-bed", "room_budget": 7, "base_area": 66},
    {"topology": "3-bed", "room_budget": 9, "base_area": 95},
    {"topology": "corridor", "room_budget": 6, "base_area": 60},
    {"topology": "l-shape", "room_budget": 6, "base_area": 72},
    {"topology": "open-plan", "room_budget": 6, "base_area": 78},
]
ASSET_AREA_MULTIPLIERS = [0.85, 1.0, 1.15]
ASSET_STYLES = ["balanced", "family", "work-from-home", "minimal"]
LIBRARY_STYLES = ["minimal", "balanced", "family", "work-from-home", "compact", "spacious"]
LIBRARY = NOVA.parent / "fyp-pipeline" / "library"


def _library_inventory() -> dict:
    aliases = {}
    apath = LIBRARY / "aliases.json"
    if apath.exists():
        aliases = (json.loads(apath.read_text(encoding="utf-8")).get("categories") or {})
    inv = {}
    for meta_path in sorted(LIBRARY.glob("*.meta.json")):
        data = json.loads(meta_path.read_text(encoding="utf-8"))
        cat = data.get("category") or "other"
        item_id = meta_path.name.replace(".meta.json", "")
        entry = {
            "item_id": item_id,
            "captions": [str(c)[:140] for c in (data.get("captions") or [])[:2]],
            "size_studs": data.get("size_studs") or data.get("size_LSH_studs"),
        }
        inv.setdefault(cat, {"items": [], "aliases": aliases.get(cat, [])})["items"].append(entry)
    for cat, entry in inv.items():
        entry["count"] = len(entry["items"])
        entry["items"] = entry["items"][:8]
    return inv


def _asset_plan_jobs(cfg, models: list[str], reps: int, max_attempts: int
                     ) -> tuple[list[dict], list[str]]:
    specs = []
    for topo in ASSET_TOPOLOGIES:
        for mult in ASSET_AREA_MULTIPLIERS:
            for style in ASSET_STYLES:
                area = int(round(topo["base_area"] * mult))
                asset_id = f'{topo["topology"]}_{area}m2_{style}'
                for rep in range(reps):
                    payload = {
                        "asset_id": asset_id,
                        "constraints": {
                            "topology": topo["topology"],
                            "target_area_m2": area,
                            "room_budget": topo["room_budget"],
                            "style": style,
                            "variant": rep,
                        },
                        "prompt_id": "asset_plan_v1",
                    }
                    for model in models:
                        specs.append(_spec("asset_plan", model, payload, rep,
                                           priority=70 + rep * 2,
                                           max_attempts=max_attempts))
    return specs, []


def _asset_library_jobs(cfg, models: list[str], reps: int, max_attempts: int,
                        categories: list[str] | None = None
                        ) -> tuple[list[dict], list[str]]:
    inventory = _library_inventory()
    if categories:
        wanted = {c.strip().lower() for c in categories if c.strip()}
        inventory = {k: v for k, v in inventory.items() if k.lower() in wanted}
    specs = []
    for category in sorted(inventory):
        for style in LIBRARY_STYLES:
            for rep in range(reps):
                payload = {
                    "focus_category": category,
                    "style": style,
                    "inventory": inventory[category],
                    "variant": rep,
                    "prompt_id": "asset_library_v1",
                }
                for model in models:
                    specs.append(_spec("asset_library", model, payload, rep,
                                       priority=75 + rep * 2,
                                       max_attempts=max_attempts))
    return specs, []


# ------------------------------------------------------------------ prompts
RAW_CASES = [("R2", "B1"), ("R4", "B1"), ("R6", "B1"), ("R6", "B4")]


def _raw_ldraw_jobs(cfg, models: list[str], reps: int, max_attempts: int
                    ) -> tuple[list[dict], list[str]]:
    """Deferred native-AI raw LDraw attempts (after asset generation)."""
    plans = {p["id"]: p for p in catalogue.load_all_plans()}
    briefs = {b["id"]: b for b in catalogue.load_briefs()}
    specs = []
    for plan_id, brief_id in RAW_CASES:
        plan, brf = plans[plan_id], briefs[brief_id]
        payload = {
            "plan_id": plan_id, "brief_id": brief_id,
            "rooms": _rooms_for_prompt(catalogue.load_plan_ir(plan)),
            "brief_text": brf["text"], "prompt_id": "raw_ldraw_v2",
        }
        for model in models:
            if not cfg.model(model).model:
                continue
            for rep in range(reps):
                specs.append(_spec("raw_ldraw", model, payload, rep,
                                   priority=90 + rep, max_attempts=max_attempts))
    return specs, []
def render_prompt(kind: str, payload: dict) -> str:
    base = prompt_text(kind)
    if kind in ("perception", "perception_compact"):
        return base
    if kind == "llm_direct":
        plan = {
            "plan_id": payload["plan_id"],
            "split": payload.get("split"),
            "provenance": payload.get("provenance"),
            "topology": payload.get("topology"),
            "area_m2": payload.get("area_m2"),
            "rooms": payload.get("rooms"),
        }
        brief = {
            "id": payload["brief_id"],
            "type": payload["brief_type"],
            "text": payload["brief_text"],
        }
        return (base + "\n\nInput:\n```json\n"
                + json.dumps({"plan": plan, "brief": brief},
                             ensure_ascii=False, indent=2)
                + "\n```\n")
    if kind == "judge":
        data = {
            "plan_id": payload["plan_id"],
            "brief": {"id": payload.get("brief_id"), "text": payload.get("brief_text")},
            "candidate_a": payload["candidate_a"],
            "candidate_b": payload["candidate_b"],
        }
        return (base + "\n\nCandidates:\n```json\n"
                + json.dumps(data, ensure_ascii=False, indent=2)
                + "\n```\n")
    if kind == "asset_plan":
        return (base + "\n\nConstraints:\n```json\n"
                + json.dumps(payload["constraints"], ensure_ascii=False, indent=2)
                + "\n```\n")
    if kind == "asset_library":
        data = {
            "focus_category": payload["focus_category"],
            "style": payload["style"],
            "inventory": payload["inventory"],
            "variant": payload.get("variant", 0),
        }
        return (base + "\n\nLibrary focus:\n```json\n"
                + json.dumps(data, ensure_ascii=False, indent=2)
                + "\n```\n")
    if kind == "raw_ldraw":
        data = {"plan": {"id": payload["plan_id"], "rooms": payload["rooms"]},
                "brief": {"id": payload["brief_id"], "text": payload["brief_text"]}}
        return (base + "\n\nInput:\n```json\n"
                + json.dumps(data, ensure_ascii=False, indent=2)
                + "\n```\n")
    raise ValueError(kind)


def prompt_and_images(kind: str, payload: dict) -> tuple[str, list[str]]:
    prompt = render_prompt(kind, payload)
    images = [payload["image"]] if kind in ("perception", "perception_compact") else []
    return prompt, images
