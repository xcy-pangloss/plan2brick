"""Command line for the Plan2Brick multi-model comparison harness.

Run from ``lego-nova/`` so that ``novalib`` is importable:

    python -m modelbench init-config
    python -m modelbench validate-config
    python -m modelbench plan --tasks perception,llm_direct --reps 1
    python -m modelbench run --concurrency 4
    python -m modelbench status
    python -m modelbench report

The API key is read from the environment variable named in the config; the
harness never prints it.
"""
from __future__ import annotations

import argparse
import copy
import json
import logging
import os
import sys
import threading
import time
from pathlib import Path

from . import catalogue, report, tasks, transport
from .config import (BenchConfig, ConfigError, DEFAULT_CONFIG, EXAMPLE_CONFIG,
                     load_config, write_example)
from .quota import QuotaPolicy, parse_anchor
from .store import Store
from .worker import Worker

DEFAULT_JUDGE_RUN = Path(__file__).resolve().parents[1] / "bench" / "out" \
    / "v13_main_table" / "d3_fidelity"


def _judge_run(value: str | None) -> str:
    if value:
        return value
    return str(DEFAULT_JUDGE_RUN) if DEFAULT_JUDGE_RUN.exists() else ""


def _models(cfg: BenchConfig, text: str | None) -> list[str]:
    if text:
        names = [s.strip() for s in text.split(",") if s.strip()]
        for n in names:
            if n not in cfg.models:
                raise ConfigError(f"unknown model {n!r}; configured: {sorted(cfg.models)}")
        return names
    return sorted(cfg.models)


def _tasks(text: str | None) -> list[str]:
    names = [s.strip() for s in (text or "perception,llm_direct").split(",") if s.strip()]
    for n in names:
        if n not in tasks.PROMPT_FILES:
            raise ConfigError(f"unknown task {n!r}; choose from {sorted(tasks.PROMPT_FILES)}")
    return names


def _store(cfg: BenchConfig, path: str | None = None) -> Store:
    policy = QuotaPolicy(limit=cfg.quota.limit, window_s=cfg.quota.window_s,
                         mode=cfg.quota.mode, anchor=parse_anchor(cfg.quota.anchor),
                         exempt_models=frozenset(cfg.quota.exempt_models),
                         model_limits={m: (int(v.get("limit", cfg.quota.limit)),
                                           float(v.get("window_hours", cfg.quota.window_hours)) * 3600.0)
                                       for m, v in cfg.quota.model_limits.items()})
    db = Path(path) if path else cfg.state_dir / "queue.sqlite3"
    return Store(db, policy)


def _mock_config(cfg: BenchConfig) -> BenchConfig:
    """Return a copy whose models all use the mock transport (no network)."""
    out = copy.deepcopy(cfg)
    from .config import ProviderConfig
    out.providers["__mock__"] = ProviderConfig(name="__mock__", protocol="mock",
                                               base_url="", api_key_env="")
    for m in out.models.values():
        m.provider = "__mock__"
    return out


def cmd_init(a) -> int:
    target = Path(a.path) if a.path else DEFAULT_CONFIG
    if target.exists():
        print(f"exists: {target}")
        return 0
    write_example(target)
    print(f"created {target}\nEdit the provider endpoint, model ids and quota, "
          f"then set the API key environment variable.")
    return 0


def cmd_validate(a) -> int:
    cfg = load_config(a.config)
    print(f"config : {cfg.path}")
    print(f"quota  : {cfg.quota.limit} calls / {cfg.quota.window_hours:g} h "
          f"({cfg.quota.mode})")
    print(f"state  : {cfg.state_dir}\nout    : {cfg.out_dir}")
    print("\nproviders:")
    for name, p in cfg.providers.items():
        if p.protocol == "mock":
            key_state = "mock"
        else:
            try:
                cfg.api_key(name)
                key_state = "set"
            except ConfigError:
                key_state = (f"MISSING {p.api_key_env}" if p.api_key_env
                             else "MISSING key file/path")
        print(f"  {name:18s} {p.protocol:10s} {p.base_url or '-':45s} key={key_state}")
    print("\nmodels:")
    placeholders = []
    for name, m in cfg.models.items():
        if "MODEL_ID" in m.model:
            placeholders.append(name)
        print(f"  {name:10s} provider={m.provider:16s} model={m.model:35s} "
              f"vision={m.vision} weight={m.weight}")
    for name, p in cfg.providers.items():
        if "YOUR-PROVIDER" in p.base_url:
            placeholders.append(f"{name}@base_url")
    if placeholders:
        print("\nWARNING: placeholder values still present: " + ", ".join(placeholders))
    plans = catalogue.load_plans(only_images=True)
    missing = catalogue.validate_images(plans)
    print(f"\nperception inputs: {len(plans)} plans, "
          f"{'all present' if not missing else 'MISSING: ' + '; '.join(missing)}")
    return 0 if not missing else 1


def cmd_plan(a) -> int:
    cfg = load_config(a.config)
    models = _models(cfg, a.models)
    kinds = _tasks(a.tasks)
    store = _store(cfg, a.state_db)
    total_new = total_old = 0
    judge_run = _judge_run(a.judge_run) if "judge" in kinds else a.judge_run
    categories = [x.strip() for x in (a.categories or "").split(",") if x.strip()]
    for kind in kinds:
        try:
            specs, skipped = tasks.make_jobs(
                kind, cfg, models, reps=a.reps, judge_run=judge_run,
                judge_pairs=a.judge_pairs, max_attempts=a.max_attempts,
                categories=categories)
        except Exception as exc:
            print(f"[{kind}] ERROR: {exc}", file=sys.stderr)
            continue
        new, old = store.enqueue(specs)
        total_new += new
        total_old += old
        print(f"[{kind}] {len(specs)} jobs ({new} new, {old} existing)"
              + (f", {len(skipped)} skipped: {', '.join(skipped)}" if skipped else ""))
    print(f"\nenqueued {total_new} new jobs ({total_old} already present)")
    print(report.status_text(store, cfg))
    store.close()
    return 0


def cmd_run(a) -> int:
    cfg = load_config(a.config)
    if a.dry_run:
        cfg = _mock_config(cfg)
    models = _models(cfg, a.models)
    store = _store(cfg, a.state_db)
    judge_run = _judge_run(a.judge_run)
    pace_s = (cfg.quota.window_s / cfg.quota.limit) if a.pace else 0.0
    worker = Worker(cfg, store, models, concurrency=a.concurrency,
                    max_reps=a.max_reps, low_watermark=a.low_watermark,
                    judge_run=judge_run, judge_pairs=a.judge_pairs,
                    build=False if a.no_build else None,
                    auto_fill=not a.no_fill, pace_s=pace_s)
    if a.status_every:
        def ticker():
            while not worker._stop.is_set():
                time.sleep(a.status_every)
                if worker._stop.is_set():
                    break
                print("\n" + report.status_text(store, cfg), flush=True)
        threading.Thread(target=ticker, daemon=True).start()
    print(report.status_text(store, cfg), flush=True)
    try:
        result = worker.run(max_calls=a.max_calls, once=a.once,
                            idle_sleep=a.idle_sleep)
    except KeyboardInterrupt:
        worker.stop()
        print("\nstopped by user; in-flight calls are counted in the quota ledger.")
        result = {"calls": 0, "counts": store.counts()}
    print("\n" + json.dumps(result, ensure_ascii=False, indent=2))
    print("\n" + report.status_text(store, cfg))
    store.close()
    return 0


def cmd_probe(a) -> int:
    """One tiny call per model, recorded in the same quota ledger."""
    cfg = load_config(a.config)
    models = _models(cfg, a.models)
    store = _store(cfg, a.state_db)
    image = str(Path(a.image).resolve()) if a.image else None
    prompt = ("Describe the attached image in one short sentence."
              if image else 'Return exactly this JSON and nothing else: {"ok":true}')
    rc = 0
    for model in models:
        call_id, nxt, used = store.reserve_call_raw(model)
        if call_id is None:
            print(f"{model}: quota full ({used}/{cfg.quota.limit}); "
                  f"next slot in {max(0, int(nxt - time.time()))}s")
            rc = 1
            break
        try:
            res = transport.call_model(cfg, model, prompt,
                                       [image] if image else None,
                                       max_output_tokens=512)
            store.finish_call(call_id, "ok", http_status=res.http_status,
                              latency_s=res.latency_s,
                              in_tokens=(res.usage or {}).get("in"),
                              out_tokens=(res.usage or {}).get("out"))
            text = " ".join((res.text or "").split())[:160]
            print(f"{model:10s} OK  {res.latency_s:6.2f}s  "
                  f"in/out={res.usage.get('in')}/{res.usage.get('out')}  {text}")
        except transport.TransportError as exc:
            released = bool(exc.release_slot)
            store.finish_call(call_id, "error", http_status=exc.status,
                              latency_s=None, released=released)
            if released:
                store.release_call(call_id, "probe_preflight")
            if exc.status == 429:
                until = time.time() + max(5.0, float(exc.retry_after or 60.0))
                store.set_quota_block(until, exc.reported_used)
                print(f"{model:10s} 429 quota exhausted; resume at "
                      f"{time.strftime('%H:%M:%S', time.localtime(until))} "
                      f"(provider used={exc.reported_used})")
                rc = 1
                break
            print(f"{model:10s} ERR status={exc.status} release={released}  {str(exc)[:240]}")
            rc = 1
        except Exception as exc:
            store.finish_call(call_id, "error")
            print(f"{model:10s} ERR {type(exc).__name__}: {exc}")
            rc = 1
    print("\n" + report.status_text(store, cfg))
    store.close()
    return rc


def cmd_assets(a) -> int:
    cfg = load_config(a.config)
    root = Path(a.out) if a.out else cfg.out_dir / "assets"
    plans = _read_jsonl(root / "plans" / "index.jsonl")
    library = _read_jsonl(root / "library" / "index.jsonl")
    print(f"assets root: {root}")
    print(f"accepted plans: {len(plans)}")
    by_topology = {}
    for row in plans:
        topo = (row.get("constraints") or {}).get("topology") or "?"
        by_topology[topo] = by_topology.get(topo, 0) + 1
    print("  by topology: " + ", ".join(f"{k} {v}" for k, v in sorted(by_topology.items())))
    print(f"library batches: {len(library)}")
    cat_count = {}
    for row in library:
        for item in row.get("items") or []:
            cat = item.get("category") or "?"
            cat_count[cat] = cat_count.get(cat, 0) + 1
    print("  accepted items by category: "
          + (", ".join(f"{k} {v}" for k, v in sorted(cat_count.items())) or "-"))
    print("  latest plan files:")
    for row in plans[-5:]:
        print(f"    {row.get('plan_png') or row.get('plan_path')}")
    print("  latest library candidates:")
    for row in library[-5:]:
        labels = [i.get("label") for i in (row.get("items") or [])]
        print(f"    {row.get('focus')}: {', '.join(labels) or '-'}")
    return 0


def _read_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return out


def cmd_status(a) -> int:
    cfg = load_config(a.config)
    store = _store(cfg, a.state_db)
    print(report.status_text(store, cfg))
    if a.json:
        print(json.dumps({"counts": store.counts(),
                          "quota": store.quota_status(),
                          "by_model": store.counts_by_model(),
                          "by_kind": store.counts_by_kind()},
                         ensure_ascii=False, indent=2))
    store.close()
    return 0


def cmd_report(a) -> int:
    cfg = load_config(a.config)
    store = _store(cfg, a.state_db)
    path = report.write_report(store, cfg, out_dir=a.out)
    print(f"report: {path}")
    print(report.status_text(store, cfg))
    store.close()
    return 0


def cmd_reset_stale(a) -> int:
    cfg = load_config(a.config)
    store = _store(cfg, a.state_db)
    n = store.reset_stale(max_age_s=a.max_age)
    print(f"reset {n} stale running jobs")
    store.close()
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default=None, help="config JSON (default: config.local.json)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def subparser(name, help_text):
        p = sub.add_parser(name, help=help_text)
        # allow --config after the subcommand as well as before it
        p.add_argument("--config", default=argparse.SUPPRESS)
        return p

    p = subparser("init-config", "create config.local.json from the example")
    p.add_argument("--path", default=None)
    p.set_defaults(func=cmd_init)

    p = subparser("validate-config", "show resolved providers/models and check inputs")
    p.set_defaults(func=cmd_validate)

    p = subparser("plan", "enqueue the fixed task matrix")
    p.add_argument("--tasks", default="perception,llm_direct",
                   help="comma-separated: perception,llm_direct,judge")
    p.add_argument("--models", default="")
    p.add_argument("--reps", type=int, default=1)
    p.add_argument("--judge-run", default="", help="bench run directory for judge tasks")
    p.add_argument("--judge-pairs", type=int, default=None,
                   help="limit pairs per cell for judge tasks")
    p.add_argument("--max-attempts", type=int, default=3)
    p.add_argument("--categories", default="",
                   help="asset_library only: comma-separated category filter")
    p.add_argument("--state-db", default=None)
    p.set_defaults(func=cmd_plan)

    p = subparser("run", "run the quota-aware scheduler")
    p.add_argument("--models", default="")
    p.add_argument("--concurrency", type=int, default=4)
    p.add_argument("--max-reps", type=int, default=8,
                   help="replication ceiling used by the filler generator")
    p.add_argument("--low-watermark", type=int, default=None)
    p.add_argument("--judge-run", default="", help="bench run directory for filler judge tasks")
    p.add_argument("--judge-pairs", type=int, default=None)
    p.add_argument("--max-calls", type=int, default=None)
    p.add_argument("--once", action="store_true", help="drain the queue, then exit")
    p.add_argument("--idle-sleep", type=float, default=10.0)
    p.add_argument("--status-every", type=float, default=0.0)
    p.add_argument("--no-build", action="store_true",
                   help="skip deterministic assembly for LLM/perception outputs")
    p.add_argument("--no-fill", action="store_true",
                   help="do not auto-extend the replication tail")
    p.add_argument("--pace", action="store_true",
                   help="space calls at window_s/limit (72 s for 150/3 h) instead of bursting")
    p.add_argument("--dry-run", action="store_true",
                   help="use the mock transport; no network calls")
    p.add_argument("--state-db", default=None)
    p.set_defaults(func=cmd_run)

    p = subparser("probe", "one tiny call per model, recorded in the quota ledger")
    p.add_argument("--models", default="")
    p.add_argument("--image", default="", help="optional image path for a vision probe")
    p.add_argument("--state-db", default=None)
    p.set_defaults(func=cmd_probe)

    p = subparser("status", "show quota, queue and window history")
    p.add_argument("--json", action="store_true")
    p.add_argument("--state-db", default=None)
    p.set_defaults(func=cmd_status)

    p = subparser("assets", "summarize the accepted asset candidate pool")
    p.add_argument("--out", default=None)
    p.set_defaults(func=cmd_assets)

    p = subparser("report", "write the per-model comparison report")
    p.add_argument("--out", default=None)
    p.add_argument("--state-db", default=None)
    p.set_defaults(func=cmd_report)

    p = subparser("reset-stale", "recover jobs left running by a crash")
    p.add_argument("--max-age", type=float, default=1800)
    p.add_argument("--state-db", default=None)
    p.set_defaults(func=cmd_reset_stale)
    return ap


def main(argv=None) -> int:
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
                        datefmt="%H:%M:%S")
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except ConfigError as exc:
        print(f"config error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
