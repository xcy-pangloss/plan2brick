# Raw native AI output-format comparison (R2-B1)

| format | model | converted | valid | parts | overlaps | status | latency s |
|---|---|---|---|---:|---:|---|---:|
| ldr | deepseek | True | False | 81 | 10 | validate_failed | 8.297 |
| json | deepseek | True | False | 79 | 36 | validate_failed | 6.964 |
| csv | deepseek | True | True | 153 | 0 | ok | 6.787 |
| csv | claude | False | False | None | None | call_error | None |
| csv | gpt | False | False | None | None | call_error | None |

Reference: Plan2Brick P on R2-B1: build true, coverage 1.0, 0 overlaps, 0 model calls, 826 parts. B (AI IR + builder): build true, coverage ~0.88-1.0 depending on model.

Notes: Claude/GPT CSV calls hit upstream HTTP 500 after ~8 min; DeepSeek CSV produced a valid 153-part model and was rendered to PNG. LDR/JSON outputs were converted but failed validation (syntax/overlap).
