# Tool vs native AI — controlled subset

Cases: R2-B1, R4-B1, R6-B1, R6-B4. Arms: A = raw LDraw, B = LLM scene IR + deterministic builder, P = Plan2Brick deterministic (no model).

| case | model | arm | status | build/valid | parts | coverage | overlaps | brief | latency s |
|---|---|---|---|---|---:|---:|---:|---|---:|
| R2_B1 | plan2brick | P | ok | True | - | 1.000 | 0 | True | 0.000 |
| R2_B1 | deepseek | A | no_ldraw_lines | False | 0 | - | - | - | 44.449 |
| R2_B1 | deepseek | B | ok | True | - | 1.000 | 0 | True | 39.305 |
| R4_B1 | plan2brick | P | ok | True | - | 0.958 | 0 | True | 0.000 |
| R4_B1 | deepseek | A | no_ldraw_lines | False | 0 | - | - | - | 43.605 |
| R4_B1 | deepseek | B | ok | True | - | 0.962 | 0 | True | 26.274 |
| R6_B1 | plan2brick | P | ok | True | - | 0.972 | 0 | True | 0.000 |
| R6_B1 | deepseek | A | no_ldraw_lines | False | 0 | - | - | - | 46.277 |
| R6_B1 | deepseek | B | ok | True | - | 0.950 | 0 | True | 33.435 |
| R6_B4 | plan2brick | P | ok | True | - | 0.970 | 0 | True | 0.000 |
| R6_B4 | deepseek | A | no_ldraw_lines | False | 0 | - | - | - | 39.297 |
| R6_B4 | deepseek | B | ok | True | - | 0.957 | 0 | False | 29.904 |

## Summary

- **A**: 0/4 valid/buildable
- **B**: 4/4 valid/buildable; mean coverage 0.967
- **P**: 4/4 valid/buildable; mean coverage 0.975
