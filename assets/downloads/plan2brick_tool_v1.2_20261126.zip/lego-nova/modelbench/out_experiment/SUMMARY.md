# Tool vs native AI — pilot summary

Controlled subset: R2-B1, R4-B1, R6-B1, R6-B4. Arm A = raw LDraw; B = LLM scene IR + deterministic builder; P = Plan2Brick deterministic (no model).

## Plan2Brick (P, deterministic)

| case | build | coverage | overlaps | brief |
|---|---|---:|---:|---|
| R2_B1 | True | 1.0 | 0 | True |
| R4_B1 | True | 0.9583 | 0 | True |
| R6_B1 | True | 0.9722 | 0 | True |
| R6_B4 | True | 0.9697 | 0 | True |

- build: **4/4**; mean coverage **0.975**; brief **4/4**; 0 model calls, 0 tokens.

## Arm B — AI scene IR + deterministic builder

| model | reps | build | mean coverage | brief effect | mean overlaps |
|---|---:|---:|---:|---:|---:|
| deepseek | 4 | 4/4 | 0.967 | 3/4 | 0 |
| claude | 32 | 32/32 | 0.897 | 24/32 | 0 |
| gpt | 32 | 32/32 | 0.918 | 24/32 | 0 |

B4 (`Use the dining room as a study`) is the failure mode: all three model families fail the room-type assertion, while P passes it deterministically. B1 (`Add a desk to the living room`) passes in all arms.

## Arm A — raw LDraw generation

| model | attempts | valid LDraw | status |
|---|---:|---:|---|
| deepseek | 4 | 0/4 | no_ldraw_lines |
| claude | 1 | 0/1 | call_error |

DeepSeek raw attempts returned empty content after consuming the full 8192-token output budget; Claude R2 returned upstream HTTP 500 after ~8 minutes. GPT raw was not completed because the shared quota window was exhausted; B/P GPT results are complete.

## Reading

- Raw LDraw (A) is not usable in one shot: empty/truncated output or provider failure; no model produced a valid model.
- AI planning + our builder (B) is buildable, but model planning loses coverage and fails room-programme replacement (B4) in every family.
- The deterministic tool (P) is buildable, has the best coverage, passes all briefs, 0 overlaps, and uses 0 model calls/tokens.
- Caveat: B already uses the deterministic builder; it is the *best case* for AI + furniture parts, not a fully free-form placement baseline. A is the fully raw baseline. The subset is a 4-cell pilot, not the final 18-plan benchmark.
