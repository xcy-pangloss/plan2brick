# Plan2Brick deterministic arm — full matrix

- cells: 72; ran: 65; not applicable: 7; exceptions: 0
- build success: **65/65**
- brief effect: **65/65**
- mean coverage: **0.97**
- total overlap errors: **0**

| provenance | cells | build | brief | mean coverage |
|---|---:|---:|---:|---:|
| real | 33 | 33/33 | 33/33 | 0.9484 |
| synthetic-preset | 13 | 13/13 | 13/13 | 1.0 |
| synthetic-topology | 8 | 8/8 | 8/8 | 1.0 |
| synthetic-traced | 11 | 11/11 | 11/11 | 0.9778 |

| case | build | coverage | overlaps | brief |
|---|---|---:|---:|---|
| R1_B1 | True | 0.9487 | 0 | True |
| R1_B2 | True | 0.9459 | 0 | True |
| R1_B3 | True | 0.9474 | 0 | True |
| R1_B4 | True | 0.9444 | 0 | True |
| R2_B1 | True | 1.0 | 0 | True |
| R2_B2 | True | 1.0 | 0 | True |
| R2_B3 | True | 1.0 | 0 | True |
| R3_B1 | True | 0.931 | 0 | True |
| R3_B2 | True | 0.9259 | 0 | True |
| R3_B3 | True | 0.9286 | 0 | True |
| R3_B4 | True | 0.9615 | 0 | True |
| R4_B1 | True | 1.0 | 0 | True |
| R4_B2 | True | 0.9545 | 0 | True |
| R4_B3 | True | 1.0 | 0 | True |
| R5_B1 | True | 1.0 | 0 | True |
| R5_B2 | True | 1.0 | 0 | True |
| R5_B3 | True | 1.0 | 0 | True |
| R5_B4 | True | 1.0 | 0 | True |
| R6_B1 | True | 0.9722 | 0 | True |
| R6_B2 | True | 0.9706 | 0 | True |
| R6_B3 | True | 0.9714 | 0 | True |
| R6_B4 | True | 0.9697 | 0 | True |
| R7_B1 | True | 0.871 | 0 | True |
| R7_B2 | True | 0.8621 | 0 | True |
| R7_B3 | True | 0.8667 | 0 | True |
| R7_B4 | True | 0.8571 | 0 | True |
| R8_B1 | True | 0.9697 | 0 | True |
| R8_B2 | True | 0.9677 | 0 | True |
| R8_B3 | True | 0.9688 | 0 | True |
| R8_B4 | True | 0.9667 | 0 | True |
| R9_B1 | True | 0.8684 | 0 | True |
| R9_B2 | True | 0.8611 | 0 | True |
| R9_B3 | True | 0.8649 | 0 | True |
| A_B1 | True | 0.9333 | 0 | True |
| A_B2 | True | 0.9286 | 0 | True |
| A_B3 | True | 0.931 | 0 | True |
| A_B4 | True | 0.963 | 0 | True |
| B_B1 | True | 1.0 | 0 | True |
| B_B2 | True | 1.0 | 0 | True |
| B_B3 | True | 1.0 | 0 | True |
| C_B1 | True | 1.0 | 0 | True |
| C_B2 | True | 1.0 | 0 | True |
| C_B3 | True | 1.0 | 0 | True |
| C_B4 | True | 1.0 | 0 | True |
| studio_B1 | True | 1.0 | 0 | True |
| studio_B2 | True | 1.0 | 0 | True |
| studio_B3 | True | 1.0 | 0 | True |
| 1br_B1 | True | 1.0 | 0 | True |
| 1br_B2 | True | 1.0 | 0 | True |
| 1br_B3 | True | 1.0 | 0 | True |
| 2br_B1 | True | 1.0 | 0 | True |
| 2br_B2 | True | 1.0 | 0 | True |
| 2br_B3 | True | 1.0 | 0 | True |
| 3br_B1 | True | 1.0 | 0 | True |
| 3br_B2 | True | 1.0 | 0 | True |
| 3br_B3 | True | 1.0 | 0 | True |
| 3br_B4 | True | 1.0 | 0 | True |
| openplan_B1 | True | 1.0 | 0 | True |
| openplan_B2 | True | 1.0 | 0 | True |
| openplan_B3 | True | 1.0 | 0 | True |
| openplan_B4 | True | 1.0 | 0 | True |
| lshape_B1 | True | 1.0 | 0 | True |
| lshape_B2 | True | 1.0 | 0 | True |
| lshape_B3 | True | 1.0 | 0 | True |
| lshape_B4 | True | 1.0 | 0 | True |
