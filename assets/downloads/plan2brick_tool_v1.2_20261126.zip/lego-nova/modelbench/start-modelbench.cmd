@echo off
REM Start the Plan2Brick multi-model scheduler.
REM Fill modelbench\config.local.json and set MODELBENCH_API_KEY first.
cd /d "%~dp0.."
if "%MODELBENCH_CONFIG%"=="" set MODELBENCH_CONFIG=%~dp0config.local.json
C:\Python314\python.exe -m modelbench run --config "%MODELBENCH_CONFIG%" --concurrency 2 --max-reps 8 --status-every 600
pause
