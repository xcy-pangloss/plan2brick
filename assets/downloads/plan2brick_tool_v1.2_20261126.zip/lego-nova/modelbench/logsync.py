"""Append completed SQLite call-ledger rows to a human-readable ``calls.log``.

Run in a terminal (or background) to watch live model calls without attaching
to a worker's console:

    C:\\Python314\\python.exe modelbench\\logsync.py

Then in another terminal:

    Get-Content modelbench\\state\\calls.log -Tail 40 -Wait
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

NOVA = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NOVA))

from modelbench.config import load_config  # noqa: E402
from modelbench.quota import QuotaPolicy, parse_anchor  # noqa: E402
from modelbench.store import Store  # noqa: E402


def format_call(store: Store, r: dict) -> str:
    job = store.job(r["job_id"])
    if job:
        payload = json.loads(job.get("payload") or "{}")
        kind = job["kind"]
        plan = payload.get("plan_id") or "-"
        brief = payload.get("brief_id") or "-"
        rep = job.get("rep", 0)
    else:
        kind, plan, brief, rep = "probe", "-", "-", 0
    parts = [
        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(r["at"])),
        f'{r["model"]:8s}', f"{kind:18s}",
        f"plan={plan:8s}", f"brief={brief:4s}", f"rep={rep}",
        f'status={r["outcome"]}',
    ]
    if r["http_status"] is not None:
        parts.append(f'http={r["http_status"]}')
    if r["latency_s"] is not None:
        parts.append(f'latency={float(r["latency_s"]):.1f}s')
    if r["in_tokens"] is not None or r["out_tokens"] is not None:
        parts.append(f'tok={r["in_tokens"]}/{r["out_tokens"]}')
    if r["released"]:
        parts.append("released=1")
    return " ".join(parts)


def main() -> int:
    cfg = load_config()
    store = Store(cfg.state_dir / "queue.sqlite3",
                  QuotaPolicy(cfg.quota.limit, cfg.quota.window_s, cfg.quota.mode,
                              parse_anchor(cfg.quota.anchor)))
    log = cfg.state_dir / "calls.log"
    # Rebuild the human-readable log from completed rows, then follow new ones.
    rows = [r for r in store.usage_rows() if r["outcome"] != "reserved"]
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("w", encoding="utf-8") as fh:
        for r in rows:
            fh.write(format_call(store, r) + "\n")
    seen = {int(r["id"]) for r in rows}
    print(f"following completed calls in {log} ({len(seen)} already seen)", flush=True)
    while True:
        rows = [r for r in store.usage_rows()
                if r["outcome"] != "reserved" and int(r["id"]) not in seen]
        if rows:
            log.parent.mkdir(parents=True, exist_ok=True)
            with log.open("a", encoding="utf-8") as fh:
                for r in rows:
                    line = format_call(store, r)
                    fh.write(line + "\n")
                    print(line, flush=True)
                    seen.add(int(r["id"]))
                fh.flush()
        time.sleep(3)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(0)
