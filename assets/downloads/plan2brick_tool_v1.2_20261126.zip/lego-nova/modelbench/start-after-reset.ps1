# Wait for the provider's rolling 3 h window to recover, probe vision on all
# three models, then start the quota-aware scheduler.  Every probe and every
# job is recorded in modelbench/state/queue.sqlite3.
$ErrorActionPreference = "Continue"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$log = Join-Path $PSScriptRoot "state\launch.log"
New-Item -ItemType Directory -Force (Split-Path $log) | Out-Null
function Log($m) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $m"
    Write-Output $line
    Add-Content -Path $log -Value $line -Encoding utf8
}

$py = "C:\Python314\python.exe"
$cfg = Join-Path $PSScriptRoot "config.local.json"

$untilText = & $py -c "from modelbench.store import Store; from modelbench.quota import QuotaPolicy; s=Store('modelbench/state/queue.sqlite3', QuotaPolicy(150,10800,'sliding')); print(int(s.blocked_until())); s.close()"
$until = 0.0
[double]::TryParse(($untilText | Select-Object -Last 1), [ref]$until) | Out-Null
Log "ledger blocked_until=$until"

while ($true) {
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    if ($now -ge $until) { break }
    $left = [int]($until - $now)
    Log "quota blocked; waiting ${left}s"
    Start-Sleep -Seconds ([Math]::Min(60, [Math]::Max(5, $left)))
}

Log "quota window open; running vision probe"
& $py -m modelbench probe --config $cfg --image "fyp-pipeline\inputs\floorplan_B.png" 2>&1 |
    ForEach-Object { Log $_ }
if ($LASTEXITCODE -ne 0) {
    Log "probe failed (exit $LASTEXITCODE); worker not started. Fix the config/model and rerun."
    exit 1
}

Log "probe ok; starting worker (concurrency 3, max reps 8)"
& $py -m modelbench run --config $cfg --concurrency 3 --max-reps 8 --status-every 600 2>&1 |
    ForEach-Object { Log $_ }
$code = $LASTEXITCODE
Log "worker exited with $code"
exit $code
