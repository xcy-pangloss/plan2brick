"""Controlled tool-vs-native-AI experiment on a small fixed subset.

Three arms, same room list + brief:

  raw_ldraw   model writes a complete LDraw model directly (no library/solver)
  llm_ir      model writes a scene IR (furniture categories/counts);
              the deterministic Plan2Brick builder assembles it
  plan2brick  no model: deterministic standard programme + brief patch +
              deterministic fit-aware solver / assembly

Models: DeepSeek, Claude, GPT.  Calls are recorded in the same SQLite quota
ledger and obey the 150/3 h sliding window.

Run from ``lego-nova``:

    C:\\Python314\\python.exe modelbench\\tool_vs_ai.py
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import traceback
from pathlib import Path

NOVA = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NOVA))

from modelbench import catalogue, scoring, tasks, transport  # noqa: E402
from modelbench.config import load_config  # noqa: E402
from modelbench.quota import QuotaPolicy, parse_anchor  # noqa: E402
from modelbench.store import Store  # noqa: E402
from novalib import brief as brief_lib, floorplan  # noqa: E402

OUT = NOVA / "modelbench" / "out_experiment"
RESULT_FILE = OUT / "results.jsonl"
RUN_LOG = OUT / "run.log"
VENV_PY = NOVA / ".venv" / "Scripts" / "python.exe"
PROMPTS = NOVA / "modelbench" / "prompts"

CASES = [("R2", "B1"), ("R4", "B1"), ("R6", "B1"), ("R6", "B4")]
MODELS = ["deepseek", "claude", "gpt"]


def log(msg: str) -> None:
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}"
    print(line, flush=True)
    try:
        RUN_LOG.parent.mkdir(parents=True, exist_ok=True)
        with RUN_LOG.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def load_existing() -> set[tuple[str, str, str]]:
    if not RESULT_FILE.exists():
        return set()
    out = set()
    for line in RESULT_FILE.read_text(encoding="utf-8").splitlines():
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            continue
        out.add((r.get("case"), r.get("model"), r.get("arm")))
    return out


def append_result(r: dict) -> None:
    RESULT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with RESULT_FILE.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(r, ensure_ascii=False) + "\n")
        fh.flush()


def load_case(plan_id: str, brief_id: str):
    plans = {p["id"]: p for p in catalogue.load_all_plans()}
    briefs = {b["id"]: b for b in catalogue.load_briefs()}
    return plans[plan_id], briefs[brief_id]


def rooms_only(plan: dict) -> list[dict]:
    ir = catalogue.load_plan_ir(plan)
    rooms = []
    for r in ir.get("rooms") or []:
        rooms.append({
            "name_cn": r.get("name_cn") or r.get("name_en"),
            "name_en": r.get("name_en") or r.get("name_cn"),
            "room_type": r.get("room_type"),
            "dims_m": r.get("dims_m"),
        })
    return rooms


def plan_payload(plan: dict, brf: dict) -> dict:
    return {
        "plan_id": plan["id"], "split": plan.get("split"),
        "provenance": plan.get("provenance"), "topology": plan.get("topology"),
        "area_m2": plan.get("area_m2"), "base_ir": plan["path"],
        "rooms": rooms_only(plan), "brief_id": brf["id"],
        "brief_type": brf["type"], "brief_text": brf["text"],
        "prompt_id": "llm_direct_v1",
    }


def call_quota(cfg, store: Store, model: str, prompt: str,
               images: list[str] | None = None,
               max_tokens: int | None = None) -> transport.CallResult | None:
    """Reserve a slot, call, and return None on non-429 errors."""
    while True:
        cid, nxt, used = store.reserve_call_raw(model)
        if cid is None:
            wait = max(0.0, float(nxt) - time.time())
            log(f"quota full (used {used}); waiting {min(wait, 60):.0f}s")
            time.sleep(min(wait, 60) if wait > 0 else 5)
            continue
        try:
            res = transport.call_model(cfg, model, prompt, images,
                                       max_output_tokens=max_tokens)
            store.finish_call(cid, "ok", http_status=res.http_status,
                              latency_s=res.latency_s,
                              in_tokens=(res.usage or {}).get("in"),
                              out_tokens=(res.usage or {}).get("out"))
            return res
        except transport.TransportError as exc:
            released = bool(exc.release_slot)
            store.finish_call(cid, "error", http_status=exc.status,
                              released=released)
            if released:
                store.release_call(cid, "experiment")
            if exc.status == 429:
                until = time.time() + max(5.0, float(exc.retry_after or 60.0))
                store.set_quota_block(until, exc.reported_used)
                log(f"429; provider used={exc.reported_used}; wait until "
                    f"{time.strftime('%H:%M:%S', time.localtime(until))}")
                continue
            log(f"call error {model}: {exc.status} {str(exc)[:200]}")
            return None


# --------------------------------------------------------------------- arm A
def raw_prompt(plan: dict, brf: dict) -> str:
    base = (PROMPTS / "raw_ldraw_v1.md").read_text(encoding="utf-8")
    data = {"plan": {"id": plan["id"], "rooms": rooms_only(plan)},
            "brief": {"id": brf["id"], "type": brf["type"], "text": brf["text"]}}
    return (base + "\n\nInput:\n```json\n"
            + json.dumps(data, ensure_ascii=False, indent=2)
            + "\n```\n")


def extract_ldraw(text: str) -> str:
    text = (text or "").strip()
    if "```" in text:
        import re
        blocks = re.findall(r"```(?:ldraw|ldr|mpd)?\s*(.*?)```", text, re.S | re.I)
        if blocks:
            text = max(blocks, key=len)
    lines = [ln.rstrip() for ln in text.splitlines()
             if ln.strip() and (ln.startswith("0 ") or ln.startswith("1 "))]
    if not lines:
        return ""
    if not lines[0].startswith("0 FILE"):
        lines = ["0 FILE model.ldr", "0 Name: model.ldr", *lines]
    return "\n".join(lines) + "\n"


def score_raw(text: str, case_dir: Path) -> dict:
    ldr = extract_ldraw(text)
    out = {"json_ok": bool(ldr), "valid": False, "build_ok": False,
           "parts": 0, "coverage": None, "overlaps": None,
           "brief_ok": None, "status": "no_ldraw_lines",
           "response_chars": len(text or "")}
    if not ldr:
        return out
    case_dir.mkdir(parents=True, exist_ok=True)
    ldr_path = case_dir / "raw.ldr"
    ldr_path.write_text(ldr, encoding="utf-8")
    report = case_dir / "validate.json"
    out["ldr_path"] = str(ldr_path)
    try:
        subprocess.run(
            [str(VENV_PY), "-m", "lego_nova.cli", "validate", str(ldr_path),
             "--geometry", "--report", str(report)],
            cwd=str(NOVA), capture_output=True, text=True, timeout=180)
    except Exception as exc:
        out["status"] = f"validate_exception: {type(exc).__name__}: {exc}"[:300]
        return out
    if not report.exists():
        out["status"] = "validate_no_report"
        return out
    try:
        rep = json.loads(report.read_text(encoding="utf-8"))
    except Exception as exc:
        out["status"] = f"report_parse_error: {exc}"[:300]
        return out
    diag = rep.get("diagnostics") or []
    errors = [d for d in diag if str(d.get("severity")).lower() == "error"]
    geom = rep.get("geometry") or {}
    out.update({
        "valid": bool(rep.get("checks_passed")) and not errors,
        "build_ok": bool(rep.get("checks_passed")) and not errors,
        "parts": int(geom.get("occurrence_count") or 0),
        # `geometry.overlaps` includes stud-zone review candidates for a valid
        # single model, so report real error diagnostics, not candidate pairs.
        "overlaps": len(errors),
        "overlap_candidates": int(geom.get("overlap_candidate_count") or 0),
        "diagnostics": [f"{d.get('severity')}:{d.get('code')}" for d in diag][:20],
        "status": "ok" if rep.get("checks_passed") else "validate_failed",
        "bbox": geom.get("bounds"),
    })
    return out


# --------------------------------------------------------------------- arm B
def run_arm_b(cfg, store: Store, model: str, plan: dict, brf: dict,
              case_dir: Path) -> dict:
    payload = plan_payload(plan, brf)
    prompt = tasks.render_prompt("llm_direct", payload)
    log(f"B {model} {plan['id']}-{brf['id']}")
    res = call_quota(cfg, store, model, prompt, max_tokens=8192)
    if res is None:
        return {"json_ok": False, "build_ok": False, "status": "call_error"}
    ir = scoring.extract_json(res.text)
    if not isinstance(ir, dict):
        return {"json_ok": False, "build_ok": False, "status": "json_parse_error",
                "response": (res.text or "")[:1000]}
    errs, warns = scoring.check_ir_obj(ir)
    metrics = scoring.score_llm_direct(ir, payload, errs, warns,
                                       f"B_{model}_{plan['id']}_{brf['id']}",
                                       case_dir / "build")
    build = metrics.get("build") or {}
    metrics.update({"build_ok": build.get("build_ok"),
                    "coverage": build.get("coverage_ratio"),
                    "overlaps": build.get("overlaps"),
                    "status": "ok", "latency_s": res.latency_s,
                    "usage": res.usage})
    (case_dir / "ir.json").write_text(json.dumps(ir, ensure_ascii=False, indent=2),
                                      encoding="utf-8")
    return metrics


# --------------------------------------------------------------------- arm P
def run_arm_p(plan: dict, brf: dict, case_dir: Path) -> dict:
    ir = catalogue.load_plan_ir(plan)
    rooms = []
    for r in ir.get("rooms") or []:
        rooms.append({
            "name_cn": r.get("name_cn") or r.get("name_en"),
            "name_en": r.get("name_en") or r.get("name_cn"),
            "room_type": r.get("room_type") or floorplan.infer_room_type(
                r.get("name_en"), r.get("name_cn")),
            "dims_m": r.get("dims_m"),
        })
    base = floorplan.make_ir(rooms, {}, source="tool-vs-ai")
    base.pop("layout_m", None)              # same row-major information as arm B
    patched = brief_lib.apply_brief(base, brf["text"])
    if not tasks._applicable(brf["id"], patched):
        return {"json_ok": True, "build_ok": False, "status": "not_applicable",
                "unmatched": patched.get("unmatched")}
    after = patched["ir"]
    case_dir.mkdir(parents=True, exist_ok=True)
    base_path = case_dir / "base_ir.json"
    base_path.write_text(json.dumps(base, ensure_ascii=False, indent=2),
                         encoding="utf-8")
    payload = {
        "plan_id": plan["id"], "base_ir": str(base_path), "rooms": rooms,
        "brief_id": brf["id"], "brief_type": brf["type"],
        "brief_text": brf["text"],
    }
    errs, warns = scoring.check_ir_obj(after)
    metrics = scoring.score_llm_direct(
        after, payload, errs, warns,
        f"P_{plan['id']}_{brf['id']}", case_dir / "build")
    build = metrics.get("build") or {}
    metrics.update({"build_ok": build.get("build_ok"),
                    "coverage": build.get("coverage_ratio"),
                    "overlaps": build.get("overlaps"),
                    "status": "ok", "latency_s": 0.0,
                    "usage": {"in": 0, "out": 0},
                    "actions": patched.get("actions")})
    (case_dir / "ir.json").write_text(json.dumps(after, ensure_ascii=False, indent=2),
                                      encoding="utf-8")
    return metrics


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--models", default=",".join(MODELS))
    ap.add_argument("--cases", default="")
    ap.add_argument("--arms", default="P,A,B")
    ap.add_argument("--force", action="store_true",
                    help="ignore existing results.jsonl entries")
    a = ap.parse_args()
    cfg = load_config()
    store = Store(cfg.state_dir / "queue.sqlite3",
                  QuotaPolicy(cfg.quota.limit, cfg.quota.window_s, cfg.quota.mode,
                              parse_anchor(cfg.quota.anchor)))
    OUT.mkdir(parents=True, exist_ok=True)
    models = [m.strip() for m in a.models.split(",") if m.strip()]
    arms = [x.strip().upper() for x in a.arms.split(",") if x.strip()]
    wanted_cases = {x.strip() for x in a.cases.split(",") if x.strip()}
    cases = [(p, b) for p, b in CASES if not wanted_cases or f"{p}_{b}" in wanted_cases]
    existing = set() if a.force else load_existing()
    log(f"start models={models} cases={[f'{p}_{b}' for p, b in cases]} "
        f"arms={arms} existing={len(existing)}")
    for plan_id, brief_id in cases:
        plan, brf = load_case(plan_id, brief_id)
        cid = f"{plan_id}_{brief_id}"
        if "P" in arms and (cid, "plan2brick", "P") not in existing:
            try:
                p = run_arm_p(plan, brf, OUT / cid / "P")
                rec = {"case": cid, "model": "plan2brick", "arm": "P", **p}
                append_result(rec)
                existing.add((cid, "plan2brick", "P"))
                log(f"P {cid}: build={p.get('build_ok')} coverage={p.get('coverage')}")
            except Exception:
                log("P failed:\n" + traceback.format_exc())
                rec = {"case": cid, "model": "plan2brick", "arm": "P",
                       "build_ok": False, "status": "exception"}
                append_result(rec)
                existing.add((cid, "plan2brick", "P"))
        for model in models:
            for arm in arms:
                if arm not in ("A", "B"):
                    continue
                if (cid, model, arm) in existing:
                    log(f"skip existing {arm} {model} {cid}")
                    continue
                try:
                    if arm == "A":
                        prompt = raw_prompt(plan, brf)
                        log(f"A {model} {cid}: calling")
                        res = call_quota(cfg, store, model, prompt,
                                         max_tokens=8192)
                        if res is None:
                            metrics = {"status": "call_error", "valid": False,
                                       "build_ok": False}
                        else:
                            adir = OUT / cid / f"A_{model}"
                            adir.mkdir(parents=True, exist_ok=True)
                            (adir / "response.txt").write_text(res.text or "",
                                                              encoding="utf-8")
                            metrics = score_raw(res.text, adir)
                            metrics.update({"latency_s": res.latency_s,
                                            "usage": res.usage})
                    else:
                        metrics = run_arm_b(cfg, store, model, plan, brf,
                                            OUT / cid / f"B_{model}")
                    rec = {"case": cid, "model": model, "arm": arm, **metrics}
                    append_result(rec)
                    existing.add((cid, model, arm))
                    log(f"{arm} {model} {cid}: status={metrics.get('status')} "
                        f"build={metrics.get('build_ok')} "
                        f"coverage={metrics.get('coverage')}")
                except Exception:
                    log(f"{arm} {model} {cid} failed:\n{traceback.format_exc()}")
                    rec = {"case": cid, "model": model, "arm": arm,
                           "status": "exception", "build_ok": False}
                    append_result(rec)
                    existing.add((cid, model, arm))
    all_results = []
    if RESULT_FILE.exists():
        for line in RESULT_FILE.read_text(encoding="utf-8").splitlines():
            try:
                all_results.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    (OUT / "results.json").write_text(
        json.dumps(all_results, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "results.md").write_text(report_md(all_results), encoding="utf-8")
    log(f"wrote {OUT / 'results.md'}")
    store.close()
    return 0


def report_md(results: list[dict]) -> str:
    lines = ["# Tool vs native AI — controlled subset", "",
             "Cases: R2-B1, R4-B1, R6-B1, R6-B4. Arms: A = raw LDraw, "
             "B = LLM scene IR + deterministic builder, P = Plan2Brick "
             "deterministic (no model).", "",
             "| case | model | arm | status | build/valid | parts | coverage | overlaps | brief | latency s |",
             "|---|---|---|---|---|---:|---:|---:|---|---:|"]
    for r in results:
        def fmt(v):
            if v is None:
                return "-"
            if isinstance(v, float):
                return f"{v:.3f}"
            return str(v)
        brief = r.get("brief_effect")
        brief_ok = brief.get("ok") if isinstance(brief, dict) else r.get("brief_ok")
        lines.append(
            f"| {r.get('case')} | {r.get('model')} | {r.get('arm')} "
            f"| {fmt(r.get('status'))} | {fmt(r.get('build_ok') if r.get('arm') != 'A' else r.get('valid'))} "
            f"| {fmt(r.get('parts'))} | {fmt(r.get('coverage'))} "
            f"| {fmt(r.get('overlaps'))} | {fmt(brief_ok)} "
            f"| {fmt(r.get('latency_s'))} |")
    lines += ["", "## Summary", ""]
    for arm in ("A", "B", "P"):
        rows = [r for r in results if r.get("arm") == arm]
        if not rows:
            continue
        ok = sum(1 for r in rows if (r.get("build_ok") if arm != "A" else r.get("valid")))
        cov = [r.get("coverage") for r in rows if isinstance(r.get("coverage"), (int, float))]
        lines.append(f"- **{arm}**: {ok}/{len(rows)} valid/buildable; "
                     f"mean coverage {sum(cov)/len(cov):.3f}" if cov
                     else f"- **{arm}**: {ok}/{len(rows)} valid/buildable")
    lines.append("")
    return "\n".join(lines)


if __name__ == "__main__":
    sys.exit(main())
