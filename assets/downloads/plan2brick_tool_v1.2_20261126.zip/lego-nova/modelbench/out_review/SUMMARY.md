# Claude / GPT review of Plan2Brick — findings and applied fixes

**Review inputs:** `micro_*_claude.md` / `micro_*_gpt.md` in this directory.
Whole-file bundles hit provider upstream HTTP 500 after ~8 min; per-function
micro-reviews (1–9 KB prompts, 1,024 output tokens) completed for:

- `novalib/assembly.py` — `try_place`, `global_overlaps`
- `novalib/diversity.py` — `qd_select`, `_filter_dedup`
- `novalib/brief.py` — `apply_brief`
- `modelbench/worker.py` — `_handle_future`, `_ensure_filler`
- `modelbench/scoring.py` — `score_llm_direct`, `build_prediction`
- `bench/run.py` — `run_cell`

## High-impact fixes applied

1. **Band search in `try_place`**
   - Before: first collision abandoned the whole wall band; useful space later
     in the band was lost and selection was order-dependent.
   - After: deterministic one-stud scan past blocked positions + explicit
     room-interior containment check before accepting a footprint.
   - Effect: Plan2Brick full 18×4 deterministic matrix mean coverage
     **0.9444 → 0.9700**, while keeping **65/65 build, 65/65 brief, 0 overlaps**.

2. **Part-level edit source selection (`novalib/edit.py`)**
   - `patch()` used `next(glob("*.placements.json"))`; after one edit it could
     pick `*.edited.placements.json` as the next source, corrupting the
     "unchanged objects" count.
   - Now prefers the base placements file and rejects ambiguous directories.
   - `nova.py selftest` part-level edit passes (`others 15`, `lines 193/193`).

3. **Transactional brief clauses (`novalib/brief.py`)**
   - Each clause is applied to a trial deep copy; committed only on success.
   - Prevents a failed helper from leaving partial mutations in the returned IR.

4. **QD selection robustness (`novalib/diversity.py`)**
   - `k == 0` now returns an empty archive and records all candidates as
     dropped; negative/non-int `k` raises.
   - Tie-break no longer requires numeric candidate IDs (string/UUID safe).

5. **Scoring reliability (`modelbench/scoring.py`)**
   - Missing/unreadable base IR returns a structured `score_error`, not an
     exception.
   - Schema-invalid predictions no longer run the builder; build is marked
     skipped.
   - `build_prediction` validates counts (`0 <= placed <= requested`) and
     artifact existence; invalid counts no longer yield a perfect 1.0 coverage.

6. **Worker network/filler reliability (`modelbench/worker.py`)**
   - DNS/connection/timeout/TLS/proxy failures now trigger a 30 s global
     network cooldown and requeue without consuming an attempt. This directly
     addresses the earlier 1,000+ `getaddrinfo failed` dead jobs.
   - Filler top-ups are capped to the low-watermark deficit instead of
     enqueuing the full corpus when only a few jobs are missing.

7. **Immutable benchmark baseline (`bench/run.py`)**
   - The pre-brief IR is deep-copied and passed to `verify_effect`, so semantic
     verification cannot compare a mutated object with itself.

## Verification after fixes

- `python nova.py selftest`: **10/10 PASS**.
- `python tests/test_modelbench.py`: **20/20 PASS**.
- `bench/run.py` R2×B1 smoke: ran, 0 errors.
- `modelbench/p_full_matrix.py`: 72 cells, 65 ran, **65/65 build**,
  **65/65 brief**, **0 overlap errors**, mean coverage **0.9700**.

## Review notes not applied

- `bench/run.py` could use a broader outer exception boundary for setup and
  artifact persistence; current per-cell try covers execution but not all
  initialization/persistence.
- `qd_select` still recomputes pairwise distances each iteration
  (O(n·k²)); pools are currently 24, so this is not hot.
- `global_overlaps` remains O(n²); it is fine at current scene sizes but a
  spatial broad phase is the next scaling step.
- `random_select`/`_filter_dedup` audit provenance could be tightened.
