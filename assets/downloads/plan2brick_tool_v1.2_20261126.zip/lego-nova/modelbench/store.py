"""SQLite-backed job queue and call ledger.

The database is the single source of truth for both work and quota.  A call
is reserved *before* the HTTP request and is counted in the quota window even
while it is in flight.  Reservations are atomic (``BEGIN IMMEDIATE``), so two
workers cannot exceed the limit between a count and an insert.

Only the main scheduler thread touches the connection; HTTP work happens in
worker threads and returns results to the main thread.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from dataclasses import replace
from pathlib import Path

from .quota import QuotaPolicy

SCHEMA_VERSION = 1

SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    model TEXT NOT NULL,
    priority INTEGER NOT NULL DEFAULT 100,
    payload TEXT NOT NULL,
    prompt_hash TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    attempts INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 3,
    rep INTEGER NOT NULL DEFAULT 0,
    created_at REAL NOT NULL,
    started_at REAL,
    finished_at REAL,
    result_path TEXT,
    metrics TEXT,
    error TEXT
);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status, priority, created_at);
CREATE INDEX IF NOT EXISTS idx_jobs_model ON jobs(model, status);

CREATE TABLE IF NOT EXISTS calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    at REAL NOT NULL,
    model TEXT NOT NULL,
    job_id TEXT NOT NULL,
    outcome TEXT NOT NULL DEFAULT 'reserved',
    http_status INTEGER,
    latency_s REAL,
    in_tokens INTEGER,
    out_tokens INTEGER,
    released INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_calls_at ON calls(at);
CREATE INDEX IF NOT EXISTS idx_calls_model_at ON calls(model, at);

CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


class Store:
    def __init__(self, path: str | Path, policy: QuotaPolicy):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.policy = policy
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(str(self.path), timeout=60, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self.conn.execute("PRAGMA busy_timeout=60000")
        self.conn.executescript(SCHEMA)
        self.conn.execute(
            "INSERT OR IGNORE INTO meta(key, value) VALUES('schema_version', ?)",
            (str(SCHEMA_VERSION),))
        self.conn.commit()
        # Fixed mode without an explicit anchor: the provider's window starts
        # at the first use of this ledger (the common "3 h from first call"
        # semantics).  Persist it so restarts keep the same boundary.
        if self.policy.mode == "fixed" and self.policy.anchor is None:
            row = self.conn.execute(
                "SELECT value FROM meta WHERE key='fixed_anchor'").fetchone()
            if row is None:
                anchor = time.time()
                self.conn.execute(
                    "INSERT INTO meta(key, value) VALUES('fixed_anchor', ?)",
                    (str(anchor),))
                self.conn.commit()
            else:
                anchor = float(row["value"])
            self.policy = replace(self.policy, anchor=anchor)

    # ------------------------------------------------------------------ meta
    def get_meta(self, key: str, default: str | None = None) -> str | None:
        with self._lock:
            row = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set_meta(self, key: str, value: str) -> None:
        with self._lock:
            self.conn.execute(
                "INSERT INTO meta(key, value) VALUES(?, ?)"
                " ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
            self.conn.commit()

    def set_quota_block(self, until: float, reported_used: int | None = None) -> None:
        self.set_meta("blocked_until", str(float(until)))
        self.set_meta("blocked_at", str(time.time()))
        if reported_used is not None:
            self.set_meta("reported_used", str(int(reported_used)))

    def blocked_until(self) -> float:
        try:
            return float(self.get_meta("blocked_until", "0") or 0)
        except ValueError:
            return 0.0

    def set_network_block(self, until: float) -> None:
        self.set_meta("network_block_until", str(float(until)))

    def network_blocked_until(self) -> float:
        try:
            return float(self.get_meta("network_block_until", "0") or 0)
        except ValueError:
            return 0.0

    # ------------------------------------------------------------------ jobs
    def enqueue(self, specs: list[dict]) -> tuple[int, int]:
        """Insert job specs; existing ids are left untouched.  Returns (new, existing)."""
        new = 0
        with self._lock:
            cur = self.conn.cursor()
            for s in specs:
                cur.execute(
                    "INSERT OR IGNORE INTO jobs"
                    "(id, kind, model, priority, payload, prompt_hash, status,"
                    " max_attempts, rep, created_at)"
                    " VALUES(?,?,?,?,?,?, 'pending', ?,?,?)",
                    (s["id"], s["kind"], s["model"], int(s.get("priority", 100)),
                     json.dumps(s.get("payload") or {}, ensure_ascii=False),
                     s.get("prompt_hash"), int(s.get("max_attempts", 3)),
                     int(s.get("rep", 0)), time.time()))
                new += cur.rowcount
            self.conn.commit()
        return new, len(specs) - new

    def counts(self) -> dict:
        with self._lock:
            rows = self.conn.execute(
                "SELECT status, COUNT(*) AS n FROM jobs GROUP BY status").fetchall()
        out = {r["status"]: r["n"] for r in rows}
        for key in ("pending", "running", "done", "dead"):
            out.setdefault(key, 0)
        out["total"] = sum(out.values())
        return out

    def counts_by_model(self, status: str = "pending") -> dict[str, int]:
        with self._lock:
            rows = self.conn.execute(
                "SELECT model, COUNT(*) AS n FROM jobs WHERE status=? GROUP BY model",
                (status,)).fetchall()
        return {r["model"]: r["n"] for r in rows}

    def counts_by_kind(self, status: str = "pending") -> dict[str, int]:
        with self._lock:
            rows = self.conn.execute(
                "SELECT kind, COUNT(*) AS n FROM jobs WHERE status=? GROUP BY kind",
                (status,)).fetchall()
        return {r["kind"]: r["n"] for r in rows}

    def pick_job(self, model_weights: dict[str, float], strategy: str = "fair",
                 now: float | None = None) -> dict | None:
        with self._lock:
            if strategy == "fifo":
                row = self.conn.execute(
                    "SELECT * FROM jobs WHERE status='pending'"
                    " ORDER BY priority ASC, created_at ASC, id ASC LIMIT 1").fetchone()
                return dict(row) if row else None
            pending = self.counts_by_model("pending")
            if not pending:
                return None
            used = self.used_by_model(time.time() if now is None else float(now))
            # Least-used model relative to its target share; equal weights
            # therefore alternate evenly.  Priority orders jobs inside a model.
            def score(item):
                name, n = item
                w = float(model_weights.get(name, 1.0))
                if w <= 0:
                    return float("inf")
                return (used.get(name, 0) + 1) / w
            candidates = [(name, n) for name, n in pending.items()
                          if float(model_weights.get(name, 1.0)) > 0]
            if not candidates:
                return None
            model = min(candidates, key=score)[0]
            row = self.conn.execute(
                "SELECT * FROM jobs WHERE status='pending' AND model=?"
                " ORDER BY priority ASC, created_at ASC, id ASC LIMIT 1",
                (model,)).fetchone()
            return dict(row) if row else None

    def pick_exempt_job(self) -> dict | None:
        """Pick a pending job whose model bypasses the global quota.

        Used as a fallback when the paid provider window is full, so a
        separate-token backend (e.g. DeepSeek) can keep working.
        """
        models = sorted(set(self.policy.exempt_models) | set(self.policy.model_limits))
        if not models:
            return None
        marks = ",".join("?" for _ in models)
        with self._lock:
            row = self.conn.execute(
                f"SELECT * FROM jobs WHERE status='pending' AND model IN ({marks})"
                " ORDER BY priority ASC, created_at ASC, id ASC LIMIT 1",
                models).fetchone()
        return dict(row) if row else None

    def job(self, job_id: str) -> dict | None:
        with self._lock:
            row = self.conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return dict(row) if row else None

    def jobs(self, status: str | None = None, kind: str | None = None,
             model: str | None = None) -> list[dict]:
        q = "SELECT * FROM jobs WHERE 1=1"
        args: list = []
        if status:
            q += " AND status=?"
            args.append(status)
        if kind:
            q += " AND kind=?"
            args.append(kind)
        if model:
            q += " AND model=?"
            args.append(model)
        q += " ORDER BY created_at ASC, id ASC"
        with self._lock:
            return [dict(r) for r in self.conn.execute(q, args).fetchall()]

    # ----------------------------------------------------------------- calls
    def used_by_model(self, now: float) -> dict[str, int]:
        start, end = self.policy.window_bounds(now)
        with self._lock:
            rows = self.conn.execute(
                "SELECT model, COUNT(*) AS n FROM calls"
                " WHERE at>=? AND at<? AND released=0 GROUP BY model",
                (start, end)).fetchall()
        return {r["model"]: r["n"] for r in rows}

    def _call_times(self, start: float, end: float, only_model: str | None = None,
                    exclude_models=()) -> list[float]:
        rows = self.conn.execute(
            "SELECT at, model FROM calls WHERE at>=? AND at<? AND released=0 ORDER BY at",
            (start, end)).fetchall()
        exclude = set(exclude_models)
        out = []
        for r in rows:
            model = r["model"]
            if only_model is not None and model != only_model:
                continue
            if model in exclude:
                continue
            out.append(float(r["at"]))
        return out

    def try_reserve(self, job_id: str, model: str, now: float | None = None
                    ) -> tuple[int | None, float, int]:
        """Atomically reserve one call.  Returns (call_id|None, next_slot, used)."""
        now = time.time() if now is None else float(now)
        ml = self.policy.model_limits.get(model)
        exempt = self.policy.exempt(model)
        separate = exempt or ml is not None
        with self._lock:
            try:
                self.conn.execute("BEGIN IMMEDIATE")
                blocked = max(self.blocked_until(), self.network_blocked_until())
                limit = None
                if exempt:
                    start = end = now
                    times = []
                elif ml is not None:
                    limit, window_s = ml
                    start = now - window_s + 1e-6
                    end = now + 1e-6
                    times = self._call_times(start, end, only_model=model)
                else:
                    start, end = self.policy.window_bounds(now)
                    times = self._call_times(
                        start, end,
                        exclude_models=set(self.policy.model_limits) | set(self.policy.exempt_models))
                    limit = self.policy.limit
                if not separate and now < blocked:
                    self.conn.rollback()
                    return None, blocked, len(times)
                if limit is not None and len(times) >= limit:
                    nxt = (max(now, min(times) + window_s) if ml is not None
                           else self.policy.next_slot(now, times))
                    self.conn.rollback()
                    return None, nxt, len(times)
                cur = self.conn.execute(
                    "INSERT INTO calls(at, model, job_id, outcome) VALUES(?,?,?, 'reserved')",
                    (now, model, job_id))
                call_id = int(cur.lastrowid)
                self.conn.execute(
                    "UPDATE jobs SET status='running', started_at=?,"
                    " attempts=attempts+1, error=NULL WHERE id=?",
                    (now, job_id))
                self.conn.commit()
                return call_id, now, len(times) + 1
            except Exception:
                self.conn.rollback()
                raise

    def reserve_call_raw(self, model: str, now: float | None = None
                         ) -> tuple[int | None, float, int]:
        """Reserve a call that is not tied to a queued job (used by probes)."""
        now = time.time() if now is None else float(now)
        ml = self.policy.model_limits.get(model)
        exempt = self.policy.exempt(model)
        separate = exempt or ml is not None
        with self._lock:
            try:
                self.conn.execute("BEGIN IMMEDIATE")
                blocked = max(self.blocked_until(), self.network_blocked_until())
                limit = None
                if exempt:
                    start = end = now
                    times = []
                elif ml is not None:
                    limit, window_s = ml
                    start = now - window_s + 1e-6
                    end = now + 1e-6
                    times = self._call_times(start, end, only_model=model)
                else:
                    start, end = self.policy.window_bounds(now)
                    times = self._call_times(
                        start, end,
                        exclude_models=set(self.policy.model_limits) | set(self.policy.exempt_models))
                    limit = self.policy.limit
                if not separate and now < blocked:
                    self.conn.rollback()
                    return None, blocked, len(times)
                if limit is not None and len(times) >= limit:
                    nxt = (max(now, min(times) + window_s) if ml is not None
                           else self.policy.next_slot(now, times))
                    self.conn.rollback()
                    return None, nxt, len(times)
                cur = self.conn.execute(
                    "INSERT INTO calls(at, model, job_id, outcome)"
                    " VALUES(?,?,?, 'probe')", (now, model, f"probe:{model}"))
                call_id = int(cur.lastrowid)
                self.conn.commit()
                return call_id, now, len(times) + 1
            except Exception:
                self.conn.rollback()
                raise

    def finish_call(self, call_id: int, outcome: str, http_status: int | None = None,
                    latency_s: float | None = None, in_tokens: int | None = None,
                    out_tokens: int | None = None, released: bool = False) -> None:
        with self._lock:
            self.conn.execute(
                "UPDATE calls SET outcome=?, http_status=?, latency_s=?,"
                " in_tokens=?, out_tokens=?, released=? WHERE id=?",
                (outcome, http_status, latency_s, in_tokens, out_tokens,
                 1 if released else 0, call_id))
            self.conn.commit()

    def release_call(self, call_id: int, reason: str = "preflight") -> None:
        with self._lock:
            self.conn.execute(
                "UPDATE calls SET released=1, outcome=? WHERE id=?", (reason, call_id))
            self.conn.commit()

    def finish_job(self, job_id: str, status: str, metrics: dict | None = None,
                   result_path: str | None = None, error: str | None = None) -> None:
        with self._lock:
            self.conn.execute(
                "UPDATE jobs SET status=?, finished_at=?, metrics=?, result_path=?, error=?"
                " WHERE id=?",
                (status, time.time(), json.dumps(metrics or {}, ensure_ascii=False),
                 result_path, error, job_id))
            self.conn.commit()

    def retry_job(self, job_id: str, error: str) -> str:
        """Requeue if attempts remain; otherwise mark dead.  Returns new status."""
        with self._lock:
            row = self.conn.execute(
                "SELECT attempts, max_attempts FROM jobs WHERE id=?", (job_id,)).fetchone()
            if row is None:
                return "missing"
            status = "pending" if row["attempts"] < row["max_attempts"] else "dead"
            self.conn.execute(
                "UPDATE jobs SET status=?, error=?, finished_at=? WHERE id=?",
                (status, error, None if status == "pending" else time.time(), job_id))
            self.conn.commit()
        return status

    def requeue_without_attempt(self, job_id: str, error: str) -> str:
        """Requeue a 429 job without consuming an attempt (no request was served)."""
        with self._lock:
            self.conn.execute(
                "UPDATE jobs SET status='pending', error=?, finished_at=NULL,"
                " attempts=MAX(attempts-1, 0) WHERE id=?", (error, job_id))
            self.conn.commit()
        return "pending"

    def fail_job(self, job_id: str, error: str, retryable: bool = True) -> str:
        """Retry transient errors; mark non-retryable errors dead immediately."""
        if retryable:
            return self.retry_job(job_id, error)
        with self._lock:
            self.conn.execute(
                "UPDATE jobs SET status='dead', error=?, finished_at=? WHERE id=?",
                (error, time.time(), job_id))
            self.conn.commit()
        return "dead"

    def disable_jobs(self, model: str, kind: str, reason: str) -> int:
        """Mark pending jobs of one kind/model dead (e.g. vision probe failed)."""
        with self._lock:
            cur = self.conn.execute(
                "UPDATE jobs SET status='dead', error=?, finished_at=?"
                " WHERE model=? AND kind=? AND status IN ('pending','running')",
                (reason, time.time(), model, kind))
            self.conn.commit()
        return cur.rowcount

    def reset_stale(self, max_age_s: float = 1800) -> int:
        """Return abandoned running jobs to pending (or dead) after a crash."""
        cutoff = time.time() - max_age_s
        with self._lock:
            rows = self.conn.execute(
                "SELECT id, attempts, max_attempts FROM jobs"
                " WHERE status='running' AND started_at<?", (cutoff,)).fetchall()
            for r in rows:
                status = "pending" if r["attempts"] < r["max_attempts"] else "dead"
                self.conn.execute(
                    "UPDATE jobs SET status=?, error='stale running job' WHERE id=?",
                    (status, r["id"]))
            self.conn.commit()
        return len(rows)

    # ----------------------------------------------------------------- stats
    def quota_status(self, now: float | None = None) -> dict:
        now = time.time() if now is None else float(now)
        start, end = self.policy.window_bounds(now)
        separate = set(self.policy.model_limits) | set(self.policy.exempt_models)
        with self._lock:
            times = self._call_times(start, end, exclude_models=separate)
            rows = self.conn.execute(
                "SELECT model, COUNT(*) AS n FROM calls"
                " WHERE at>=? AND at<? AND released=0 GROUP BY model",
                (start, end)).fetchall()
            model_windows = {}
            for name, (limit, window_s) in self.policy.model_limits.items():
                ws = now - window_s + 1e-6
                wt = self._call_times(ws, now + 1e-6, only_model=name)
                model_windows[name] = {
                    "limit": limit, "used": len(wt),
                    "window_hours": round(window_s / 3600.0, 3),
                    "next_slot": max(now, min(wt) + window_s) if len(wt) >= limit else now,
                }
        used = len(times)
        blocked = self.blocked_until()
        network = self.network_blocked_until()
        return {
            "mode": self.policy.mode,
            "limit": self.policy.limit,
            "window_hours": round(self.policy.window_s / 3600.0, 3),
            "window_start": start,
            "window_end": end,
            "used": used,
            "remaining": max(0, self.policy.limit - used),
            "utilization": round(self.policy.utilization(used), 4),
            "next_slot": max(self.policy.next_slot(now, times), blocked, network),
            "blocked_until": blocked if blocked > now else None,
            "network_blocked_until": network if network > now else None,
            "reported_used": self.get_meta("reported_used"),
            "per_model": {r["model"]: r["n"] for r in rows},
            "model_windows": model_windows,
            "released": self.conn.execute(
                "SELECT COUNT(*) AS n FROM calls WHERE at>=? AND at<? AND released=1",
                (start, end)).fetchone()["n"],
        }

    def history(self, now: float | None = None, buckets: int = 8) -> list[dict]:
        """Call counts in trailing clock-aligned windows (current one partial)."""
        import math
        now = time.time() if now is None else float(now)
        w = self.policy.window_s
        if self.policy.mode == "fixed" and self.policy.anchor is not None:
            k = math.floor((now - self.policy.anchor) / w)
            end = self.policy.anchor + (k + 1) * w
        else:
            end = (math.floor(now / w) + 1) * w
        out = []
        separate = sorted(set(self.policy.model_limits) | set(self.policy.exempt_models))
        marks = ",".join("?" for _ in separate)
        for i in range(buckets - 1, -1, -1):
            b_end = end - i * w
            b_start = b_end - w
            with self._lock:
                sql = ("SELECT COUNT(*) AS n FROM calls"
                       " WHERE at>=? AND at<? AND released=0")
                args = [b_start, b_end]
                if separate:
                    sql += f" AND model NOT IN ({marks})"
                    args.extend(separate)
                n = self.conn.execute(sql, args).fetchone()["n"]
            out.append({"start": b_start, "end": b_end, "used": n,
                        "limit": self.policy.limit,
                        "current": b_start <= now < b_end})
        return out

    def usage_rows(self) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self.conn.execute(
                "SELECT * FROM calls ORDER BY id ASC").fetchall()]

    def calls_after(self, call_id: int = 0, limit: int = 500) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self.conn.execute(
                "SELECT * FROM calls WHERE id>? ORDER BY id ASC LIMIT ?",
                (int(call_id), int(limit))).fetchall()]

    def max_call_id(self) -> int:
        with self._lock:
            row = self.conn.execute("SELECT MAX(id) AS n FROM calls").fetchone()
        return int(row["n"] or 0)

    def done_jobs(self) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self.conn.execute(
                "SELECT * FROM jobs WHERE status='done' ORDER BY finished_at ASC").fetchall()]

    def close(self) -> None:
        with self._lock:
            self.conn.close()
