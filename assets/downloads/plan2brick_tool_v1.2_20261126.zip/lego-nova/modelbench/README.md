# modelbench · quota-aware multi-model comparison

This package closes the two evaluation gaps that the Plan2Brick protocol still
lists as **not tested**: live image perception (M2, image → IR) and the
LLM-direct baseline (text plan + brief → IR). It compares **Claude, GPT and
Gemini** on the same frozen inputs and scores every response with the same
deterministic code used by the rest of the benchmark.

The provider quota is **150 calls per 3 hours** (1 call per 72 s, 1,200/day).
The scheduler treats that as a hard resource: it reserves a slot before every
request, persists the call ledger in SQLite, and keeps a replication tail so
the quota is consumed in every window instead of being wasted.

## 1. Setup

```powershell
# from C:\Users\XCY\Desktop\CSCI4998\lego-nova
C:\Python314\python.exe -m modelbench init-config
# edit modelbench\config.local.json:
#   providers.relay.base_url, providers.relay.api_key_env
#   models.claude.model / models.gpt.model / models.gemini.model
# then set the key in the environment (never write it into the JSON):
$env:MODELBENCH_API_KEY = "..."
C:\Python314\python.exe -m modelbench validate-config
```

`config.local.json` is git-ignored. `models.example.json` shows the schema.
Three wire protocols are supported:

| `protocol` | endpoint | notes |
|---|---|---|
| `openai` | `{base_url}/v1/chat/completions` (or a full `/chat/completions` URL) | most relay vendors exposing all three families behind one API |
| `anthropic` | `{base_url}/v1/messages` | native Anthropic Messages API |
| `gemini` | `{base_url}/v1beta/models/{model}:generateContent` | native Google API |

The API key is read at call time from `api_key_env`, or from a local JSON
profile via `api_key_file` + `api_key_path` (for example
`~/.claude/profiles/aipro.json` → `env.ANTHROPIC_AUTH_TOKEN`). It is never
printed, logged, or stored in the repository.

The current live profile uses the aipro gateway (`https://vip.aipro.love/v1`,
OpenAI-compatible) with `claude-opus-5` and `gpt-6.1-sol`. The same key returns
403 `upstream authentication failed` for Gemini (`gemini-3.1-pro-high` and
`gemini-3-flash` were both tested), so Gemini is omitted; add a separate
provider/key if it becomes available. Change the `model` values in
`config.local.json` if you want a different tier/family.

## 1.1 Probe before a batch

```powershell
C:\Python314\python.exe -m modelbench probe --image fyp-pipeline\inputs\floorplan_B.png
```

This makes one tiny text/vision call per model (recorded in the same quota
ledger) and prints status/latency. `start_after_reset.py` runs this probe
automatically after the provider's rolling window recovers, disables
perception jobs for a model that cannot see images, and only then starts the
worker.

Live provider notes (2026-11-05):

- Gemini is not available on the aipro key: both `gemini-3.1-pro-high` and
  `gemini-3-flash` return 403 `upstream authentication failed`. Gemini jobs are
  marked dead and the config now lists only Claude and GPT.
- R1 (the largest real plan, 11 rooms) returned upstream HTTP 500 for both
  Claude and GPT after three attempts; those perception jobs are skipped rather
  than retried forever. R2–R9 and A/B/C continue. A future retry can use a
  smaller image / `max_output_tokens` to test whether the upstream limit is
  the cause.

## 2. Task matrix

The primary matrix is fixed before any call:

| task | input | outputs | cells × models × reps |
|---|---|---|---|
| `perception` | 12 source images (R1–R9 + A/B/C) | scene IR | 12 × 3 × reps |
| `llm_direct` | room list + dims + one of 4 briefs | scene IR | 64 applicable cells × 3 × reps |
| `judge` | two candidate summaries from the v1.3 D3 run | `A/B/tie` preference | 64 cells × 15 pairs × 3 (tail) |
| `asset_plan` | topology + target area + room budget + style + variant | new scene IR, schematic PNG, build check | 84 prompts × models × reps |
| `asset_library` | focus category + style + existing inventory | candidate item metadata, aliases, BrickNet queries | 96 prompts × models × reps |

The asset tasks are the long-lived stage after the comparison. `asset_plan`
asks the model for a complete new floor-plan IR; the harness validates it with
`check_ir`, builds it with the deterministic solver, and renders a clean input
schematic PNG. Accepted plans go to `out/assets/plans/` plus `index.jsonl`;
they are **candidates**, never inserted into the frozen benchmark automatically.
`asset_library` asks for new furniture metadata, everyday aliases and
BrickNet-style retrieval queries; accepted items go to
`out/assets/library/` plus `index.jsonl` for the next controlled library
version (no invented MPD ids or geometry).

`perception` uses the manual transcriptions R4–R9 as GT for both rooms and
objects; R1–R3 use hand-read room dimensions but the cached M2 flash IR for
objects; A/B/C use the cached M2 flash IR for both. The report records this
`gt_source` and never presents cached objects as human GT.

`llm_direct` gives the model only room names, dimensions and the brief — not
the reference furniture list and not `layout_m`. Its output is built by the
same deterministic solver, so requested/placed coverage and overlaps are
directly comparable across models.

`judge` is an LLM-as-judge **proxy**, not a human preference study. It is used
as a long-tail filler after the core matrix; the human pilot remains separate.

Repetitions use temperature 0 for rep 0 and `defaults.replication_temperature`
(default 0.4) for later reps. Every job id is a content hash of
`(kind, model, payload, prompt hash, rep)`, so re-running `plan` is idempotent
and a prompt edit creates new jobs instead of mixing versions.

## 2.1 Asset stage (after the comparison)

The asset stage is pre-enqueued behind the comparison; priority order is
`core 10/20 → asset_plan 70+ → asset_library 75+ → judge 100`:

```powershell
# 84 plan constraints x 2 models x 8 variants = 1,344 calls
C:\Python314\python.exe -m modelbench plan --tasks asset_plan --reps 8 --models claude,gpt
# 96 category/style prompts x 2 models x 4 variants = 768 calls
C:\Python314\python.exe -m modelbench plan --tasks asset_library --reps 4 --models claude,gpt
```

Accepted plans land in `out/assets/plans/<job>.json` and `.png` (clean
schematic), with one line per accepted plan in `out/assets/plans/index.jsonl`.
Accepted library items/aliases land in `out/assets/library/<job>.json` and
`index.jsonl`. These are a **candidate pool**: the frozen `bench/plans*.json`
and the 58-item controlled library are never modified by the worker. Review
the pool and promote selected entries in a versioned update.

```powershell
C:\Python314\python.exe -m modelbench assets
```

The stage is finite by design (2,112 asset calls); raise `--max-reps` or add
more prompt families if you want a longer tail. It is deliberately long
enough to keep using every quota window after the comparison.

## 3. Run

```powershell
# enqueue the primary matrix (one repetition each)
C:\Python314\python.exe -m modelbench plan --tasks perception,llm_direct --reps 1

# long-running scheduler: fills the replication tail automatically,
# then falls back to judge pairs when the core tail is exhausted
C:\Python314\python.exe -m modelbench run --concurrency 4 --max-reps 8 --status-every 600

# optional: spread calls at exactly one per 72 s instead of bursting the window
C:\Python314\python.exe -m modelbench run --concurrency 2 --pace

# inspect without stopping the worker
C:\Python314\python.exe -m modelbench status

# aggregate results
C:\Python314\python.exe -m modelbench report
```

A `start-modelbench.cmd` launcher is included for a double-click/startup run.
The worker is resumable: jobs are `pending/running/done/dead` in
`modelbench/state/queue.sqlite3`; a crash leaves in-flight jobs `running` and
`reset-stale` returns them to `pending` (or `dead` after max attempts).

### How the quota is kept full

1. **Reserve before call.** `Store.try_reserve` runs under `BEGIN IMMEDIATE`,
   counts non-released calls in the current window and inserts the reservation
   atomically. A second worker on the same database cannot overrun.
2. **Sliding window (default).** At most 150 calls in any trailing 3 h. A cold
   start may burst the first 150; after that the limiter opens one slot every
   72 s and the scheduler dispatches as soon as it opens. Steady state is
   exactly 150 calls per 3 h — i.e. 100% of the quota.
3. **Fixed window (optional).** `quota.mode="fixed"` plus `quota.anchor` (ISO
   time or `HH:MM`) spends the whole window budget at the window start. Use
   this only if the provider resets on a clock boundary; the sliding mode is
   safe for both.
4. **Filler.** `plan` enqueues the primary matrix; `run` tops the queue up to
   `--max-reps` (default 8) whenever pending falls below the low watermark
   (default 150). Priority order is **core comparison (10/20) → asset_plan
   (70+) → asset_library (75+) → judge (100)**, so every core repetition is
   finished before the long asset stage starts, and judge pairs only run after
   the asset queue is exhausted. With two active models the tail is roughly
   `12×2×8 + 64×2×8 = 1,216` core calls, `84×2×8 = 1,344` plan candidates,
   `96×2×4 = 768` library batches, and up to `64×15×2 = 1,920` judge calls —
   about 5,250 calls or 4.4 days at 1,200/day.
5. **Retries.** A 429 or a preflight connection error releases the reservation
   (`quota.release_on_429` / `release_on_connection_error`, both true by
   default); other errors keep the reservation because the provider may have
   counted them. Retries are capped by `max_attempts` (default 3) and show up
   as `dead` jobs in `status`.
6. **No silent waste.** `status` shows the last 8 clock windows as
   `[used/limit]` and the pending count. If the queue cannot fill a window,
   the reason is visible (no pending jobs / all models exhausted / dead
   jobs), rather than silently idling.

### 3.1 The quota is account-wide, not process-wide

The provider meters the **key**, not this process. Any other session using the
same key (for example an interactive `claude-aipro` session) consumes the same
150 calls. The local ledger only counts calls made by modelbench; it cannot
see external calls in advance. When the provider returns 429 it includes the
used count and the recovery time (e.g. `当前已使用150次，预计17分钟后（20:26）恢复`).
The scheduler parses both, persists `blocked_until` in the ledger, pauses all
dispatch, and requeues the 429 job **without consuming an attempt**. If the
provider frees only part of the window, the next 429 refreshes the estimate.

Operationally: to let the batch consume all 150, use a key that is not also
driving an interactive session, or keep interactive usage idle while the
worker runs. `status` prints `Blocked: provider quota exhausted ...` while it
waits.

### 3.2 Separate-token / separate-quota backends

`quota.model_limits` gives a model its own call window instead of sharing the
paid-provider limit, e.g.:

```json
"quota": {
  "limit": 150,
  "window_hours": 3,
  "model_limits": {"deepseek": {"limit": 150, "window_hours": 3}}
}
```

DeepSeek calls are recorded in `calls` but counted in their own 150/3h window,
not the aipro window. When the aipro window is full, the scheduler falls back
to a pending DeepSeek job so the separate-token backend keeps working; the
aipro provider resumes when its next slot opens. `status` shows the aipro quota
in `used/limit`, plus a `Quota[deepseek]` line. `quota.exempt_models` remains
available for a truly uncapped backend, but should not be used for a metered
API.

## 4. Scoring

* `perception`: JSON/schema validity, room recall/precision with fuzzy
  bilingual name matching, dimension MAE (axis-swap aware, mm→m fixed for
  R1–R3), area MAE, object-category precision/recall/F1 (micro over count
  vectors), plus an optional deterministic assembly (coverage, overlaps,
  parts).
* `llm_direct`: JSON/schema validity, room preservation and dimension MAE,
  brief-effect assertions (add/remove/replace/change-room-use), object count,
  and the same deterministic assembly metrics.
* `judge`: winner and criteria only; the report shows A/B/tie distribution and
  cross-model agreement, not accuracy (there is no human label yet).

`report` writes `out/model_compare_<stamp>.md` and `.json` with per-model
metrics, paired comparisons on the same `(plan, brief, rep)`, token usage,
latency, cost when prices are configured, quota windows, and dead jobs.

## 5. Dry run

`config.mock.json` defines three mock models with no network access:

```powershell
C:\Python314\python.exe -m modelbench plan --config modelbench\config.mock.json --tasks perception,llm_direct --reps 1
C:\Python314\python.exe -m modelbench run --config modelbench\config.mock.json --once --max-calls 12 --no-build --no-fill
C:\Python314\python.exe -m modelbench report --config modelbench\config.mock.json
```

This exercises the queue, quota ledger, scoring and report without spending a
single provider call. Tests: `python tests\test_modelbench.py -v` (stdlib
`unittest`, no pytest required).

## 6. Operational rules

* Use **one** state database per provider quota. If you run several worker
  processes, point them all at the same `--state-db`; the reservation
  transaction is the only thing that prevents overrun.
* Do not edit a prompt while a run is active unless you intend new job ids;
  old and new prompt hashes are kept separate by design.
* Provider keys stay in environment variables. `config.local.json`,
  `state*/` and `out*/` are git-ignored.
* The images and manual IRs are for local research use; see
  `fyp-pipeline/inputs/real/SOURCES.md` for provenance and do not redistribute
  the source floor plans.
