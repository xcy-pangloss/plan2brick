"""Wait for the provider's 3 h window, probe each model, then run the worker.

This is the no-PowerShell-policy launcher for a long batch.  It logs to
``modelbench/state/launch.log``; every probe call and every job is recorded in
the same SQLite quota ledger, so the 150-call budget is never double-spent.

Usage (from ``lego-nova``):

    C:\\Python314\\python.exe modelbench\\start_after_reset.py
"""
from __future__ import annotations

import sys
import time
import traceback
from pathlib import Path

NOVA = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NOVA))

from modelbench import report, transport  # noqa: E402
from modelbench.config import load_config  # noqa: E402
from modelbench.quota import QuotaPolicy, parse_anchor  # noqa: E402
from modelbench.store import Store  # noqa: E402
from modelbench.worker import Worker  # noqa: E402

LOG = NOVA / "modelbench" / "state" / "launch.log"
IMAGE = NOVA.parent / "fyp-pipeline" / "inputs" / "floorplan_B.png"


def log(msg: str) -> None:
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}"
    print(line, flush=True)
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def wait_for_window(store: Store, cfg) -> bool:
    while True:
        until = store.blocked_until()
        now = time.time()
        if now >= until:
            return True
        left = int(until - now)
        log(f"quota blocked; waiting {left}s (reported used={store.get_meta('reported_used')})")
        time.sleep(min(60, max(5, left)))


def _one_call(cfg, store: Store, model: str, prompt: str,
              images: list[str] | None, max_tokens: int) -> tuple[bool, str]:
    call_id, nxt, used = store.reserve_call_raw(model)
    if call_id is None:
        wait_for_window(store, cfg)
        call_id, nxt, used = store.reserve_call_raw(model)
        if call_id is None:
            return False, f"429; quota full ({used}/{cfg.quota.limit})"
    try:
        res = transport.call_model(cfg, model, prompt, images,
                                   max_output_tokens=max_tokens)
        store.finish_call(call_id, "ok", http_status=res.http_status,
                          latency_s=res.latency_s,
                          in_tokens=(res.usage or {}).get("in"),
                          out_tokens=(res.usage or {}).get("out"))
        return True, " ".join((res.text or "").split())[:160]
    except transport.TransportError as exc:
        released = bool(exc.release_slot)
        store.finish_call(call_id, "error", http_status=exc.status, released=released)
        if released:
            store.release_call(call_id, "probe")
        if exc.status == 429:
            until = time.time() + max(5.0, float(exc.retry_after or 60.0))
            store.set_quota_block(until, exc.reported_used)
            return False, f"429; resume {time.strftime('%H:%M:%S', time.localtime(until))}"
        return False, f"{exc.status}: {str(exc)[:200]}"


def probe(cfg, store: Store, model: str, image: Path) -> tuple[bool, bool, str]:
    """Return (available, vision_ok, note)."""
    ok, note = _one_call(cfg, store, model,
                         "Look at the attached floor-plan image. Name one room "
                         "label you can read. If you cannot see the image, reply "
                         "exactly: CANNOT_SEE",
                         [str(image)], 512)
    if ok:
        if "cannot_see" in note.lower() or not note.strip():
            return True, False, "model reports CANNOT_SEE"
        return True, True, note
    if note.startswith("429"):
        return False, False, note
    ok2, note2 = _one_call(cfg, store, model,
                           'Return exactly this JSON and nothing else: {"ok":true}',
                           None, 64)
    if ok2:
        return True, False, f"vision failed ({note}); text ok ({note2})"
    return False, False, f"vision: {note}; text: {note2}"


def main() -> int:
    cfg = load_config()
    policy = QuotaPolicy(cfg.quota.limit, cfg.quota.window_s, cfg.quota.mode,
                         parse_anchor(cfg.quota.anchor))
    store = Store(cfg.state_dir / "queue.sqlite3", policy)
    log("launcher started")
    wait_for_window(store, cfg)

    models = sorted(cfg.models)
    active = []
    for model in models:
        while True:
            ok, vision, note = probe(cfg, store, model, IMAGE)
            if note.startswith("429"):
                log(f"{model}: {note}; waiting for the window again")
                wait_for_window(store, cfg)
                continue
            break
        if ok and vision:
            log(f"{model}: vision probe OK ({note})")
            active.append(model)
        elif ok and not vision:
            log(f"{model}: text OK but no vision ({note}); disabling perception jobs")
            n = store.disable_jobs(model, "perception", f"vision probe failed: {note}")
            log(f"{model}: disabled {n} perception jobs")
            active.append(model)
        else:
            log(f"{model}: probe FAILED ({note}); disabling all jobs for this model")
            store.disable_jobs(model, "perception", f"probe failed: {note}")
            store.disable_jobs(model, "llm_direct", f"probe failed: {note}")
            store.disable_jobs(model, "judge", f"probe failed: {note}")
    if not active:
        log("no model passed the probe; worker not started")
        store.close()
        return 1

    log(f"starting worker with models: {', '.join(active)}")
    judge_run = NOVA / "bench" / "out" / "v13_main_table" / "d3_fidelity"
    worker = Worker(cfg, store, active, concurrency=3, max_reps=8,
                    build=True, auto_fill=True,
                    judge_run=str(judge_run) if judge_run.exists() else None)
    try:
        result = worker.run()
        log(f"worker exited: {result}")
    except KeyboardInterrupt:
        worker.stop()
        log("worker stopped by user")
    except Exception:
        log("worker crashed:\n" + traceback.format_exc())
        return 1
    finally:
        log(report.status_text(store, cfg))
        store.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
