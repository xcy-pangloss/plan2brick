"""Configuration for the Plan2Brick multi-model comparison harness.

The harness never stores credentials in the repository.  A provider entry names
an environment variable; the key is read from the process environment at call
time.  Copy ``models.example.json`` to ``config.local.json`` (git-ignored) and
fill in the provider endpoint and model ids.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

HERE = Path(__file__).resolve().parent
NOVA = HERE.parent
EXAMPLE_CONFIG = HERE / "models.example.json"
DEFAULT_CONFIG = HERE / "config.local.json"


class ConfigError(RuntimeError):
    pass


@dataclass
class ProviderConfig:
    name: str
    protocol: str                 # openai | anthropic | gemini | mock
    base_url: str = ""
    api_key_env: str = ""
    api_key_file: str = ""         # optional JSON file (e.g. a local profile)
    api_key_path: str = ""         # dot path inside that JSON, e.g. env.ANTHROPIC_AUTH_TOKEN
    timeout_s: float = 180.0
    extra_headers: dict = field(default_factory=dict)
    api_version: str = "2023-06-01"
    max_tokens_field: str = "max_tokens"
    supports_system: bool = True


@dataclass
class ModelConfig:
    name: str
    provider: str
    model: str
    vision: bool = True
    weight: float = 1.0
    max_output_tokens: int = 4096
    temperature: float | None = 0.0
    max_tokens_field: str = ""        # override provider field, e.g. max_completion_tokens
    price_in: float | None = None      # USD per 1M input tokens
    price_out: float | None = None     # USD per 1M output tokens


@dataclass
class QuotaConfig:
    limit: int = 150
    window_hours: float = 3.0
    mode: str = "sliding"              # sliding | fixed
    anchor: str | None = None          # fixed mode: ISO time, e.g. 2026-11-05T00:00:00+08:00
    release_on_429: bool = True
    release_on_connection_error: bool = True
    exempt_models: list[str] = field(default_factory=list)
    model_limits: dict[str, dict] = field(default_factory=dict)

    @property
    def window_s(self) -> float:
        return float(self.window_hours) * 3600.0


@dataclass
class BenchConfig:
    path: Path
    providers: dict[str, ProviderConfig]
    models: dict[str, ModelConfig]
    quota: QuotaConfig
    state_dir: Path
    out_dir: Path
    defaults: dict
    raw: dict

    def model(self, name: str) -> ModelConfig:
        try:
            return self.models[name]
        except KeyError as exc:
            raise ConfigError(f"unknown model {name!r}; configured: {sorted(self.models)}") from exc

    def provider(self, name: str) -> ProviderConfig:
        try:
            return self.providers[name]
        except KeyError as exc:
            raise ConfigError(f"model references unknown provider {name!r}") from exc

    def api_key(self, provider_name: str) -> str:
        prov = self.provider(provider_name)
        if prov.protocol == "mock":
            return "mock"
        key = os.environ.get(prov.api_key_env or "") if prov.api_key_env else ""
        if not key and prov.api_key_file:
            path = Path(prov.api_key_file).expanduser()
            try:
                data = json.loads(path.read_text(encoding="utf-8-sig"))
                node = data
                for part in (prov.api_key_path or "").split("."):
                    if part:
                        node = node[part]
                key = str(node or "")
            except Exception as exc:
                raise ConfigError(
                    f"cannot read API key from {path} ({prov.api_key_path}): {exc}") from exc
        if not key:
            raise ConfigError(
                f"no API key for provider {provider_name!r}: set "
                f"{prov.api_key_env!r} or configure api_key_file/api_key_path")
        return key


def _resolve(path: str | Path, base: Path) -> Path:
    p = Path(path).expanduser()
    return p if p.is_absolute() else (base / p).resolve()


def load_config(path: str | Path | None = None) -> BenchConfig:
    p = Path(path) if path else Path(os.environ.get("MODELBENCH_CONFIG", DEFAULT_CONFIG))
    p = p.expanduser().resolve()
    if not p.exists():
        raise ConfigError(
            f"config not found: {p}\n"
            f"copy {EXAMPLE_CONFIG.name} to {DEFAULT_CONFIG.name} and fill in the "
            f"provider endpoint, model ids and quota; the API key stays in an env var.")
    raw = json.loads(p.read_text(encoding="utf-8"))
    base = p.parent

    providers = {}
    for name, entry in (raw.get("providers") or {}).items():
        protocol = str(entry.get("protocol", "openai")).lower()
        if protocol not in ("openai", "anthropic", "gemini", "mock"):
            raise ConfigError(f"provider {name}: unsupported protocol {protocol!r}")
        providers[name] = ProviderConfig(
            name=name,
            protocol=protocol,
            base_url=str(entry.get("base_url", "")).rstrip("/"),
            api_key_env=str(entry.get("api_key_env", "")),
            api_key_file=str(entry.get("api_key_file", "")),
            api_key_path=str(entry.get("api_key_path", "")),
            timeout_s=float(entry.get("timeout_s", 180)),
            extra_headers=dict(entry.get("extra_headers") or {}),
            api_version=str(entry.get("api_version", "2023-06-01")),
            max_tokens_field=str(entry.get("max_tokens_field", "max_tokens")),
            supports_system=bool(entry.get("supports_system", True)),
        )

    models = {}
    for name, entry in (raw.get("models") or {}).items():
        provider = str(entry.get("provider", ""))
        if provider not in providers:
            raise ConfigError(f"model {name}: provider {provider!r} not defined")
        models[name] = ModelConfig(
            name=name,
            provider=provider,
            model=str(entry.get("model", "")),
            vision=bool(entry.get("vision", True)),
            weight=float(entry.get("weight", 1.0)),
            max_output_tokens=int(entry.get("max_output_tokens", 4096)),
            temperature=(None if entry.get("temperature") is None
                         else float(entry.get("temperature", 0.0))),
            max_tokens_field=str(entry.get("max_tokens_field", "")),
            price_in=entry.get("price_in"),
            price_out=entry.get("price_out"),
        )
    if not models:
        raise ConfigError("config has no models")

    q = raw.get("quota") or {}
    quota = QuotaConfig(
        limit=int(q.get("limit", 150)),
        window_hours=float(q.get("window_hours", 3)),
        mode=str(q.get("mode", "sliding")).lower(),
        anchor=q.get("anchor"),
        release_on_429=bool(q.get("release_on_429", True)),
        release_on_connection_error=bool(q.get("release_on_connection_error", True)),
        exempt_models=[str(x) for x in (q.get("exempt_models") or [])],
        model_limits={str(k): dict(v) for k, v in (q.get("model_limits") or {}).items()},
    )
    if quota.mode not in ("sliding", "fixed"):
        raise ConfigError("quota.mode must be 'sliding' or 'fixed'")
    if quota.limit <= 0 or quota.window_hours <= 0:
        raise ConfigError("quota.limit and quota.window_hours must be positive")

    defaults = dict(raw.get("defaults") or {})
    state_dir = _resolve(raw.get("state_dir", "state"), base)
    out_dir = _resolve(raw.get("out_dir", "out"), base)
    state_dir.mkdir(parents=True, exist_ok=True)
    out_dir.mkdir(parents=True, exist_ok=True)

    return BenchConfig(
        path=p, providers=providers, models=models, quota=quota,
        state_dir=state_dir, out_dir=out_dir, defaults=defaults, raw=raw)


def write_example(path: str | Path | None = None) -> Path:
    """Write a placeholder config (no secrets) and return the path."""
    target = Path(path) if path else DEFAULT_CONFIG
    target = target.expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        return target
    data = {
        "providers": {
            "relay": {
                "protocol": "openai",
                "base_url": "https://YOUR-PROVIDER.example/v1",
                "api_key_env": "MODELBENCH_API_KEY",
                "timeout_s": 240,
                "extra_headers": {}
            }
        },
        "models": {
            "claude": {"provider": "relay", "model": "CLAUDE_MODEL_ID", "vision": True, "weight": 1.0},
            "gpt": {"provider": "relay", "model": "GPT_MODEL_ID", "vision": True, "weight": 1.0},
            "gemini": {"provider": "relay", "model": "GEMINI_MODEL_ID", "vision": True, "weight": 1.0}
        },
        "quota": {"limit": 150, "window_hours": 3, "mode": "sliding"},
        "state_dir": "state",
        "out_dir": "out",
        "defaults": {"temperature": 0.0, "max_output_tokens": 4096}
    }
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return target
