"""Quota-window arithmetic.

Two modes are supported:

``sliding``  at most ``limit`` calls in any trailing ``window_s`` interval.
             A full queue is consumed at one call per ``window_s/limit``
             seconds; a burst is allowed only at cold start.
``fixed``    at most ``limit`` calls in each clock-aligned window.  The anchor
             sets the window boundary; the scheduler may spend the whole
             window's budget as soon as the window opens.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, time


def parse_anchor(value: str | None) -> float | None:
    """Parse an ISO date/time or a local ``HH:MM`` string to a Unix timestamp."""
    if not value:
        return None
    if "T" not in value and ":" in value:
        hh, mm = value.split(":", 1)
        local = datetime.combine(datetime.now().astimezone().date(),
                                 time(int(hh), int(mm)))
        return local.timestamp()
    dt = datetime.fromisoformat(value)
    if dt.tzinfo is None:
        dt = dt.astimezone()
    return dt.timestamp()


def local_midnight(now: float | None = None) -> float:
    dt = datetime.fromtimestamp(now if now is not None else datetime.now().timestamp())
    dt = dt.astimezone()
    return dt.replace(hour=0, minute=0, second=0, microsecond=0).timestamp()


@dataclass(frozen=True)
class QuotaPolicy:
    limit: int
    window_s: float
    mode: str = "sliding"
    anchor: float | None = None
    exempt_models: frozenset[str] = frozenset()
    model_limits: dict[str, tuple[int, float]] = field(default_factory=dict)

    def __post_init__(self):
        if self.mode not in ("sliding", "fixed"):
            raise ValueError("mode must be sliding or fixed")
        if self.limit <= 0 or self.window_s <= 0:
            raise ValueError("limit and window_s must be positive")

    def exempt(self, model: str) -> bool:
        return model in self.exempt_models

    def separate(self, model: str) -> bool:
        """True when the model has its own token/quota instead of the global one."""
        return model in self.exempt_models or model in self.model_limits

    def window_bounds(self, now: float) -> tuple[float, float]:
        if self.mode == "sliding":
            # Sliding interval (now-window, now]; the epsilons make both ends
            # strict so a call exactly at the boundary leaves immediately.
            return now - self.window_s + 1e-6, now + 1e-6
        anchor = self.anchor if self.anchor is not None else local_midnight(now)
        k = math.floor((now - anchor) / self.window_s)
        start = anchor + k * self.window_s
        return start, start + self.window_s

    def next_slot(self, now: float, call_times: list[float]) -> float:
        """Earliest time a new call is allowed given the counted call times."""
        if len(call_times) < self.limit:
            return now
        if self.mode == "sliding":
            oldest = min(call_times)
            return max(now, oldest + self.window_s)
        _start, end = self.window_bounds(now)
        return end

    def utilization(self, used: int) -> float:
        return min(1.0, used / float(self.limit)) if self.limit else 0.0

    def bucket(self, now: float) -> tuple[float, float]:
        """Fixed 3-hour reporting bucket (independent of the scheduling mode)."""
        start, end = self.window_bounds(now) if self.mode == "fixed" else (
            math.floor(now / self.window_s) * self.window_s,
            (math.floor(now / self.window_s) + 1) * self.window_s)
        return start, end
