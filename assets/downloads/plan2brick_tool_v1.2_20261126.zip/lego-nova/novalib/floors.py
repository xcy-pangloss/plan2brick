"""Deterministic LEGO brick floors for Plan2Brick scenes.

A room zone in ``assembly.py`` is an LDU rectangle (x0, z0, x1, z1).  This
module fills the floor with real 24-LDU-tall bricks whose top face is at
``y = 0``: the same plane that the existing walls and furniture stand on.
The bricks therefore sit *below* the scene, never intersect furniture or
walls, and are written as ordinary ``1 ...`` MPD lines counted in the BOM.

Construction
------------
* The floor footprint is a union of axis-aligned rectangles on the global
  20-LDU grid.  ``IR.floor_m`` can spell out the apartment outline (useful for
  plans with corridors between rectangular rooms); otherwise every room zone
  is used.
* Rows are filled in two-stud-deep bands with 2xN bricks.  An odd final row
  uses 1xN bricks.  Runs are packed exactly with lengths {8,6,4,3,2,1}; a
  one-stud 2-deep remainder uses a rotated 1x2 brick (there is no 2x1 brick).
* Every floor brick has y = 0 (LDraw y grows downward, so the body occupies
  0..24 below the scene).  The top face is flush with the wall and furniture
  base plane.

Pure Python, no LDraw or three.js dependency.
"""
from __future__ import annotations

import math

LDU = 20
FLOOR_HEIGHT_LDU = 24
# Drop the floor top by 0.5 LDU (0.2 mm) so the LDraw validator's body-envelope
# tolerance does not report the flush floor/wall and floor/furniture faces as
# zero-penetration contacts.  At minifig scale this is invisible.
FLOOR_GAP_LDU = 0.5
FLOOR_COLOR = 28  # Dark Tan
FLOOR_MARKER = "0 // ---- FLOOR (LEGO bricks) ----"

# 2-stud-deep band, long axis along x.  A 1-stud remainder uses 3004 rotated.
FLOOR_2_BY_LENGTH = {
    1: "3004",  # Brick 1 x 2, rotated to 1 wide x 2 deep
    2: "3003",  # Brick 2 x 2
    3: "3002",  # Brick 2 x 3
    4: "3001",  # Brick 2 x 4
    6: "2456",  # Brick 2 x 6
    8: "3007",  # Brick 2 x 8
}
# 1-stud-deep band.
FLOOR_1_BY_LENGTH = {
    1: "3005",  # Brick 1 x 1
    2: "3004",  # Brick 1 x 2
    3: "3622",  # Brick 1 x 3
    4: "3010",  # Brick 1 x 4
    6: "3009",  # Brick 1 x 6
    8: "3008",  # Brick 1 x 8
}
ALLOWED_LENGTHS = (8, 6, 4, 3, 2, 1)
STARTS = (4, 3, 2, 1, 6, 8)
MATRIX_H = "1 0 0 0 1 0 0 0 1"
MATRIX_V = "0 0 1 0 1 0 -1 0 0"
EPS = 1e-6


def _cell_start(v: float) -> int:
    return int(math.floor(v / LDU + EPS))


def _cell_end(v: float) -> int:
    """Exclusive cell index: ceil(v / LDU)."""
    return int(math.ceil(v / LDU - EPS))


def rects_from_ir(ir: dict, rooms: list[dict]) -> list[list[float]]:
    """Floor rectangles in LDU.

    ``IR.floor_m`` is a list of ``[x0, z0, x1, z1]`` metre rectangles and wins
    when present.  Otherwise the union of the built room zones is used.
    """
    floor_m = ir.get("floor_m")
    if floor_m:
        out = []
        for r in floor_m:
            if not (isinstance(r, (list, tuple)) and len(r) >= 4):
                raise ValueError(f"floor_m entries must be [x0,z0,x1,z1], got {r!r}")
            x0, z0, x1, z1 = (float(v) * 100.0 for v in r[:4])
            if x1 <= x0 or z1 <= z0:
                raise ValueError(f"floor_m rectangle has no area: {r!r}")
            out.append([x0, z0, x1, z1])
        return out
    return [[float(r["x0"]), float(r["z0"]), float(r["x1"]), float(r["z1"])] for r in rooms]


def floor_cells(rects: list[list[float]]) -> set[tuple[int, int]]:
    """Rasterise floor rectangles onto the global 20-LDU grid."""
    cells: set[tuple[int, int]] = set()
    for x0, z0, x1, z1 in rects:
        for i in range(_cell_start(x0), _cell_end(x1)):
            for j in range(_cell_start(z0), _cell_end(z1)):
                cells.add((i, j))
    return cells


def pack_floor_run(length: int, phase: int = 0) -> list[int]:
    """Exact partition of a run into allowed lengths, avoiding a lone 1."""
    if length <= 0:
        return []
    out: list[int] = []
    rem = length
    for k in range(len(STARTS)):
        start = STARTS[(phase + k) % len(STARTS)]
        if start <= rem and rem - start != 1:
            out.append(start)
            rem -= start
            break
    if not out:
        out.append(rem)
        rem = 0
    while rem > 0:
        if rem in ALLOWED_LENGTHS:
            out.append(rem)
            break
        take = next((c for c in ALLOWED_LENGTHS if c <= rem and rem - c != 1), 1)
        out.append(take)
        rem -= take
    return out


def _row_runs(row_cells: set[int]) -> list[list[int]]:
    """Split a set of x indices into contiguous runs."""
    if not row_cells:
        return []
    vals = sorted(row_cells)
    runs = [[vals[0]]]
    for v in vals[1:]:
        if v == runs[-1][-1] + 1:
            runs[-1].append(v)
        else:
            runs.append([v])
    return runs


def _make_brick(i0: int, i1: int, j0: int, j1: int, depth: int, length: int,
                phase: int) -> dict:
    """Create one floor brick covering cells i0..i1, j0..j1."""
    if depth == 2:
        part = FLOOR_2_BY_LENGTH[length]
        yaw = 90 if length == 1 else 0
        matrix = MATRIX_V if yaw else MATRIX_H
    else:
        part = FLOOR_1_BY_LENGTH[length]
        yaw = 0
        matrix = MATRIX_H
    cx = (i0 + i1 + 1) * LDU / 2
    cz = (j0 + j1 + 1) * LDU / 2
    return {
        "part": part,
        "color": FLOOR_COLOR,
        "center_ldu": [round(cx, 1), FLOOR_GAP_LDU, round(cz, 1)],
        "yaw": yaw,
        "cells": [[i, j] for j in range(j0, j1 + 1) for i in range(i0, i1 + 1)],
        "aabb_ldu": [round(i0 * LDU, 1), round(j0 * LDU, 1),
                     round((i1 + 1) * LDU, 1), round((j1 + 1) * LDU, 1)],
        "matrix": matrix,
        "height_ldu": FLOOR_HEIGHT_LDU,
    }


def floor_bricks(rooms: list[dict], ir: dict | None = None,
                 rects_ldu: list[list[float]] | None = None) -> list[dict]:
    """Return every floor brick for the scene."""
    rects = rects_ldu if rects_ldu is not None else rects_from_ir(ir or {}, rooms)
    cells = floor_cells(rects)
    if not cells:
        return []

    remaining = set(cells)
    bricks: list[dict] = []
    run_no = 0
    for j in sorted({cell[1] for cell in cells}):
        while any(cell[1] == j for cell in remaining):
            row = {i for (i, jj) in remaining if jj == j}
            # Start the next run at the leftmost remaining cell in this row.
            i_start = min(row)
            run = [i_start]
            while (run[-1] + 1) in row:
                run.append(run[-1] + 1)
            below = {i for (i, jj) in remaining if jj == j + 1}
            depth = 2 if all(i in below for i in run) else 1
            # Pack the run; a 2-deep run consumes the same x cells in row j+1.
            lengths = pack_floor_run(len(run), phase=(j + run_no) % len(STARTS))
            pos = 0
            for length in lengths:
                piece = run[pos:pos + length]
                if len(piece) != length:
                    raise AssertionError("floor packing produced a short brick")
                brick = _make_brick(piece[0], piece[-1], j,
                                    j + depth - 1, depth, length, run_no)
                bricks.append(brick)
                pos += length
                run_no += 1
            for i in run:
                for jj in range(j, j + depth):
                    remaining.discard((i, jj))
    _assert_coverage(cells, bricks)
    return bricks


def _assert_coverage(cells: set[tuple[int, int]], bricks: list[dict]) -> None:
    seen: set[tuple[int, int]] = set()
    for b in bricks:
        for c in b["cells"]:
            key = (c[0], c[1])
            if key in seen:
                raise AssertionError(f"floor cell {key} covered twice")
            seen.add(key)
    if seen != cells:
        missing = sorted(cells - seen)[:6]
        extra = sorted(seen - cells)[:6]
        raise AssertionError(f"floor coverage mismatch missing={missing} extra={extra}")


def floor_summary(bricks: list[dict], rects_ldu: list[list[float]]) -> dict:
    area_studs2 = sum((r[2] - r[0]) * (r[3] - r[1]) for r in rects_ldu) / (LDU * LDU)
    return {
        "height_ldu": FLOOR_HEIGHT_LDU,
        "color": FLOOR_COLOR,
        "brick_count": len(bricks),
        "area_studs2": round(area_studs2, 1),
    }


def mpd_line(brick: dict) -> str:
    x, y, z = brick["center_ldu"]
    return (f"1 {brick['color']} {x:.4f} {y:.4f} {z:.4f} "
            f"{brick['matrix']} {brick['part']}.dat")
