"""Natural-language brief -> scene IR patch (Plan2Brick v1.0, deterministic).

The brief is a *small, auditable* patch language, not a second model call.  It
covers the four operations the single-entry demo needs:

  add a desk to the living room
  remove the plant from the balcony
  replace the coffee table with a desk in the living room
  use the dining room as a study
  style: minimal / compact / spacious

Every applied change is returned in ``actions``; anything not understood is
returned in ``unmatched`` and leaves the IR untouched.  No network calls and no
hidden fallbacks: an unsupported sentence is reported, not guessed.
"""
from __future__ import annotations

import re
from copy import deepcopy

from . import floorplan

# --------------------------------------------------------------------- words
# phrase -> IR category.  Longest phrase wins ("dining table" before "table").
ITEM_SYNONYMS = {
    "washing machine": "washer", "washer": "washer", "洗衣机": "washer",
    "refrigerator": "fridge", "fridge": "fridge", "冰箱": "fridge",
    "television": "tv", "tv": "tv", "电视": "tv",
    "bookshelf": "bookshelf", "bookcase": "bookshelf", "书架": "bookshelf",
    "nightstand": "cabinet", "wardrobe": "cabinet", "dresser": "cabinet",
    "sideboard": "cabinet", "tv stand": "cabinet", "media console": "cabinet",
    "cabinet": "cabinet", "衣柜": "cabinet", "床头柜": "cabinet", "电视柜": "cabinet", "柜子": "cabinet",
    "couch": "sofa", "sofa": "sofa", "沙发": "sofa",
    "bed": "bed", "床": "bed",
    "desk": "desk", "workspace": "desk", "书桌": "desk", "写字台": "desk",
    "dining table": "table", "coffee table": "table", "table": "table",
    "餐桌": "table", "茶几": "table", "桌子": "table",
    "armchair": "chair", "lounge chair": "chair", "chair": "chair", "stool": "chair", "椅子": "chair",
    "floor lamp": "lamp", "lamp": "lamp", "light": "lamp", "台灯": "lamp", "灯": "lamp",
    "potted plant": "plant", "plant": "plant", "盆栽": "plant", "绿植": "plant",
    "cooktop": "stove", "stove": "stove", "灶台": "stove",
    "washbasin": "sink", "basin": "sink", "sink": "sink", "洗手盆": "sink", "水槽": "sink",
    "toilet": "toilet", "马桶": "toilet", "坐便器": "toilet",
    "bathtub": "bath", "shower": "bath", "bath": "bath", "淋浴": "bath", "浴缸": "bath",
}

ROOM_TYPES = {
    "study": "study", "office": "study", "书房": "study", "工作间": "study",
    "bedroom": "bedroom", "卧室": "bedroom",
    "living room": "living", "living": "living", "客厅": "living", "起居室": "living",
    "dining room": "dining", "dining": "dining", "餐厅": "dining",
    "kitchen": "kitchen", "厨房": "kitchen",
    "bathroom": "bathroom", "卫生间": "bathroom", "浴室": "bathroom",
    "hallway": "hallway", "hall": "hallway", "过道": "hallway", "走廊": "hallway",
    "balcony": "balcony", "阳台": "balcony",
    "storage": "storage", "储藏室": "storage",
    "empty room": "empty", "空房": "empty",
}

ORDINALS = {
    "first": 0, "1st": 0, "第一": 0,
    "second": 1, "2nd": 1, "第二": 1,
    "third": 2, "3rd": 2, "第三": 2,
    "fourth": 3, "4th": 3, "第四": 3,
}


def _norm(text: str) -> str:
    return " ".join(re.findall(r"[a-z0-9一-鿿]+", (text or "").lower()))


def _item_category(phrase: str) -> str | None:
    q = _norm(phrase)
    for key in sorted(ITEM_SYNONYMS, key=len, reverse=True):
        if _norm(key) and _norm(key) in q:
            return ITEM_SYNONYMS[key]
    return None


def _room_type(phrase: str) -> str | None:
    q = _norm(phrase)
    for key in sorted(ROOM_TYPES, key=len, reverse=True):
        if _norm(key) and _norm(key) in q:
            return ROOM_TYPES[key]
    return None


def _ordinal(phrase: str) -> int | None:
    q = _norm(phrase)
    for key, idx in ORDINALS.items():
        if _norm(key) in q.split():
            return idx
    return None


ROOM_STOP = {"the", "a", "an", "room", "area", "zone"}


def _name_hit(q: str, name: str) -> bool:
    """Deliberately conservative: a generic shared word ("room") is not a match."""
    n = _norm(name)
    if not q or not n:
        return False
    if q in n or n in q:
        return True
    qt = {t for t in q.split() if t not in ROOM_STOP}
    nt = {t for t in n.split() if t not in ROOM_STOP}
    if not qt or not nt:
        return False
    # "second bedroom" vs "bedroom 2" is handled by the ordinal branch below;
    # otherwise require one content-token set to contain the other.
    return qt <= nt or nt <= qt


def _room_indices(ir: dict, phrase: str) -> list[int]:
    q = _norm(phrase)
    idx = _ordinal(phrase)
    if idx is not None:
        base = " ".join(t for t in q.split() if t not in ORDINALS)
        hits = [i for i, r in enumerate(ir.get("rooms") or [])
                if _name_hit(base, r.get("name_en", "")) or _name_hit(base, r.get("name_cn", ""))]
        if hits:
            return [hits[idx]] if idx < len(hits) else []
    hits = [i for i, r in enumerate(ir.get("rooms") or [])
            if _name_hit(q, r.get("name_en", "")) or _name_hit(q, r.get("name_cn", ""))]
    return hits


def _object_in_room(obj: dict, room: dict) -> bool:
    rn = _norm(obj.get("room", ""))
    return bool(rn) and (_name_hit(rn, room.get("name_cn", ""))
                         or _name_hit(rn, room.get("name_en", "")))


def _default_size(category: str) -> list[float]:
    for items in floorplan.FURNISH.values():
        for cat, _label, _count, size in items:
            if cat == category:
                return list(size)
    return [0.8, 0.6, 0.8]


def _add_object(ir: dict, room: dict, phrase: str, category: str) -> dict:
    obj = {
        "category": category,
        "label": f"{phrase.strip()} ({room.get('name_cn', '')})",
        "count": 1,
        "room": room.get("name_cn") or room.get("name_en"),
        "size_est_m": _default_size(category),
        "placement": "brief: added by user request",
        "confidence": 0.5,
    }
    ir.setdefault("objects", []).append(obj)
    return obj


def _remove_objects(ir: dict, rooms: list[dict], category: str) -> list[dict]:
    keep, removed = [], []
    for obj in ir.get("objects") or []:
        hit = (obj.get("category") == category
               and (not rooms or any(_object_in_room(obj, r) for r in rooms)))
        (removed if hit else keep).append(obj)
    ir["objects"] = keep
    return removed


def _clauses(text: str) -> list[str]:
    parts = re.split(r"(?:[.;]|\bthen\b|\band\b)", text or "", flags=re.I)
    return [p.strip(" ,") for p in parts if p.strip(" ,")]


def _apply_clause(ir: dict, clause: str) -> dict | None:
    """Try one clause; return an action record or None (unmatched)."""
    low = clause.lower()

    # replace X with Y [in room]
    m = re.search(r"\breplace\s+(?:the\s+)?(.+?)\s+with\s+(?:a|an|the)?\s*(.+?)"
                  r"(?:\s+(?:in|from)\s+(?:the\s+)?(.+))?$", low)
    if m:
        old_cat = _item_category(m.group(1))
        new_cat = _item_category(m.group(2))
        if not old_cat or not new_cat:
            return None
        rooms = [ir["rooms"][i] for i in _room_indices(ir, m.group(3) or "")]
        removed = _remove_objects(ir, rooms, old_cat)
        if not removed:
            rooms = [ir["rooms"][i] for i in _room_indices(ir, m.group(3) or "")]
            if not rooms:
                return None
        room = rooms[0] if rooms else next(
            (r for r in ir["rooms"] if _object_in_room(removed[0], r)), ir["rooms"][0])
        obj = _add_object(ir, room, m.group(2), new_cat)
        return {"action": "replace", "clause": clause, "room": room.get("name_cn"),
                "removed": len(removed), "added": obj["label"],
                "old_category": old_cat, "category": new_cat}

    # add X to room
    m = re.search(r"\b(?:add|put|place)\s+(?:a|an|the)?\s*(.+?)\s+"
                  r"(?:to|in|into)\s+(?:the\s+)?(.+)$", low)
    if m:
        cat = _item_category(m.group(1))
        hits = _room_indices(ir, m.group(2))
        if not cat or not hits:
            return None
        room = ir["rooms"][hits[0]]
        obj = _add_object(ir, room, m.group(1), cat)
        return {"action": "add", "clause": clause, "room": room.get("name_cn"),
                "added": obj["label"], "category": cat}

    # remove X [from room]
    m = re.search(r"\b(?:remove|delete|take out|drop)\s+(?:the\s+)?(.+?)"
                  r"(?:\s+(?:from|in)\s+(?:the\s+)?(.+))?$", low)
    if m:
        cat = _item_category(m.group(1))
        if not cat:
            return None
        rooms = [ir["rooms"][i] for i in _room_indices(ir, m.group(2) or "")]
        removed = _remove_objects(ir, rooms, cat)
        if not removed:
            return None
        return {"action": "remove", "clause": clause,
                "room": rooms[0].get("name_cn") if rooms else "all",
                "removed": len(removed), "category": cat}

    # use / turn / make X as/into a type
    m = re.search(r"\b(?:use|turn|make|convert|repurpose)\s+(?:the\s+)?(.+?)\s+"
                  r"(?:into|as)\s+(?:a|an|the)?\s*(.+)$", low)
    if m:
        hits = _room_indices(ir, m.group(1))
        rtype = _room_type(m.group(2))
        if not hits or not rtype:
            return None
        room = ir["rooms"][hits[0]]
        if sum(1 for r in ir["rooms"] if r.get("name_cn") == room.get("name_cn")) > 1:
            return None  # duplicate room name: refuse rather than refurnish the wrong instance
        ir["objects"] = [o for o in ir.get("objects") or [] if not _object_in_room(o, room)]
        for cat, label, count, size in floorplan.FURNISH.get(rtype, []):
            ir["objects"].append({
                "category": cat, "label": f"{label} ({room.get('name_cn', '')})",
                "count": count, "room": room.get("name_cn"),
                "size_est_m": list(size), "placement": f"brief: {rtype} program",
                "confidence": 0.6,
            })
        room["name_en"] = rtype          # plan colour / inferred type
        room["room_type"] = rtype        # replan/workbench honour the explicit type
        room["notes"] = (str(room.get("notes") or "") + f" Brief: used as {rtype}.").strip()
        return {"action": "use", "clause": clause, "room": room.get("name_cn"),
                "room_type": rtype, "objects": len(floorplan.FURNISH.get(rtype, []))}

    # style knobs
    if "minimal" in low:
        before = len(ir.get("objects") or [])
        ir["objects"] = [o for o in ir.get("objects") or [] if o.get("category") != "plant"]
        ir.setdefault("_build", {})["item_bias"] = 0.85
        return {"action": "style", "clause": clause, "style": "minimal",
                "removed": before - len(ir["objects"])}
    if "compact" in low:
        ir.setdefault("_build", {})["item_bias"] = 0.85
        return {"action": "style", "clause": clause, "style": "compact"}
    if "spacious" in low:
        ir.setdefault("_build", {})["item_bias"] = 1.15
        return {"action": "style", "clause": clause, "style": "spacious"}
    return None


def apply_brief(ir: dict, text: str) -> dict:
    """Return {ir, actions, unmatched}.  The input IR is not mutated."""
    patched = deepcopy(ir)
    actions, unmatched = [], []
    for clause in _clauses(text):
        # Apply each clause to a trial copy; commit only on success.  This keeps
        # ``unmatched`` and the returned IR consistent even if a helper bails
        # out after a partial mutation.
        trial = deepcopy(patched)
        action = _apply_clause(trial, clause)
        if action:
            patched = trial
            actions.append(action)
        else:
            unmatched.append(clause)
    if actions:
        patched["notes"] = (str(patched.get("notes") or "")
                            + " Brief applied: " + "; ".join(a["clause"] for a in actions)).strip()
    return {"ir": patched, "actions": actions, "unmatched": unmatched}
