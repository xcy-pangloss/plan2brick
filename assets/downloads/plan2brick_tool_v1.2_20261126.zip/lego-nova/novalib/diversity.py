"""Diversity v1: four-layer candidate operators + quality-diversity selection.

Plan2Brick's original candidates only rotated `pref_shift` and scaled
`item_bias`, so several candidates shared one layout and looked alike.  This
module samples four independent layers before the deterministic solver runs:

  program    style-driven optional furniture programme (minimal / balanced /
             family / wfh / compact / spacious)
  placement  per-category wall-band preference profiles + band fill direction
  palette    furniture recolour to a fixed LDraw palette (neutral/warm/cool/mono)
  topology   room re-packing for `creative` mode only (fidelity mode keeps the
             input `layout_m` authoritative)

A pool is built with the existing solver, structurally invalid candidates are
filtered, exact duplicates are removed, and a farthest-point quality-diversity
step selects K candidates.  Every run writes a manifest with the pool, the
selection trace and the pairwise metric matrix; shortfall is reported rather
than filled with duplicates.

No model calls.  All sampling is seeded.
"""
from __future__ import annotations

import hashlib
import math
import random
from collections import Counter
from copy import deepcopy

from . import assembly, floorplan

STYLES = ["minimal", "balanced", "family", "wfh", "compact", "spacious"]
PLACEMENT_PROFILES = [
    "balanced", "rotate1", "rotate2", "rotate3",
    "mirror_ns", "mirror_ew", "reverse",
]
PALETTES = ["neutral", "warm", "cool", "mono", "earth", "vivid"]

# Optional programme deltas.  They add/remove *optional* pieces, keeping the
# input's observed/requested objects intact; this is a style operator, not a
# regenerated program.
STYLE_BIAS = {
    "minimal": 0.85, "balanced": 1.00, "family": 1.05,
    "wfh": 0.95, "compact": 0.80, "spacious": 1.15,
}


def _norm(s):
    return str(s or "").lower().replace("_", " ").strip()


def _room_type(ir, room):
    return room.get("room_type") or floorplan.infer_room_type(
        room.get("name_en"), room.get("name_cn"))


def _space(ir, rtype, largest=False):
    """First (or largest) room of a type, or None."""
    hits = [r for r in ir.get("rooms") or [] if _room_type(ir, r) == rtype]
    if not hits:
        return None
    if largest:
        return max(hits, key=lambda r: float((r.get("dims_m") or [0, 0])[0])
                   * float((r.get("dims_m") or [0, 0])[1]))
    return hits[0]


def _object_room(ir, obj):
    q = _norm(obj.get("room"))
    if not q:
        return None
    exact = [r for r in ir.get("rooms") or []
             if q in (_norm(r.get("name_cn")), _norm(r.get("name_en")))]
    if exact:
        return exact[0]
    best, best_len = None, 0
    for r in ir.get("rooms") or []:
        for key in ("name_cn", "name_en"):
            n = _norm(r.get(key))
            if n and (n in q or q in n) and len(n) > best_len:
                best, best_len = r, len(n)
    return best


def program_vector(ir):
    """Counter[(room_type, category)] = requested count."""
    out = Counter()
    for obj in ir.get("objects") or []:
        cat = obj.get("category")
        if not cat:
            continue
        room = _object_room(ir, obj)
        rtype = _room_type(ir, room) if room else "unknown"
        out[(rtype, cat)] += int(obj.get("count", 1) or 1)
    return out


def _add(ir, rtype, category, label, count, size, largest=False):
    room = _space(ir, rtype, largest=largest)
    if room is None:
        return False
    ir.setdefault("objects", []).append({
        "category": category,
        "label": f"{label} ({room.get('name_cn', '')})",
        "count": int(count),
        "room": room.get("name_en") or room.get("name_cn"),
        "size_est_m": list(size),
        "placement": "diversity: style programme",
        "confidence": 0.5,
    })
    return True


def apply_style(ir, style, rng=None):
    """Return a deep-copied IR with one optional programme style applied."""
    cand = deepcopy(ir)
    style = style if style in STYLES else "balanced"
    build = dict(cand.get("_build") or {})
    build["item_bias"] = STYLE_BIAS[style]
    build["program_style"] = style

    if style == "minimal":
        # Strip decorative / secondary categories; keep the functional core.
        cand["objects"] = [o for o in (cand.get("objects") or [])
                           if o.get("category") not in ("plant", "lamp", "bookshelf", "tv")]
        for o in cand.get("objects") or []:
            if o.get("category") == "chair":
                o["count"] = min(int(o.get("count", 1) or 1), 2)
    elif style == "family":
        _add(cand, "dining", "chair", "餐椅", 2, [0.45, 0.45, 0.9])
        _add(cand, "living", "chair", "单椅", 1, [0.7, 0.7, 0.8])
        _add(cand, "living", "plant", "盆栽", 1, [0.45, 0.45, 1.0])
        _add(cand, "living", "lamp", "落地灯", 1, [0.4, 0.4, 1.5])
        _add(cand, "bedroom", "cabinet", "床头柜", 1, [0.5, 0.4, 0.55])
        _add(cand, "bedroom", "lamp", "床头灯", 1, [0.35, 0.35, 0.5])
    elif style == "wfh":
        if _add(cand, "bedroom", "desk", "书桌", 1, [1.2, 0.6, 0.75], largest=True):
            _add(cand, "bedroom", "chair", "书桌椅", 1, [0.45, 0.45, 0.9], largest=True)
            _add(cand, "bedroom", "bookshelf", "书架", 1, [0.9, 0.35, 2.0], largest=True)
        _add(cand, "living", "bookshelf", "书架", 1, [0.9, 0.35, 2.0])
        _add(cand, "living", "desk", "工作桌", 1, [1.2, 0.6, 0.75])
    elif style == "spacious":
        _add(cand, "living", "plant", "盆栽", 2, [0.5, 0.5, 1.1])
        _add(cand, "living", "lamp", "落地灯", 2, [0.4, 0.4, 1.5])
        _add(cand, "living", "bookshelf", "书架", 1, [0.9, 0.35, 2.0])
        _add(cand, "dining", "chair", "餐椅", 2, [0.45, 0.45, 0.9])
    elif style == "compact":
        cand["objects"] = [o for o in (cand.get("objects") or [])
                           if o.get("category") not in ("plant", "bookshelf")]
        for o in cand.get("objects") or []:
            if o.get("category") == "chair":
                o["count"] = min(int(o.get("count", 1) or 1), 2)

    cand["_build"] = build
    cand["notes"] = (str(cand.get("notes") or "")
                     + f" Diversity programme style: {style}.").strip()
    return cand


def _layout_bounds(ir):
    layout = ir.get("layout_m") or {}
    rooms = ir.get("rooms") or []
    if not layout or not rooms:
        return None
    origins = {}
    for i, r in enumerate(rooms):
        o = (layout.get(str(i)) or layout.get(r.get("name_cn"))
             or layout.get(r.get("name_en")))
        if not (isinstance(o, (list, tuple)) and len(o) >= 2):
            return None
        origins[str(i)] = [float(o[0]), float(o[1])]
    bw = max(origins[str(i)][0] + float(r["dims_m"][0]) for i, r in enumerate(rooms))
    bd = max(origins[str(i)][1] + float(r["dims_m"][1]) for i, r in enumerate(rooms))
    return origins, round(bw, 2), round(bd, 2)


def _pack_layout(ir, rng, variant=0, trials=16):
    rooms = []
    for i, r in enumerate(ir.get("rooms") or []):
        rooms.append({"key": str(i), "name_cn": r.get("name_cn") or f"room{i}",
                      "name_en": r.get("name_en") or r.get("name_cn") or f"room {i}",
                      "room_type": _room_type(ir, r),
                      "dims_m": [float(r["dims_m"][0]), float(r["dims_m"][1])]})
    total = sum(r["dims_m"][0] * r["dims_m"][1] for r in rooms)
    widths = [math.sqrt(total) * k for k in (1.05, 1.2, 1.35, 1.5)]
    best = None
    for t in range(trials):
        order = rooms[:]
        rng.shuffle(order)
        origins, score, bw, bd = floorplan._shelf_pack(order, widths[(variant + t) % len(widths)])
        if best is None or score > best[0]:
            best = (score, origins, bw, bd)
    _, origins, bw, bd = best
    return {str(i): origins[str(i)] for i in range(len(rooms))}, round(bw, 2), round(bd, 2)


def _permute(pref, fn):
    return {cat: "".join(fn(ch) for ch in bands) for cat, bands in pref.items()}


def _shift(bands, k):
    k %= len(bands)
    return bands[k:] + bands[:k]


def wall_profile(name):
    """Return {category: band-string} or {} for the base preference table."""
    base = assembly.PREF
    if name == "rotate1":
        return {c: _shift(s, 1) for c, s in base.items()}
    if name == "rotate2":
        return {c: _shift(s, 2) for c, s in base.items()}
    if name == "rotate3":
        return {c: _shift(s, 3) for c, s in base.items()}
    if name == "mirror_ns":
        return _permute(base, lambda ch: {"N": "S", "S": "N"}.get(ch, ch))
    if name == "mirror_ew":
        return _permute(base, lambda ch: {"E": "W", "W": "E"}.get(ch, ch))
    if name == "reverse":
        return {c: s[::-1] for c, s in base.items()}
    return {}


def make_pool(ir, pool_size=24, seed=0, mode="fidelity", styles=None,
              profiles=None, palettes=None, reverse_bands=True):
    """Sample `pool_size` candidate IRs across the four layers.

    ``profiles`` / ``palettes`` default to the full layer; pass a single
    baseline value (``["balanced"]`` / ``["native"]``) and
    ``reverse_bands=False`` to ablate a layer.  ``"native"`` keeps the original
    furniture colours (the build skips recolouring).

    Returns [{candidate, ir, style, palette, wall_profile, band_start,
              topology_mode, svg, bbox_m}].  Fidelity mode preserves `layout_m`;
    creative mode re-packs rooms and reports against the same room set.
    """
    if pool_size < 1:
        raise ValueError("pool_size must be >= 1")
    bad_styles = [s for s in (styles or []) if s not in STYLES]
    if bad_styles:
        raise ValueError(f"unknown styles {bad_styles}")
    styles = [s for s in (styles or STYLES) if s in STYLES] or STYLES[:]
    profiles = PLACEMENT_PROFILES if profiles is None else (profiles or ["balanced"])
    palettes = PALETTES if palettes is None else (palettes or ["native"])
    bad_profiles = [p for p in profiles if p not in PLACEMENT_PROFILES]
    bad_palettes = [p for p in palettes if p not in PALETTES + ["native"]]
    if bad_profiles or bad_palettes:
        raise ValueError(f"unknown profiles {bad_profiles} or palettes {bad_palettes}")
    rng = random.Random(seed)
    base_bounds = _layout_bounds(ir)
    if not base_bounds:
        base_bounds = _pack_layout(ir, rng)
    fixed_layout, bw, bd = base_bounds

    out = []
    for i in range(pool_size):
        style = styles[i % len(styles)]
        cand = apply_style(ir, style)
        profile = profiles[i % len(profiles)]
        wall_prefs = wall_profile(profile)
        # Reverse 0-2 bands so items fill from the other end of the wall.
        bands = []
        if reverse_bands and i % 3 == 2:
            bands = ["S", "E"]
        elif reverse_bands and i % 5 == 4:
            bands = ["N"]
        palette = palettes[(i + seed) % len(palettes)]
        build_palette = "" if palette == "native" else palette

        if mode == "creative":
            layout, cw, cd = _pack_layout(cand, rng, variant=i)
            topology_mode = "creative"
        else:
            layout, cw, cd = fixed_layout, bw, bd
            topology_mode = "fixed"

        cand["layout_m"] = {k: list(v) for k, v in layout.items()}
        build = dict(cand.get("_build") or {})
        build.pop("pref_shift", None)
        build.update({
            "pref_shift": 0,
            "wall_prefs": wall_prefs,
            "band_start": bands,
            "palette": build_palette,
            "program_style": style,
            "diversity_mode": mode,
            "diversity_seed": seed,
            "diversity_pool_index": i,
        })
        cand["source"] = f"diversity:{ir.get('source', 'ir')}#pool{i}"
        cand["_build"] = build
        cand["notes"] = (str(cand.get("notes") or "")
                         + f" Diversity pool {i}: style {style}, placement {profile}, "
                           f"palette {palette}, topology {topology_mode}.").strip()
        out.append({
            "candidate": i,
            "ir": cand,
            "style": style,
            "palette": palette,
            "wall_profile": profile,
            "band_start": bands,
            "topology_mode": topology_mode,
            "bbox_m": [cw, cd],
            "svg": floorplan.plan_svg(cand, 1.0, cw, cd),
        })
    return out


# ----------------------------------------------------------------- metrics
def _norm_counts(c):
    total = float(sum(c.values()))
    return {k: v / total for k, v in c.items()} if total else {}


def js_divergence(c1, c2):
    """Jensen-Shannon divergence with log2, normalised to [0, 1]."""
    p, q = _norm_counts(c1), _norm_counts(c2)
    keys = set(p) | set(q)
    if not keys:
        return 0.0
    m = {k: 0.5 * (p.get(k, 0.0) + q.get(k, 0.0)) for k in keys}

    def h(d):
        return -sum(v * math.log2(v) for v in d.values() if v > 0)

    js = h(m) - 0.5 * (h(p) + h(q))
    return round(max(0.0, min(1.0, js)), 6)


def program_divergence(c1, c2):
    """Programme difference: 60% count JSD + 40% category-presence Jaccard."""
    counts = js_divergence(c1, c2)
    presence = 1.0 - jaccard(set(c1), set(c2))
    return round(0.6 * counts + 0.4 * presence, 6)


def palette_divergence(c1, c2):
    """Total-variation distance between furniture colour histograms."""
    p, q = _norm_counts(c1), _norm_counts(c2)
    return round(0.5 * sum(abs(p.get(k, 0.0) - q.get(k, 0.0)) for k in set(p) | set(q)), 6)


def jaccard(a, b):
    return len(a & b) / max(len(a | b), 1)


def placement_divergence(a, b):
    return round(1.0 - jaccard(a, b), 6)


def topology_divergence(a, b):
    return round(1.0 - jaccard(a, b), 6)


def distance(row_a, row_b, weights=None):
    w = weights or {"placement": 0.40, "program": 0.25, "palette": 0.20, "topology": 0.15}
    vals = {
        "placement": placement_divergence(row_a["signature"], row_b["signature"]),
        "program": program_divergence(row_a["program"], row_b["program"]),
        "palette": palette_divergence(row_a["palette_hist"], row_b["palette_hist"]),
        "topology": topology_divergence(row_a["topology"], row_b["topology"]),
    }
    total = sum(vals[k] * w[k] for k in w) / max(sum(w.values()), 1e-9)
    return round(total, 6), vals


def _dedup_key(row):
    return (
        frozenset(row["signature"]),
        tuple(sorted(row["program"].items())),
        tuple(sorted(row["palette_hist"].items())),
        tuple(sorted(row["topology"])),
    )


def _quality(row):
    req = max(int(row.get("requested") or 0), 1)
    cov = float(row.get("placed") or 0) / req
    penalty = 1.0 if not row.get("overlaps") and not row.get("wall_furniture_overlaps") else 0.55
    if row.get("gate") == "red":
        penalty = 0.0
    return round(cov * penalty, 6)


def quality(row):
    return _quality(row)


def _filter_dedup(rows):
    """Drop build errors/invalid rows, then keep one best row per exact descriptor."""
    dropped = []
    candidates = []
    for r in rows:
        if r.get("error"):
            dropped.append({"candidate": r["candidate"], "why": "build error",
                            "detail": r["error"]})
            continue
        if not r.get("valid"):
            dropped.append({"candidate": r["candidate"], "why": "invalid",
                            "detail": r.get("invalid_reason")})
            continue
        candidates.append(r)

    chosen = {}
    for r in candidates:
        key = _dedup_key(r)
        best = chosen.get(key)
        if best is None or (_quality(r), r["candidate"]) > (_quality(best), best["candidate"]):
            if best is not None:
                dropped.append({"candidate": best["candidate"], "why": "duplicate",
                                "duplicate_of": r["candidate"]})
            chosen[key] = r
        else:
            dropped.append({"candidate": r["candidate"], "why": "duplicate",
                            "duplicate_of": best["candidate"]})
    return list(chosen.values()), dropped


def qd_select(rows, k, weights=None):
    """Filter, deduplicate, then farthest-point select K.

    Returns (selected, trace, dropped).  `dropped` records every pool candidate
    that did not make the archive and why (invalid / duplicate / not selected).
    """
    if not isinstance(k, int) or k < 0:
        raise ValueError("k must be a non-negative integer")
    trace = []
    candidates, dropped = _filter_dedup(rows)
    if not candidates:
        return [], trace, dropped
    if k == 0:
        dropped.extend({"candidate": r["candidate"], "why": "not selected (QD)"}
                       for r in candidates)
        return [], trace, dropped

    # Stable tie-break independent of candidate type (string/UUID/int).
    def _sort_key(r):
        c = r["candidate"]
        return (0, c) if isinstance(c, (int, float)) else (1, str(c))

    rank = {r["candidate"]: i for i, r in enumerate(
        sorted(candidates, key=_sort_key))}
    candidates.sort(key=lambda r: (-_quality(r), _sort_key(r)))
    selected = [candidates[0]]
    selected_ids = {candidates[0]["candidate"]}
    trace.append({"candidate": selected[0]["candidate"], "step": 0,
                  "quality": _quality(selected[0]), "min_distance": None,
                  "reason": "best quality"})
    while len(selected) < k and len(selected) < len(candidates):
        remain = [r for r in candidates if r["candidate"] not in selected_ids]
        best = None
        for r in remain:
            ds = [distance(r, s, weights)[0] for s in selected]
            score = min(ds)
            key = (score, _quality(r), -rank[r["candidate"]])
            if best is None or key > best[0]:
                best = (key, r, ds)
        _, r, ds = best
        selected.append(r)
        selected_ids.add(r["candidate"])
        trace.append({"candidate": r["candidate"], "step": len(selected) - 1,
                      "quality": _quality(r), "min_distance": round(min(ds), 6),
                      "reason": "farthest point"})
    selected_ids = {r["candidate"] for r in selected}
    for r in candidates:
        if r["candidate"] not in selected_ids:
            dropped.append({"candidate": r["candidate"], "why": "not selected (QD)"})
    return selected, trace, dropped


def random_select(rows, k, seed=0):
    """Fair baseline: same valid/unique pool, uniformly random K (seeded).

    Returns the same (selected, trace, dropped) shape as `qd_select` so both
    selections can be scored with identical metrics.
    """
    candidates, dropped = _filter_dedup(rows)
    trace = []
    rng = random.Random(seed)
    rng.shuffle(candidates)
    selected = candidates[:k]
    for i, r in enumerate(selected):
        trace.append({"candidate": r["candidate"], "step": i, "quality": _quality(r),
                      "min_distance": None, "reason": "random baseline"})
    chosen = {r["candidate"] for r in selected}
    for r in candidates:
        if r["candidate"] not in chosen:
            dropped.append({"candidate": r["candidate"], "why": "not selected (random)"})
    return selected, trace, dropped


def descriptor(row):
    topo = hashlib.sha1(
        "|".join(sorted(f"{a}>{b}" for a, b in row["topology"])).encode("utf-8")
    ).hexdigest()[:8]
    return (row.get("style"), row.get("palette"), row.get("wall_profile"),
            topo, round(float(row.get("coverage_ratio") or 0), 1))


def effective_bins(rows):
    """exp(entropy) over descriptor bins; 1 means all candidates look alike."""
    if not rows:
        return 0.0
    counts = Counter(descriptor(r) for r in rows)
    n = float(sum(counts.values()))
    h = -sum((c / n) * math.log2(c / n) for c in counts.values())
    return round(2 ** h, 4)


def pairwise(rows, weights=None):
    """Pairwise metric matrix for selected rows (list of dicts)."""
    out = []
    for i, a in enumerate(rows):
        for b in rows[i + 1:]:
            d, vals = distance(a, b, weights)
            out.append({"a": a["name"], "b": b["name"], "distance": d, **vals})
    return out


def aggregate(rows, weights=None):
    pairs = pairwise(rows, weights)
    def stat(key):
        vals = [p[key] for p in pairs]
        return {"mean": round(sum(vals) / len(vals), 4) if vals else 0.0,
                "min": round(min(vals), 4) if vals else 0.0,
                "max": round(max(vals), 4) if vals else 0.0}
    return {
        "pairs": len(pairs),
        "pairwise": {
            "distance": stat("distance"),
            "placement": stat("placement"),
            "program": stat("program"),
            "palette": stat("palette"),
            "topology": stat("topology"),
        },
        "effective_bins": effective_bins(rows),
        "coverage_mean": round(sum(float(r.get("coverage_ratio") or 0) for r in rows)
                               / max(len(rows), 1), 4),
        "room_coverage_mean": round(sum(float(r.get("room_coverage") or 0) for r in rows)
                                    / max(len(rows), 1), 4),
        "rooms_targeted_mean": round(sum(float(r.get("rooms_targeted") or 0) for r in rows)
                                     / max(len(rows), 1), 4),
        "rooms_furnished_mean": round(sum(float(r.get("rooms_furnished") or 0) for r in rows)
                                      / max(len(rows), 1), 4),
        "matrix": pairs,
    }
