"""Professor point 1: generate multiple candidate models for side-by-side comparison.

Pipeline: floorplan.generate_candidates -> write IR -> deterministic assembly
(assembly.py) -> metrics table + SVG plan gallery + pairwise diversity.  No model
calls; the comparison is over geometry/coverage, not prose.
"""
from __future__ import annotations

import json
import subprocess
import sys
from collections import Counter
from copy import deepcopy
from datetime import datetime
from pathlib import Path

from . import diversity, floorplan

HERE = Path(__file__).resolve().parent
ASSEMBLY = HERE / "assembly.py"
FYP_EVALUATE = HERE.parent.parent / "fyp-pipeline" / "evaluate.py"


def build_ir(ir: dict, name: str, outroot: Path, library: Path) -> tuple[dict, Path, str]:
    ir_dir = outroot / "ir"
    ir_dir.mkdir(parents=True, exist_ok=True)
    ir_path = ir_dir / f"{name}.json"
    ir_path.write_text(json.dumps(ir, ensure_ascii=False, indent=2), encoding="utf-8")
    scene_root = outroot / "scenes"
    cmd = [sys.executable, str(ASSEMBLY), "--ir", str(ir_path), "--name", name,
           "--library", str(library), "--out", str(scene_root)]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8")
    if r.returncode != 0:
        raise RuntimeError(f"assembly failed for {name}:\n{r.stdout}\n{r.stderr}")
    pl_path = scene_root / name / f"{name}.placements.json"
    return json.loads(pl_path.read_text(encoding="utf-8")), pl_path, r.stdout


def signature(pl: dict) -> set:
    """Within-room placement signature (room-relative, plan-origin invariant)."""
    zones = {r["name_cn"]: r["zone_ldu"] for r in pl["rooms"]}
    out = set()
    for p in pl["placements"]:
        room = str(p["room"]).split("#")[0]
        z = zones.get(room)
        rel = (round(p["center_ldu"][0] - z[0], -1), round(p["center_ldu"][2] - z[1], -1)) if z else (None, None)
        out.add((room, p["library_id"], rel[0], rel[1]))
    return out


def topology(pl: dict) -> set:
    """Room adjacency set (rooms sharing a wall segment)."""
    zs = [(r["name_cn"], r["zone_ldu"]) for r in pl["rooms"]]
    adj = set()
    for i in range(len(zs)):
        for j in range(i + 1, len(zs)):
            a, b = zs[i], zs[j]
            ax0, az0, ax1, az1 = a[1]
            bx0, bz0, bx1, bz1 = b[1]
            x_touch = (abs(ax1 - bx0) < 1 or abs(bx1 - ax0) < 1) and min(az1, bz1) > max(az0, bz0)
            z_touch = (abs(az1 - bz0) < 1 or abs(bz1 - az0) < 1) and min(ax1, bx1) > max(ax0, bx0)
            if x_touch or z_touch:
                adj.add(tuple(sorted((a[0], b[0]))))
    return adj


def jaccard(a: set, b: set) -> float:
    return len(a & b) / max(len(a | b), 1)


def evaluate_scene(scene_dir: Path, attempts: int = 2) -> dict:
    """Run the existing M6 evaluator (validate + three views) on a built scene.
    Not parallel-safe: concurrent leocad renders can collide, so retry once."""
    scene_dir = Path(scene_dir).resolve()
    qc = scene_dir / "qc" / "evaluate.json"
    last = ""
    for _ in range(attempts):
        r = subprocess.run([sys.executable, str(FYP_EVALUATE), str(scene_dir)],
                           capture_output=True, text=True, encoding="utf-8", timeout=900)
        last = (r.stdout or "")[-500:] + (r.stderr or "")[-500:]
        if qc.exists():
            ev = json.loads(qc.read_text(encoding="utf-8"))
            return {"ok": bool(ev.get("validate_ok")), "validate_exit": ev.get("validate_exit"),
                    "epsilon": len(ev.get("validate_epsilon_ignored", [])),
                    "envelope": len(ev.get("validate_envelope_ignored", [])),
                    "renders": ev.get("renders", []), "coverage": ev.get("coverage")}
    return {"ok": False, "error": last}


def style_candidates(preset: str, n: int, seed: int = 0) -> list[dict]:
    """One floor plan, N furnishing styles (balanced / compact / spacious / minimal)."""
    base = floorplan.generate_candidates(preset, n=1, seed=seed)[0]
    knobs = [(0, 1.00), (1, 0.85), (2, 1.15), (3, 1.00)]
    out = []
    for i in range(n):
        shift, bias = knobs[i % len(knobs)]
        ir = deepcopy(base["ir"])
        ir["source"] = f"generated:{preset}#style{i}"
        ir["_build"] = {"pref_shift": shift, "item_bias": bias}
        if i % 4 == 3:  # minimal: drop decorative-only categories
            ir["objects"] = [o for o in ir["objects"]
                             if o["category"] not in ("plant", "lamp", "tv")]
            ir["notes"] += " Style: minimal (decorative categories removed)."
        else:
            ir["notes"] += f" Style: {('balanced', 'compact', 'spacious')[i % 4]}."
        out.append({**base, "candidate": i, "ir": ir,
                    "svg": floorplan.plan_svg(ir, base["score"], *base["bbox_m"])})
    return out


def _build_rows(cands: list[dict], name_fn, outroot: Path, library: str | Path,
                evaluate: bool) -> list[dict]:
    """Build every candidate, write plan SVG/PNG, collect metrics + diversity."""
    rows = []
    for c in cands:
        name = name_fn(c)
        pl, pl_path, _ = build_ir(c["ir"], name, outroot, Path(library))
        requested = pl["requested_count"]
        row = {
            "candidate": c["candidate"],
            "name": name,
            "plan_score": c.get("score"),
            "bbox_m": c.get("bbox_m"),
            "coverage_m2": c.get("coverage_m2"),
            "rooms": len(c["ir"]["rooms"]),
            "placed": pl["placed_count"],
            "requested": requested,
            "coverage": pl["coverage"],
            "parts": pl["parts_total"],
            "furniture_parts": pl.get("furniture_parts", pl["parts_total"]),
            "floor_parts": pl.get("floor_parts", 0),
            "wall_parts": pl.get("wall_parts", 0),
            "wall_furniture_overlaps": len(pl.get("wall_furniture_overlaps") or []),
            "overlaps": len(pl["cross_room_overlaps"]),
            "distinct_ids": len({p["library_id"] for p in pl["placements"]}),
            "dropped": len(pl["dropped"]),
            "placement_file": str(pl_path),
            "scene": str(pl_path.parent / f"{name}.mpd"),
            "signature": signature(pl),
            "topology": topology(pl),
        }
        if evaluate:
            ev = evaluate_scene(pl_path.parent)
            row["gate"] = "green" if ev.get("ok") else "red"
            row["renders"] = ev.get("renders", [])
            row["epsilon"] = ev.get("epsilon", 0)
            row["render_dir"] = str(pl_path.parent / "qc")
        (outroot / "plans").mkdir(exist_ok=True)
        svg_path = outroot / "plans" / f"{name}.svg"
        svg_path.write_text(c.get("svg") or floorplan.svg_from_zones(pl["rooms"], name),
                            encoding="utf-8")
        row["svg"] = str(svg_path)
        try:
            row["png"] = floorplan.plan_png(c["ir"], outroot / "plans" / f"{name}.png")
        except ModuleNotFoundError:
            # Pillow is optional; the SVG plan and every scene remain complete.
            row["png"] = None
        rows.append(row)

    for i, a in enumerate(rows):
        for b in rows[i + 1:]:
            a.setdefault("diversity", {})[b["name"]] = {
                "placement": round(1 - jaccard(a["signature"], b["signature"]), 3),
                "topology": round(1 - jaccard(a["topology"], b["topology"]), 3),
            }
    return rows


def run(preset: str, n: int, outroot: str | Path, library: str | Path,
        seed: int = 0, evaluate: bool = False, mode: str = "plan") -> dict:
    outroot = Path(outroot).resolve()
    outroot.mkdir(parents=True, exist_ok=True)
    cands = (style_candidates(preset, n=n, seed=seed) if mode == "style"
             else floorplan.generate_candidates(preset, n=n, seed=seed))
    prefix = "style" if mode == "style" else "cand"
    rows = _build_rows(cands, lambda c: f"{preset}_{prefix}{c['candidate']}",
                       outroot, library, evaluate)
    report = _write_report(preset, rows, outroot, seed, mode)
    return {"preset": preset, "mode": mode, "candidates": rows, "report": str(report)}


def run_ir(ir_path: str | Path, n: int, outroot: str | Path, library: str | Path,
           seed: int = 0, evaluate: bool = False, name: str | None = None) -> dict:
    """Real IR -> n alternative room topologies -> n built models (Prof1 + TA3).

    Unlike `run`, rooms/objects come from an existing IR (e.g. an image-read
    floor plan) and only the packing topology + wall preferences vary.  `name`
    overrides the output prefix (the single-entry wrapper uses the plan name,
    not the temporary briefed-IR filename).
    """
    outroot = Path(outroot).resolve()
    outroot.mkdir(parents=True, exist_ok=True)
    ir_path = Path(ir_path).resolve()
    ir = json.loads(ir_path.read_text(encoding="utf-8"))
    stem = name or ir_path.stem
    cands = floorplan.replan_ir(ir, n=n, seed=seed)
    rows = _build_rows(cands, lambda c: f"{stem}_plan{c['candidate']}",
                       outroot, library, evaluate)
    report = _write_report(stem, rows, outroot, seed, mode="replan")
    return {"preset": stem, "mode": "replan", "candidates": rows, "report": str(report)}


def _public_row(row: dict) -> dict:
    """JSON-safe view of a pool row (sets/Counters summarised, SVG omitted)."""
    out = {k: v for k, v in row.items()
           if k not in ("signature", "topology", "program", "palette_hist", "svg")}
    out["signature_size"] = len(row.get("signature") or ())
    out["topology_pairs"] = len(row.get("topology") or ())
    out["program"] = {"|".join(k): v for k, v in (row.get("program") or {}).items()}
    out["palette_hist"] = dict(row.get("palette_hist") or {})
    return out


def _write_diversity_report(stem: str, mode: str, pool: list[dict], selected: list[dict],
                            trace: list[dict], dropped: list[dict], outroot: Path,
                            seed: int, k: int, min_coverage: float,
                            selection: str = "qd") -> tuple[Path, Path]:
    agg = diversity.aggregate(selected)
    shortfall = max(0, k - len(selected))
    lines = [
        f"# Plan2Brick · diversity run — `{stem}`",
        "",
        f"- **Mode**: `{mode}` · **Selection**: `{selection}` · **Seed**: {seed} · "
        f"**Pool**: {len(pool)} · "
        f"**Requested K**: {k} · **Selected**: {len(selected)} · **Shortfall**: {shortfall}",
        f"- **Quality filter**: coverage ≥ {min_coverage:.0%}, 0 cross-room overlaps, "
        f"0 wall–furniture overlaps",
        f"- **Mean pairwise distance**: {agg['pairwise']['distance']['mean']:.3f} "
        f"(min {agg['pairwise']['distance']['min']:.3f}) · "
        f"**Effective descriptor bins**: {agg['effective_bins']:.2f}",
        "",
        "## Selected candidates",
        "",
        "| Candidate | Style | Palette | Wall profile | Coverage | Room cov. | Parts | "
        "Program div. (mean) | Palette div. (mean) | Gate |",
        "|---|---|---|---|---|---|---|---|---|---|",
    ]
    for r in selected:
        prow = [p for p in agg["matrix"] if r["name"] in (p["a"], p["b"])]
        pdiv = sum(p["program"] for p in prow) / len(prow) if prow else 0.0
        cdiv = sum(p["palette"] for p in prow) / len(prow) if prow else 0.0
        gate = r.get("gate", "not_evaluated")
        lines.append(
            f"| {r['name']} | {r['style']} | {r['palette']} | {r['wall_profile']} "
            f"| {r['coverage']} | {r.get('room_coverage', '—')} | {r['parts']} "
            f"| {pdiv:.3f} | {cdiv:.3f} | {gate} |")
    if shortfall:
        lines += ["", f"> **Shortfall**: only {len(selected)} qualified candidates; "
                      f"{shortfall} requested candidate(s) were not filled with duplicates."]

    lines += ["", "## Pairwise metrics (selected)", "",
              "| Pair | Distance | Placement | Program | Palette | Topology |",
              "|---|---|---|---|---|---|"]
    for p in agg["matrix"]:
        lines.append(f"| {p['a']} × {p['b']} | {p['distance']:.3f} | {p['placement']:.3f} "
                     f"| {p['program']:.3f} | {p['palette']:.3f} | {p['topology']:.3f} |")

    lines += ["", "## QD selection trace", "",
              "| Step | Pool candidate | Quality | Min distance | Reason |",
              "|---|---|---|---|---|"]
    for t in trace:
        md = "—" if t["min_distance"] is None else f"{t['min_distance']:.3f}"
        lines.append(f"| {t['step']} | div{t['candidate']:02d} | {t['quality']:.3f} "
                     f"| {md} | {t['reason']} |")

    reasons = Counter(d["why"] for d in dropped)
    lines += ["", "## Pool disposition", "",
              "| Outcome | Count |", "|---|---|"]
    for why, n in sorted(reasons.items(), key=lambda kv: (-kv[1], kv[0])):
        lines.append(f"| {why} | {n} |")
    if dropped:
        lines += ["", "Dropped candidates (first 20): " + "; ".join(
            f"div{d['candidate']:02d}: {d['why']}" for d in dropped[:20])]

    lines += ["", "## Artifacts", "",
              f"- Manifest: `{outroot / 'manifest.json'}`",
              f"- Gallery: `{outroot / 'index.html'}`",
              f"- Candidate scenes: `{outroot / 'scenes'}`", ""]
    md = outroot / "diversity.md"
    md.write_text("\n".join(lines), encoding="utf-8")

    cards = []
    for r in selected:
        svg = Path(r["svg"]).read_text(encoding="utf-8") if r.get("svg") else ""
        img = ""
        if r.get("renders"):
            rel = Path(r["render_dir"]).relative_to(outroot).as_posix() + "/home.png"
            img = f'<img src="{rel}" alt="home view" style="max-width:100%;border-radius:8px"/>'
        cards.append(
            f'<section><h2>{r["name"]}</h2><p>{r["style"]} · {r["palette"]} · '
            f'{r["wall_profile"]} · coverage {r["coverage"]} · {r["parts"]} parts · '
            f'gate {r.get("gate", "not evaluated")}</p>{svg}{img}</section>')
    html = ("<!doctype html><meta charset='utf-8'><title>Plan2Brick diversity</title>"
            "<style>body{font-family:Segoe UI,Arial;margin:24px;background:#f8fafc}"
            "section{background:#fff;border:1px solid #ddd;border-radius:10px;padding:16px;margin:16px 0}"
            "h1{font-size:20px}svg{max-width:100%;height:auto}img{margin-top:8px}</style>"
            f"<h1>Plan2Brick · {stem} · {mode} · {len(selected)}/{k} candidates "
            f"(pool {len(pool)}, seed {seed})</h1>" + "".join(cards))
    gallery = outroot / "index.html"
    gallery.write_text(html, encoding="utf-8")
    return md, gallery


def run_diversity(ir_path: str | Path, n: int, outroot: str | Path, library: str | Path,
                  seed: int = 0, mode: str = "fidelity", pool: int = 24,
                  styles: list[str] | None = None, evaluate: bool = False,
                  name: str | None = None, min_coverage: float = 0.5,
                  profiles: list[str] | None = None, palettes: list[str] | None = None,
                  reverse_bands: bool = True, selection: str = "qd") -> dict:
    """Four-layer pool + QD selection -> K diverse, valid candidates.

    Fidelity mode keeps the input `layout_m`; creative mode re-packs rooms.
    Pool candidates are built without rendering; only the selected K are
    rendered when `evaluate=True`.  Invalid candidates are reported, never
    silently replaced.  ``profiles`` / ``palettes`` / ``reverse_bands`` ablate
    the placement and palette layers; ``selection="random"`` is the fair
    baseline against QD (same pool and quality filter).
    """
    if mode not in ("fidelity", "creative"):
        raise ValueError("mode must be 'fidelity' or 'creative'")
    if selection not in ("qd", "random"):
        raise ValueError("selection must be 'qd' or 'random'")
    outroot = Path(outroot).resolve()
    outroot.mkdir(parents=True, exist_ok=True)
    ir_path = Path(ir_path).resolve()
    ir = json.loads(ir_path.read_text(encoding="utf-8"))
    stem = name or ir_path.stem
    cands = diversity.make_pool(ir, pool_size=pool, seed=seed, mode=mode, styles=styles,
                                profiles=profiles, palettes=palettes,
                                reverse_bands=reverse_bands)

    rows = []
    for c in cands:
        cname = f"{stem}_div{c['candidate']:02d}"
        try:
            pl, pl_path, _ = build_ir(c["ir"], cname, outroot, Path(library))
            requested = int(pl.get("requested_count") or 0)
            placed = int(pl.get("placed_count") or 0)
            cov = placed / requested if requested else 1.0
            room_names = {r["name_cn"] for r in pl.get("rooms") or []}
            targeted = set()
            for obj in c["ir"].get("objects") or []:
                room = diversity._object_room(c["ir"], obj)
                if room:
                    targeted.add(room.get("name_cn"))
            targeted &= room_names
            furnished = {str(p["room"]).split("#")[0] for p in pl.get("placements") or []}
            rooms_furnished = len(furnished & targeted)
            room_cov = rooms_furnished / len(targeted) if targeted else 1.0
            row = {
                "candidate": c["candidate"],
                "name": cname,
                "style": c["style"],
                "palette": c["palette"],
                "wall_profile": c["wall_profile"],
                "band_start": c["band_start"],
                "topology_mode": c["topology_mode"],
                "bbox_m": c["bbox_m"],
                "rooms": len(c["ir"]["rooms"]),
                "rooms_targeted": len(targeted),
                "rooms_furnished": rooms_furnished,
                "room_coverage": round(room_cov, 4),
                "placed": placed,
                "requested": requested,
                "coverage_ratio": round(cov, 4),
                "coverage": pl["coverage"],
                "parts": pl["parts_total"],
                "furniture_parts": pl.get("furniture_parts", pl["parts_total"]),
                "floor_parts": pl.get("floor_parts", 0),
                "wall_parts": pl.get("wall_parts", 0),
                "wall_furniture_overlaps": len(pl.get("wall_furniture_overlaps") or []),
                "overlaps": len(pl["cross_room_overlaps"]),
                "distinct_ids": len({p["library_id"] for p in pl["placements"]}),
                "dropped": len(pl["dropped"]),
                "placement_file": str(pl_path),
                "scene": str(pl_path.parent / f"{cname}.mpd"),
                "signature": signature(pl),
                "topology": topology(pl),
                "program": diversity.program_vector(c["ir"]),
                "palette_hist": Counter(pl.get("furniture_colors") or {}),
                "wall_bands": dict(Counter(p.get("wall_band") for p in pl["placements"])),
                "svg": None,
                "png": None,
                "gate": "not_evaluated",
            }
            row["quality"] = diversity.quality(row)
            reason = None
            if row["overlaps"]:
                reason = f'{row["overlaps"]} cross-room overlap(s)'
            elif row["wall_furniture_overlaps"]:
                reason = f'{row["wall_furniture_overlaps"]} wall-furniture overlap(s)'
            elif cov < min_coverage:
                reason = f"coverage {cov:.1%} < {min_coverage:.0%}"
            row["valid"] = reason is None
            row["invalid_reason"] = reason
        except Exception as exc:  # one bad candidate must not kill the pool
            row = {"candidate": c["candidate"], "name": cname, "style": c["style"],
                   "palette": c["palette"], "wall_profile": c["wall_profile"],
                   "error": f"{type(exc).__name__}: {exc}", "valid": False,
                   "gate": "error"}
        (outroot / "plans").mkdir(exist_ok=True)
        svg_path = outroot / "plans" / f"{cname}.svg"
        svg_path.write_text(c.get("svg") or "", encoding="utf-8")
        row["svg"] = str(svg_path)
        try:
            row["png"] = floorplan.plan_png(c["ir"], outroot / "plans" / f"{cname}.png")
        except ModuleNotFoundError:
            row["png"] = None
        rows.append(row)

    if selection == "random":
        selected, trace, dropped = diversity.random_select(rows, n, seed=seed + 1000)
    else:
        selected, trace, dropped = diversity.qd_select(rows, n)
    for r in selected:
        if evaluate:
            ev = evaluate_scene(Path(r["placement_file"]).parent)
            r["gate"] = "green" if ev.get("ok") else "red"
            r["renders"] = ev.get("renders", [])
            r["epsilon"] = ev.get("epsilon", 0)
            r["render_dir"] = str(Path(r["placement_file"]).parent / "qc")
            r["quality"] = diversity.quality(r)
        else:
            r["gate"] = "not_evaluated"
            r["renders"] = []

    report, gallery = _write_diversity_report(stem, mode, rows, selected, trace, dropped,
                                              outroot, seed, n, min_coverage, selection)
    manifest = {
        "tool": "Plan2Brick diversity v1",
        "protocol": "EVALUATION_PROTOCOL v1.0 (frozen 2026-11-03)",
        "created": datetime.now().isoformat(timespec="seconds"),
        "plan": {"path": str(ir_path), "name": stem, "source": ir.get("source")},
        "config": {"mode": mode, "selection": selection, "seed": seed, "pool": pool, "k": n,
                   "styles": styles or diversity.STYLES,
                   "profiles": profiles if profiles is not None else diversity.PLACEMENT_PROFILES,
                   "palettes": palettes if palettes is not None else diversity.PALETTES,
                   "reverse_bands": reverse_bands,
                   "min_coverage": min_coverage, "evaluate": evaluate,
                   "weights": {"placement": 0.40, "program": 0.25,
                               "palette": 0.20, "topology": 0.15}},
        "shortfall": max(0, n - len(selected)),
        "selected": [r["name"] for r in selected],
        "selection_trace": trace,
        "aggregate": diversity.aggregate(selected),
        "pool": [_public_row(r) for r in rows],
        "dropped": dropped,
        "artifacts": {"report": str(report), "gallery": str(gallery),
                      "scenes": str(outroot / "scenes")},
    }
    (outroot / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"plan": stem, "mode": mode, "pool": rows, "candidates": selected,
            "trace": trace, "dropped": dropped, "report": str(report),
            "gallery": str(gallery), "manifest": str(outroot / "manifest.json"),
            "shortfall": manifest["shortfall"], "aggregate": manifest["aggregate"]}


def compare_irs(ir_paths: list[str], outroot: str | Path, library: str | Path,
                evaluate: bool = False) -> dict:
    """Compare arbitrary scene IRs (e.g. existing A/B/C or R1-R3 floor plans)."""
    outroot = Path(outroot).resolve()
    outroot.mkdir(parents=True, exist_ok=True)
    (outroot / "plans").mkdir(exist_ok=True)
    rows = []
    for ir_path in ir_paths:
        ir_path = Path(ir_path).resolve()
        ir = json.loads(ir_path.read_text(encoding="utf-8"))
        name = ir_path.stem
        pl, pl_path, _ = build_ir(ir, name, outroot, Path(library))
        svg_path = outroot / "plans" / f"{name}.svg"
        svg_path.write_text(floorplan.svg_from_zones(pl["rooms"], name), encoding="utf-8")
        row = {
            "name": name, "coverage": pl["coverage"], "placed": pl["placed_count"],
            "requested": pl["requested_count"], "parts": pl["parts_total"],
            "furniture_parts": pl.get("furniture_parts", pl["parts_total"]),
            "floor_parts": pl.get("floor_parts", 0),
            "wall_parts": pl.get("wall_parts", 0),
            "wall_furniture_overlaps": len(pl.get("wall_furniture_overlaps") or []),
            "rooms": len(pl["rooms"]), "overlaps": len(pl["cross_room_overlaps"]),
            "dropped": len(pl["dropped"]), "scene": str(pl_path.parent / f"{name}.mpd"),
            "placement_file": str(pl_path), "svg": str(svg_path),
        }
        if evaluate:
            ev = evaluate_scene(pl_path.parent)
            row["gate"] = "green" if ev.get("ok") else "red"
            row["epsilon"] = ev.get("epsilon", 0)
            row["renders"] = ev.get("renders", [])
            row["render_dir"] = str(pl_path.parent / "qc")
        rows.append(row)

    lines = ["# lego-nova · floor-plan comparison", "",
             "| IR | 房间 | 覆盖 | 件数（含地板/墙） | 地板砖 | 墙砖 | 跨房重叠 | 丢弃 | 门 |",
             "|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        gate = r.get("gate", "—")
        if "epsilon" in r and r.get("gate") == "green":
            gate += f" (ε {r['epsilon']})"
        lines.append(f'| {r["name"]} | {r["rooms"]} | {r["coverage"]} | {r["parts"]} '
                     f'| {r.get("floor_parts", 0)} | {r.get("wall_parts", 0)} '
                     f'| {r["overlaps"]} | {r["dropped"]} | {gate} |')
    lines += ["", "## 产物", ""]
    for r in rows:
        lines.append(f'- {r["name"]}: [平面图]({Path(r["svg"]).name}) · 场景 `{r["scene"]}`')
    (outroot / "compare.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    cards = []
    for r in rows:
        svg = Path(r["svg"]).read_text(encoding="utf-8")
        img = ""
        if r.get("renders"):
            rel = Path(r["render_dir"]).relative_to(outroot).as_posix() + "/home.png"
            img = f'<img src="{rel}" style="max-width:100%;border-radius:8px"/>'
        cards.append(f'<section><h2>{r["name"]}</h2><p>{r["coverage"]} · {r["parts"]} parts '
                     f'({r.get("furniture_parts", r["parts"])} furniture + '
                     f'{r.get("floor_parts", 0)} floor + {r.get("wall_parts", 0)} wall) · '
                     f'gate {r.get("gate", "—")}</p>'
                     f'{svg}{img}</section>')
    html = ("<!doctype html><meta charset='utf-8'><title>lego-nova compare</title>"
            "<style>body{font-family:Segoe UI,Arial;margin:24px;background:#f8fafc}"
            "section{background:#fff;border:1px solid #ddd;border-radius:10px;padding:16px;margin:16px 0}"
            "h1{font-size:20px}svg{max-width:100%;height:auto}</style>"
            f"<h1>lego-nova · {len(rows)} floor plans</h1>" + "".join(cards))
    (outroot / "index.html").write_text(html, encoding="utf-8")
    return {"rows": rows, "report": str(outroot / "compare.md")}


def _write_report(preset: str, rows: list[dict], outroot: Path, seed: int,
                  mode: str = "plan") -> Path:
    lines = [f"# lego-nova · multi-model comparison — preset `{preset}` · mode `{mode}` (seed {seed})", "",
             "同一户型生成多个候选方案供用户比较（professor 第 1 点）。全部确定性、零 token。", "",
             "| 候选 | 平面评分 | 外接盒 m | 房间 | 覆盖 | 件数（含地板/墙） | 地板砖 | 墙砖 | 跨房重叠 | 不同库件 | 陈设多样性 | 拓扑多样性 | 门 |",
             "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        div = r.get("diversity", {})
        pd = " / ".join(f"{v['placement']:.2f}" for v in div.values()) or "—"
        td = " / ".join(f"{v['topology']:.2f}" for v in div.values()) or "—"
        gate = r.get("gate", "—")
        if "epsilon" in r and r["gate"] == "green":
            gate += f" (ε {r['epsilon']})"
        lines.append(f"| {r['name']} | {r['plan_score']:.3f} | {r['bbox_m'][0]:.1f}×{r['bbox_m'][1]:.1f} "
                     f"| {r['rooms']} | {r['coverage']} | {r['parts']} | {r.get('floor_parts', 0)} "
                     f"| {r.get('wall_parts', 0)} | {r['overlaps']} | {r['distinct_ids']} "
                     f"| {pd} | {td} | {gate} |")
    lines += ["", "## 产物", ""]
    for r in rows:
        lines.append(f"- {r['name']}: [平面图]({Path(r['svg']).name}) · 场景 `{r['scene']}` · "
                     f"placements `{r['placement_file']}`")
    lines += ["", "> 陈设多样性 = 1 - Jaccard(房间内相对落位签名)；拓扑多样性 = 1 - Jaccard(房间相邻对)。", ""]
    p = outroot / "compare.md"
    p.write_text("\n".join(lines), encoding="utf-8")

    # self-contained HTML gallery (SVG inline, no server needed)
    cards = []
    for r in rows:
        svg = Path(r["svg"]).read_text(encoding="utf-8")
        img = ""
        if r.get("renders"):
            rel = Path(r["render_dir"]).relative_to(outroot).as_posix() + "/home.png"
            img = f'<img src="{rel}" alt="home view" style="max-width:100%;border-radius:8px"/>'
        cards.append(f'<section><h2>{r["name"]}</h2><p>coverage {r["coverage"]} · '
                     f'{r["parts"]} parts ({r.get("furniture_parts", r["parts"])} furniture + '
                     f'{r.get("floor_parts", 0)} floor + {r.get("wall_parts", 0)} wall) · '
                     f'overlaps {r["overlaps"]} · gate {r.get("gate", "—")}</p>'
                     f'{svg}{img}</section>')
    html = ("<!doctype html><meta charset='utf-8'><title>lego-nova compare</title>"
            "<style>body{font-family:Segoe UI,Arial;margin:24px;background:#f8fafc}"
            "section{background:#fff;border:1px solid #ddd;border-radius:10px;padding:16px;margin:16px 0}"
            "h1{font-size:20px}svg{max-width:100%;height:auto}</style>"
            f"<h1>lego-nova · {preset} · mode {mode} · {len(rows)} candidates</h1>" + "".join(cards))
    (outroot / "index.html").write_text(html, encoding="utf-8")
    return p
