"""Generate a compact room programme + layout from a requested room count.

The generated plan is deliberately simple and deterministic:

* a central corridor (1.4 m deep) with rooms on both sides;
* every room touches the corridor, so the existing wall/door builder puts a
  door on every room-corridor edge;
* room widths/depths are chosen to keep the aspect ratio of habitable rooms
  within ``MAX_ASPECT`` (the corridor itself is exempt);
* no room is narrower than ``MIN_SIDE_M``.

Call ``make_plan(n)`` to get a scene-IR dict (rooms + layout_m + objects).
"""
from __future__ import annotations

from . import floorplan

MAX_ASPECT = 2.0
MIN_SIDE_M = 2.2
CORRIDOR_DEPTH = 1.4

# area in m^2 for a typical room; names are assigned in order
AREA = {
    "living": 20.0,
    "bedroom": 12.0,
    "kitchen": 7.0,
    "bathroom": 5.0,
    "study": 9.0,
    "dining": 10.0,
}

PROGRAMS = {
    1: ["living"],
    2: ["living", "bedroom"],
    3: ["living", "bedroom", "kitchen"],
    4: ["living", "bedroom", "kitchen", "bathroom"],
    5: ["living", "bedroom", "bedroom", "kitchen", "bathroom"],
    6: ["living", "bedroom", "bedroom", "kitchen", "bathroom", "study"],
    7: ["living", "bedroom", "bedroom", "bedroom", "kitchen", "bathroom", "study"],
    8: ["living", "bedroom", "bedroom", "bedroom", "kitchen", "bathroom", "bathroom", "study"],
    9: ["living", "bedroom", "bedroom", "bedroom", "bedroom", "kitchen", "bathroom", "bathroom", "study"],
    10: ["living", "bedroom", "bedroom", "bedroom", "bedroom", "kitchen", "bathroom", "bathroom", "study", "dining"],
}


def _names(types: list[str]) -> list[str]:
    counters = {"bedroom": 0, "bathroom": 0}
    out = []
    for t in types:
        if t == "bedroom":
            counters["bedroom"] += 1
            out.append("主卧" if counters["bedroom"] == 1 and types.count("bedroom") > 1 else
                       (f"次卧{counters['bedroom']}" if types.count("bedroom") > 1 else "卧室"))
        elif t == "bathroom":
            counters["bathroom"] += 1
            out.append("卫生间" if types.count("bathroom") == 1 else f"卫生间{counters['bathroom']}")
        elif t == "living":
            out.append("客厅")
        elif t == "kitchen":
            out.append("厨房")
        elif t == "study":
            out.append("书房")
        elif t == "dining":
            out.append("餐厅")
        else:
            out.append(t)
    return out


def _assign(types: list[str]) -> tuple[list[int], list[int]]:
    """Greedy balance room areas across the two sides of the corridor."""
    order = sorted(range(len(types)), key=lambda i: -AREA[types[i]])
    top, bottom = [], []
    ta = ba = 0.0
    for i in order:
        a = AREA[types[i]]
        if ta <= ba:
            top.append(i); ta += a
        else:
            bottom.append(i); ba += a
    return sorted(top), sorted(bottom)


def _try_width(types: list[str], top: list[int], bottom: list[int], width: float):
    sides = []
    for ids in (top, bottom):
        if not ids:
            sides.append((0.0, []))
            continue
        area = sum(AREA[types[i]] for i in ids)
        depth = area / width
        if depth < 2.2 or depth > 7.5:
            return None
        rows = []
        for i in ids:
            w = AREA[types[i]] / depth
            aspect = max(depth / w, w / depth)
            if w < MIN_SIDE_M or aspect > MAX_ASPECT:
                return None
            rows.append((i, w, depth))
        sides.append((depth, rows))
    d_top = sides[0][0]
    d_bottom = sides[1][0]
    total_depth = d_top + CORRIDOR_DEPTH + d_bottom
    if total_depth <= 0:
        return None
    ratio = width / total_depth
    # prefer a footprint roughly 1.0-1.8 wide; penalise extremes
    penalty = 0.0 if 0.9 <= ratio <= 2.0 else abs(ratio - 1.35) * 2.0
    return penalty, d_top, d_bottom, sides


def _aspect(rect: tuple[float, float, float, float]) -> float:
    w, d = rect[2] - rect[0], rect[3] - rect[1]
    if w <= 0 or d <= 0:
        return 99.0
    return max(w / d, d / w)


def _tree_layout(indices: list[int], rect: tuple[float, float, float, float],
                 types: list[str], area: dict[int, float]):
    """Recursive guillotine treemap; returns {index: rect} or None."""
    if len(indices) == 1:
        return {indices[0]: rect}
    x0, z0, x1, z1 = rect
    total = sum(area[i] for i in indices)
    best = None
    n = len(indices)
    # All non-empty proper subsets; skip duplicates by fixing the first item
    # in group A (the split is symmetric).
    first = indices[0]
    for mask in range(0, 1 << (n - 1)):
        a = [indices[0]] + [indices[i] for i in range(1, n) if mask & (1 << (i - 1))]
        if len(a) == n:
            continue
        b = [i for i in indices if i not in a]
        aa = sum(area[i] for i in a)
        bb = total - aa
        if aa <= 0 or bb <= 0:
            continue
        for axis in ("v", "h"):
            if axis == "v":
                xm = x0 + (x1 - x0) * aa / total
                ra, rb = (x0, z0, xm, z1), (xm, z0, x1, z1)
            else:
                zm = z0 + (z1 - z0) * aa / total
                ra, rb = (x0, z0, x1, zm), (x0, zm, x1, z1)
            la = _tree_layout(a, ra, types, area)
            lb = _tree_layout(b, rb, types, area)
            if la is None or lb is None:
                continue
            leaves = {**la, **lb}
            ars = []
            for i, r in leaves.items():
                ar = _aspect(r)
                if types[i] != "hallway":
                    ars.append(ar)
            if not ars:
                score = 0.0
            else:
                score = max(ars) * 100.0 + sum(ars)
                for i, r in leaves.items():
                    if types[i] == "hallway":
                        continue
                    ar = _aspect(r)
                    score += max(0.0, ar - MAX_ASPECT) * 50.0
                    if min(r[2] - r[0], r[3] - r[1]) < MIN_SIDE_M:
                        score += 10.0
            if best is None or score < best[0]:
                best = (score, leaves)
    return None if best is None else best[1]


def _treemap_plan(types: list[str], names: list[str], style: str) -> dict:
    total = sum(AREA[t] for t in types)
    best = None
    for ratio in (1.0, 1.15, 1.3, 1.5, 1.7, 1.9):
        w = (total * ratio) ** 0.5
        h = total / w
        rect = (0.0, 0.0, round(w, 3), round(h, 3))
        leaves = _tree_layout(list(range(len(types))), rect, types,
                              {i: AREA[t] for i, t in enumerate(types)})
        if leaves is None:
            continue
        score = 0.0
        ars = []
        for i, r in leaves.items():
            ar = _aspect(r)
            if types[i] != "hallway":
                ars.append(ar)
                score += max(0.0, ar - MAX_ASPECT) * 50.0
                if min(r[2] - r[0], r[3] - r[1]) < MIN_SIDE_M:
                    score += 10.0
        if ars:
            score += max(ars) * 100.0 + sum(ars)
        if best is None or score < best[0]:
            best = (score, leaves)
    if best is None:
        raise ValueError("could not generate a compact layout")
    leaves = best[1]
    rooms, origins = [], {}
    for i, t in enumerate(types):
        x0, z0, x1, z1 = leaves[i]
        rooms.append({"name_cn": names[i], "name_en": t, "room_type": t,
                      "dims_m": [round(x1 - x0, 2), round(z1 - z0, 2)]})
        origins[names[i]] = [round(x0, 2), round(z0, 2)]
    return floorplan.make_ir(rooms, origins, f"generated:rooms={len(types)}:{style}")


def make_plan(n: int, style: str = "balanced") -> dict:
    """Return a scene IR for ``n`` habitable rooms (plus central corridor)."""
    n = int(n)
    if n < 1 or n > 10:
        raise ValueError("room count must be 1-10")
    types = PROGRAMS[n]
    names = _names(types)
    if n == 1:
        w, d = 5.2, 4.2
        rooms = [{"name_cn": names[0], "name_en": types[0], "room_type": types[0],
                  "dims_m": [w, d]}]
        origins = {names[0]: [0.0, 0.0]}
        return floorplan.make_ir(rooms, origins, f"generated:rooms={n}:{style}")

    if n <= 4:
        return _treemap_plan(types, names, style)

    top, bottom = _assign(types)
    best = None
    w = 7.0
    while w <= 30.0:
        got = _try_width(types, top, bottom, w)
        if got is not None:
            penalty, d_top, d_bottom, sides = got
            if best is None or penalty < best[0]:
                best = (penalty, w, d_top, d_bottom, sides)
        w = round(w + 0.2, 3)
    if best is None:
        # last-resort: equal-width rows; still deterministic and connected
        width = max(9.0, sum(AREA[t] for t in types) / 5.0)
        top_depth = max(AREA[types[i]] / (width / max(1, len(top))) for i in top) if top else 2.6
        bottom_depth = max(AREA[types[i]] / (width / max(1, len(bottom))) for i in bottom) if bottom else 2.6
        d_top, d_bottom = top_depth, bottom_depth
        sides = [(d_top, [(i, width / max(1, len(top)), d_top) for i in top]),
                 (d_bottom, [(i, width / max(1, len(bottom)), d_bottom) for i in bottom])]
        best = (0.0, width, d_top, d_bottom, sides)
    _penalty, width, d_top, d_bottom, sides = best

    rooms = []
    origins = {}
    # top row
    x = 0.0
    for i, rw, _d in sides[0][1]:
        name = names[i]
        rooms.append({"name_cn": name, "name_en": types[i], "room_type": types[i],
                      "dims_m": [round(rw, 2), round(d_top, 2)]})
        origins[name] = [round(x, 2), 0.0]
        x += rw
    # central corridor
    hall_name = "过道"
    rooms.append({"name_cn": hall_name, "name_en": "hallway", "room_type": "hallway",
                  "dims_m": [round(width, 2), CORRIDOR_DEPTH]})
    origins[hall_name] = [0.0, round(d_top, 2)]
    # bottom row
    x = 0.0
    z = round(d_top + CORRIDOR_DEPTH, 2)
    for i, rw, _d in sides[1][1]:
        name = names[i]
        rooms.append({"name_cn": name, "name_en": types[i], "room_type": types[i],
                      "dims_m": [round(rw, 2), round(d_bottom, 2)]})
        origins[name] = [round(x, 2), z]
        x += rw
    return floorplan.make_ir(rooms, origins, f"generated:rooms={n}:{style}")
