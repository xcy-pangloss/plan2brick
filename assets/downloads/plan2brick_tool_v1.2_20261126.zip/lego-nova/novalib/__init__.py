"""lego-nova: own-code rebuild of the FYP LEGO generation pipeline, floor-plan first."""

__version__ = "0.1.0"
