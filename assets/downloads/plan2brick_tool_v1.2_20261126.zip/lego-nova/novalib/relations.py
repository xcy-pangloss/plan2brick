"""Lightweight furniture-relation preferences for the deterministic placer.

The assembler still places every item on a wall band, but a few everyday
pairings should not be left to category order alone:

* a bedside cabinet / bedside lamp belongs on the same wall band as the bed;
* a wardrobe should leave the bed band free for those companions;
* a desk chair belongs on the desk's band;
* a TV cabinet should face the sofa (opposite wall band).

The helper only rewrites the per-category band preference for one object; it
never changes geometry, sizes or the library.  Missing anchors are a no-op, so
the frozen benchmark and IRs without these labels are unaffected.
"""
from __future__ import annotations

OPPOSITE = {"N": "S", "S": "N", "E": "W", "W": "E"}


def _band_of(placed: list[dict], category: str) -> str | None:
    for p in reversed(placed):
        if (p.get("item") or {}).get("category") == category:
            band = p.get("band")
            if band in OPPOSITE:
                return band
    return None


def _with_first(base: str, first: str | None) -> str:
    if not first:
        return base
    return first + "".join(ch for ch in base if ch != first)


def override(pref: dict[str, str], obj: dict, placed: list[dict]) -> dict[str, str]:
    """Return a copy of ``pref`` with a relation-aware band order for ``obj``.

    ``pref`` maps category -> band string (e.g. ``"bed": "NSWE"``).  The
    returned dict is safe to pass to ``assembly.try_place``.
    """
    cat = obj.get("category")
    label = str(obj.get("label") or "").lower()
    out = dict(pref)
    bed = _band_of(placed, "bed")
    sofa = _band_of(placed, "sofa")
    desk = _band_of(placed, "desk")

    if cat == "cabinet" and bed and ("床头柜" in label or "nightstand" in label):
        out[cat] = _with_first(pref.get(cat, "NSEW"), bed)
    elif cat == "cabinet" and bed and ("衣柜" in label or "wardrobe" in label):
        # Keep the bed wall free for the bedside pair; fall back to the full
        # order if the room is too narrow for another band.
        base = pref.get(cat, "NSEW")
        out[cat] = "".join(ch for ch in base if ch != bed) or base
    elif cat == "lamp" and bed and ("床头灯" in label or "night" in label):
        out[cat] = _with_first(pref.get(cat, "NSEW"), bed)
    elif cat == "chair" and desk and ("书桌椅" in label or "desk" in label):
        out[cat] = _with_first(pref.get(cat, "NSEW"), desk)
    elif cat == "tv" and sofa:
        out[cat] = _with_first(pref.get(cat, "NSEW"), OPPOSITE.get(sofa))
    return out
