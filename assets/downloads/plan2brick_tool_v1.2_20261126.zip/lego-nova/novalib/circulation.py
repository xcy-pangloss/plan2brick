"""Deterministic circulation / walkability analysis for Plan2Brick scenes.

The assembler places furniture on wall bands and reserves a short approach
zone on both sides of every door.  That is enough to keep a door itself clear,
but it does not prove that a person can walk from one door of a room to
another.  This module rasterises the room floor on the same 20-LDU (one stud)
grid as the wall generator and runs a four-neighbour BFS from the door
approach cells.

Outputs are deliberately simple and deterministic:

* ``connected``      every door in the room belongs to one BFS component
* ``walkable_ratio`` reachable free cells / all free cells
* ``free_cells``     free cells inside the room
* ``blocked_doors``  doors without a free approach cell within two studs

``repair`` removes low-priority furniture (plants, lamps, chairs, tables,
desks, cabinets, bookshelves, TVs) until every room is connected.  Beds,
sofas and wet fixtures are never removed by the circulation pass.  It is a
post-placement repair, so the frozen benchmark (no openings) is unaffected.
"""
from __future__ import annotations

import math
from collections import deque

LDU = 20
CELL_AREA = LDU * LDU
BLOCK_FRACTION = 0.25  # a cell is blocked when >=25% of it is covered
REMOVABLE = ["plant", "lamp", "chair", "table", "desk", "cabinet", "bookshelf", "tv"]
REMOVABLE_PRIORITY = {c: i for i, c in enumerate(REMOVABLE)}


def _cell_bounds(room: dict) -> tuple[int, int, int, int]:
    """Global cell index range (i0, j0, i1, j1), inclusive."""
    i0 = int(math.floor(room["x0"] / LDU + 1e-6))
    j0 = int(math.floor(room["z0"] / LDU + 1e-6))
    i1 = int(math.ceil(room["x1"] / LDU - 1e-6)) - 1
    j1 = int(math.ceil(room["z1"] / LDU - 1e-6)) - 1
    return i0, j0, max(i0, i1), max(j0, j1)


def _overlap_area(a: dict, b: dict) -> float:
    ox = min(a["x1"], b["x1"]) - max(a["x0"], b["x0"])
    oz = min(a["z1"], b["z1"]) - max(a["z0"], b["z0"])
    return max(0.0, ox) * max(0.0, oz)


def _blocked_cells(room: dict, placed: list[dict]) -> set[tuple[int, int]]:
    i0, j0, i1, j1 = _cell_bounds(room)
    blocked: set[tuple[int, int]] = set()
    for p in placed:
        if p.get("rid") != room.get("rid"):
            continue
        foot = p.get("foot") or {}
        if not all(k in foot for k in ("x0", "z0", "x1", "z1")):
            continue
        for i in range(i0, i1 + 1):
            for j in range(j0, j1 + 1):
                cell = {"x0": i * LDU, "z0": j * LDU, "x1": (i + 1) * LDU, "z1": (j + 1) * LDU}
                if _overlap_area(foot, cell) >= BLOCK_FRACTION * CELL_AREA:
                    blocked.add((i, j))
    return blocked


def _inside_cells(room: dict, op: dict, steps: int = 2) -> list[tuple[int, int]]:
    """Free cells just inside ``room`` for one door opening.

    ``op['cells']`` are global wall-grid cells.  For a horizontal wall the
    wall line is a row; for a vertical wall it is a column.  Try one stud
    inside, then up to ``steps`` studs, and keep every cell that lies inside
    the room.  The caller filters blocked cells.
    """
    out: list[tuple[int, int]] = []
    at = float(op.get("at", 0.0))
    axis = op.get("axis")
    if axis == "h":
        above = room["z1"] <= at + 2
        below = room["z0"] >= at - 2
        if not (above or below):
            return out
        wall_row = int(math.floor(at / LDU + 1e-6))
        for ci, _cj in op.get("cells") or []:
            for k in range(1, steps + 1):
                j = wall_row - k if above else wall_row + k
                if room["z0"] <= j * LDU < room["z1"]:
                    out.append((ci, j))
    elif axis == "v":
        left = room["x1"] <= at + 2
        right = room["x0"] >= at - 2
        if not (left or right):
            return out
        wall_col = int(math.floor(at / LDU + 1e-6))
        for _ci, cj in op.get("cells") or []:
            for k in range(1, steps + 1):
                i = wall_col - k if left else wall_col + k
                if room["x0"] <= i * LDU < room["x1"]:
                    out.append((i, cj))
    return out


def _door_entries(room: dict, openings: list[dict], blocked: set[tuple[int, int]]) -> tuple[list[tuple[int, int]], int]:
    """Return viable approach cells and the number of doors with none."""
    i0, j0, i1, j1 = _cell_bounds(room)
    entries: list[tuple[int, int]] = []
    blocked_doors = 0
    for op in openings:
        if op.get("kind") != "door" or room.get("rid") not in (op.get("rooms") or []):
            continue
        candidates = [c for c in _inside_cells(room, op)
                      if i0 <= c[0] <= i1 and j0 <= c[1] <= j1 and c not in blocked]
        if not candidates:
            blocked_doors += 1
            continue
        # Prefer the cell closest to the door centre; all candidates are one
        # or two studs inside, so this is just a deterministic tie-breaker.
        entries.extend(candidates)
    return entries, blocked_doors


def _bfs(free: set[tuple[int, int]], starts: list[tuple[int, int]]) -> set[tuple[int, int]]:
    seen = set(starts)
    q = deque(starts)
    while q:
        i, j = q.popleft()
        for ni, nj in ((i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1)):
            if (ni, nj) in free and (ni, nj) not in seen:
                seen.add((ni, nj))
                q.append((ni, nj))
    return seen


def analyze(rooms: list[dict], placed: list[dict], openings: list[dict]) -> dict:
    """Return per-room and scene-level circulation metrics.

    With no openings the result is a neutral pass: ``connected=True`` and
    ``walkable_ratio=1.0``, so callers can run this unconditionally.
    """
    doors = [op for op in openings if op.get("kind") == "door"]
    per_room: dict[int, dict] = {}
    if not doors:
        return {"rooms": {}, "connected": True, "walkable_ratio": 1.0, "door_count": 0}

    for room in rooms:
        rid = room["rid"]
        i0, j0, i1, j1 = _cell_bounds(room)
        blocked = _blocked_cells(room, placed)
        free = {(i, j) for i in range(i0, i1 + 1) for j in range(j0, j1 + 1)} - blocked
        entries, blocked_doors = _door_entries(room, doors, blocked)
        # Only keep entries that are actually free (defensive: a door zone
        # may be occupied by a legacy placement).
        entries = [c for c in entries if c in free]
        if not entries:
            connected = blocked_doors == 0
            per_room[rid] = {
                "door_count": sum(1 for op in doors if rid in (op.get("rooms") or [])),
                "blocked_doors": blocked_doors,
                "connected": connected,
                "free_cells": len(free),
                "reachable_cells": 0,
                "walkable_ratio": 0.0 if free else 1.0,
            }
            continue
        reachable = _bfs(free, [entries[0]])
        # A room is connected when every door with a free entry is reachable
        # from the first door.  Seeding BFS from every entry would hide
        # disconnection, because the union of two components still contains
        # all entry cells.
        connected = blocked_doors == 0 and all(e in reachable for e in entries)
        per_room[rid] = {
            "door_count": sum(1 for op in doors if rid in (op.get("rooms") or [])),
            "blocked_doors": blocked_doors,
            "connected": connected,
            "free_cells": len(free),
            "reachable_cells": len(reachable),
            "walkable_ratio": round(len(reachable) / len(free), 4) if free else 1.0,
        }

    room_vals = list(per_room.values())
    return {
        "rooms": per_room,
        "connected": all(r["connected"] for r in room_vals),
        "walkable_ratio": round(sum(r["walkable_ratio"] for r in room_vals) / len(room_vals), 4) if room_vals else 1.0,
        "door_count": len(doors),
    }


def repair(rooms: list[dict], placed: list[dict], openings: list[dict]) -> tuple[list[dict], list[dict], dict]:
    """Remove low-priority furniture until every room is connected.

    Returns ``(kept, removed, summary)``.  ``removed`` entries carry the same
    fields as the assembler's placement records plus ``why``.  The function
    never removes beds, sofas, toilets, baths, sinks, stoves, washers or
    fridges; if a path is still blocked the room remains disconnected and the
    summary records it.
    """
    kept = list(placed)
    removed: list[dict] = []
    summary = analyze(rooms, kept, openings)
    if not summary["rooms"] or summary["connected"]:
        return kept, removed, summary

    # Deterministic order: least disruptive category first, then later
    # placements first.  Recompute after every removal so the next candidate
    # is judged against the current geometry.
    while not summary["connected"]:
        bad_rooms = {rid for rid, r in summary["rooms"].items() if not r["connected"]}
        candidates = [p for p in kept
                      if p.get("rid") in bad_rooms
                      and (p.get("item") or {}).get("category") in REMOVABLE_PRIORITY]
        if not candidates:
            break
        candidates.sort(key=lambda p: (
            REMOVABLE_PRIORITY[(p.get("item") or {}).get("category", "")],
            -p.get("index", 0),
        ))
        victim = candidates[0]
        kept = [p for p in kept if p is not victim]
        rec = dict(victim)
        rec["why"] = "circulation: removed to keep doors connected"
        removed.append(rec)
        summary = analyze(rooms, kept, openings)
    return kept, removed, summary
