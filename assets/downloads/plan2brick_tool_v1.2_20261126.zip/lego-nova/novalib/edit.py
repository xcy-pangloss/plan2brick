"""Professor point 2: modify one part/object without touching the rest.

Works on a built scene (placements.json + composed MPD): the target object is
replaced / removed / nudged at its existing centre, and every other object is
re-emitted with its original centre and library body.  We then verify, against
the original MPD, that all lines belonging to unaffected objects are unchanged
(multiset match) — so "the rest did not move" is measured, not assumed.
"""
from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

from . import floors, walls
from .assembly import load_items


def _object_lines(item: dict, cx: float, cz: float) -> list[str]:
    ax, ay, az = item["anchor"]
    tx, ty, tz = ax + cx, ay, az + cz
    out = []
    for ln in item["parts"]:
        t = ln.split()
        x, y, z = float(t[2]) + tx, float(t[3]) + ty, float(t[4]) + tz
        out.append(" ".join([t[0], t[1], f"{x:.4f}", f"{y:.4f}", f"{z:.4f}", *t[5:]]))
    return out


def patch(scene_dir: str | Path, library: str | Path, no: int | None = None,
          room: str | None = None, label: str | None = None,
          new_library_id: str | None = None, remove: bool = False,
          dx: float = 0.0, dz: float = 0.0) -> dict:
    scene_dir = Path(scene_dir)
    # Prefer the base scene placement file; repeated edits write
    # ``*.edited.placements.json`` into the same directory and must not become
    # the source of a later edit (that silently changed the "unchanged" count).
    candidates = sorted(scene_dir.glob("*.placements.json"))
    base = [p for p in candidates if ".edited." not in p.name]
    if not base:
        base = candidates
    if not base:
        raise FileNotFoundError(f"no placements.json under {scene_dir}")
    if len(base) > 1:
        raise ValueError(f"multiple base placements under {scene_dir}: "
                         + ", ".join(p.name for p in base))
    pl_path = base[0]
    pl = json.loads(pl_path.read_text(encoding="utf-8"))
    mpd_path = scene_dir / pl["scene"]
    if not mpd_path.exists():
        mpd_path = next(scene_dir.glob("*.mpd"))
    original_lines = mpd_path.read_text(encoding="utf-8").splitlines()
    items = load_items(Path(library))

    targets = []
    for p in pl["placements"]:
        if no is not None and p["no"] != no:
            continue
        if room is not None and room not in str(p.get("room")):
            continue
        if label is not None and label not in str(p.get("ir_label")):
            continue
        targets.append(p)
    if not targets:
        raise ValueError("no target placement matched the selector")
    if len(targets) > 1:
        raise ValueError(f"selector matched {len(targets)} placements; narrow it (use --no)")

    tgt = targets[0]
    if new_library_id and new_library_id not in items:
        raise KeyError(f"library id not found: {new_library_id}")
    if remove and new_library_id:
        raise ValueError("choose either --remove or --library-id")

    new_placements, expected_unaffected = [], []
    for p in deepcopy(pl["placements"]):
        if p["no"] == tgt["no"] and remove:
            continue
        item = items[p["library_id"]]
        cx, cz = p["center_ldu"][0], p["center_ldu"][2]
        if p["no"] == tgt["no"]:
            if new_library_id:
                item = items[new_library_id]
                p["library_id"] = new_library_id
                p["category"] = item["category"]
            cx, cz = cx + dx, cz + dz
            p["center_ldu"] = [round(cx, 1), 0.0, round(cz, 1)]
        else:
            expected_unaffected.append((p, item, cx, cz))
        p["_lines"] = _object_lines(item, cx, cz)
        new_placements.append(p)

    # verify unaffected object lines exist unchanged in the original MPD
    orig_multiset = {}
    for ln in original_lines:
        orig_multiset[ln] = orig_multiset.get(ln, 0) + 1
    total = matched = 0
    for p, item, cx, cz in expected_unaffected:
        for ln in _object_lines(item, cx, cz):
            total += 1
            if orig_multiset.get(ln, 0) > 0:
                matched += 1
                orig_multiset[ln] -= 1

    # Preserve the LEGO floor and wall sections verbatim.  Floors and walls are
    # scene infrastructure, not part of the object-level edit; dropping them
    # would silently change the model.  Lines are copied from each marker up to
    # the next marker (or end of file).
    wall_section: list[str] = []
    marker_idx = next((i for i, ln in enumerate(original_lines)
                       if ln.strip() == walls.WALLS_MARKER), None)
    if marker_idx is not None:
        wall_section = [original_lines[marker_idx]]
        wall_section += [ln for ln in original_lines[marker_idx + 1:] if ln.startswith("1 ")]

    floor_section: list[str] = []
    floor_idx = next((i for i, ln in enumerate(original_lines)
                      if ln.strip() == floors.FLOOR_MARKER), None)
    if floor_idx is not None:
        floor_end = (marker_idx if marker_idx is not None and marker_idx > floor_idx
                     else len(original_lines))
        floor_section = [original_lines[floor_idx]]
        floor_section += [ln for ln in original_lines[floor_idx + 1:floor_end]
                          if ln.startswith("1 ")]

    out_name = mpd_path.stem + ".edited"
    header = [f"0 FILE {out_name}.ldr", f"0 lego-nova part-level edit of {mpd_path.name}",
              f"0 Name: {out_name}.ldr", "0 Author: lego-nova edit"]
    body = [ln for p in new_placements for ln in p.pop("_lines")]
    (scene_dir / f"{out_name}.mpd").write_text(
        "\n".join(header + body + floor_section + wall_section + ["0"]) + "\n",
        encoding="utf-8")

    pl_out = deepcopy(pl)
    pl_out["scene"] = f"{out_name}.mpd"
    pl_out["placements"] = new_placements
    pl_out["placed_count"] = len(new_placements)
    furniture_parts = sum(items[p["library_id"]]["part_count"] for p in new_placements)
    floor_records = pl_out.get("floors") or []
    wall_records = pl_out.get("walls") or []
    pl_out["furniture_parts"] = furniture_parts
    pl_out["floor_parts"] = len(floor_records)
    pl_out["wall_parts"] = len(wall_records)
    pl_out["parts_total"] = furniture_parts + len(floor_records) + len(wall_records)
    pl_out["wall_furniture_overlaps"] = walls.check_wall_furniture(wall_records, new_placements)
    pl_out["edit"] = {
        "target_no": tgt["no"], "target_room": tgt.get("room"), "target_label": tgt.get("ir_label"),
        "action": "remove" if remove else ("replace" if new_library_id else "move"),
        "new_library_id": new_library_id, "delta_ldu": [dx, 0, dz],
        "unchanged_objects": len(expected_unaffected),
        "unchanged_lines_verified": f"{matched}/{total}",
    }
    (scene_dir / f"{out_name}.placements.json").write_text(
        json.dumps(pl_out, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"scene": str(scene_dir / f"{out_name}.mpd"), "placements": pl_out["edit"],
            "parts_total": pl_out["parts_total"]}
