"""M1 object library: description retrieval + shape retrieval.

TA direction 1 (library + image analysis -> selection) and professor point 3
(retrieve parts of specific shapes).  Both retrievers return ranked items over
the same 42-item / 16-category BrickNet library used by fyp-pipeline v1.3.
If ``library/aliases.json`` is present, everyday synonyms (couch -> sofa,
washbasin -> sink, ...) add a fixed category boost to text retrieval, so words
missing from the BrickNet captions still route to the right category.

Shape units: studs by default (1 stud = 8 mm real part).  A footprint is stored
as [x, height, z] studs in the library; retrieval is orientation-invariant on
the footprint (long side vs short side), so a 12x8 part matches an 8x12 query.
"""
from __future__ import annotations

import json
import math
import re
from pathlib import Path

STUD_MM = 8.0


class Library:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        idx = json.loads((self.path / "index.json").read_text(encoding="utf-8"))
        self.items = []
        for it in idx:
            meta = json.loads((self.path / f"{it['id']}.meta.json").read_text(encoding="utf-8"))
            sx, sy, sz = meta["size_studs"]
            self.items.append({
                "id": it["id"],
                "category": it["category"],
                "file": it["file"],
                "size_studs": [sx, sy, sz],
                "L": max(sx, sz),
                "S": min(sx, sz),
                "H": sy,
                "aspect": max(sx, sz) / max(min(sx, sz), 0.2),
                "footprint_area": sx * sz,
                "part_count": meta.get("part_count", 0),
                "spec": meta.get("spec", ""),
                "captions": meta.get("captions", []),
                "score": meta.get("score"),
            })
        self.by_id = {it["id"]: it for it in self.items}
        self.aliases = self._load_aliases()

    def _load_aliases(self) -> dict[str, str]:
        """phrase -> category from <library>/aliases.json (optional, v1.3+)."""
        path = self.path / "aliases.json"
        if not path.exists():
            return {}
        data = json.loads(path.read_text(encoding="utf-8"))
        out = {}
        for cat, phrases in data.get("categories", {}).items():
            for phrase in phrases:
                norm = " ".join(re.findall(r"[a-z0-9]+", phrase.lower()))
                if norm:
                    out[norm] = cat
        return out

    # ---------------------------------------------------------------- text
    def search_text(self, query: str, category: str | None = None,
                    limit: int = 8) -> list[dict]:
        """Description-driven retrieval: token hits in id/spec/captions.
        This is the explicit, inspectable form of the selector's text side.
        A whole-word alias phrase (couch, washbasin, ...) adds a fixed boost to
        its mapped category; aliases live in the library, not in the caller."""
        toks = re.findall(r"[a-z0-9]+", (query or "").lower())
        if not toks:
            return []
        qnorm = " ".join(toks)
        padded = f" {qnorm} "
        alias_cats = {cat for phrase, cat in self.aliases.items()
                      if f" {phrase} " in padded}
        out = []
        for it in self.items:
            if category and it["category"] != category:
                continue
            hay = " ".join([it["id"], it["spec"], " ".join(it["captions"])]).lower()
            id_hay = f'{it["id"]} {it["spec"]}'.lower()
            score = 8.0 if it["category"] in alias_cats else 0.0
            for t in toks:
                if t in id_hay:
                    score += 3.0
                score += 0.5 * min(hay.count(t), 6)
            if score > 0:
                out.append({**it, "match": round(score, 2)})
        out.sort(key=lambda x: (-x["match"], x["id"]))
        return out[:limit]

    # --------------------------------------------------------------- shape
    def search_shape(self, length: float | None = None, short: float | None = None,
                     height: float | None = None, tol: float = 0.35,
                     category: str | None = None, limit: int = 8) -> list[dict]:
        """Shape-driven retrieval.  length/short/height are in studs.
        A provided dimension must be within `tol` relative error; ranking is the
        mean absolute log-ratio over the provided dimensions.  Footprint sides
        are matched order-free (long-to-long, short-to-short)."""
        targets = [v for v in (length, short, height) if v is not None]
        if not targets:
            return []
        out = []
        for it in self.items:
            if category and it["category"] != category:
                continue
            pairs = []
            if length is not None:
                pairs.append((it["L"], length))
            if short is not None:
                pairs.append((it["S"], short))
            if height is not None:
                pairs.append((it["H"], height))
            if any(abs(v - t) / max(t, 1e-6) > tol for v, t in pairs):
                continue
            err = sum(abs(math.log(max(v, 0.2) / max(t, 0.2))) for v, t in pairs) / len(pairs)
            out.append({**it, "shape_error": round(err, 4),
                        "dims_mm": [round(v * STUD_MM, 1) for v in it["size_studs"]]})
        out.sort(key=lambda x: (x["shape_error"], x["id"]))
        return out[:limit]

    def summary(self) -> dict:
        cats = {}
        for it in self.items:
            cats[it["category"]] = cats.get(it["category"], 0) + 1
        return {"items": len(self.items), "categories": cats}


def format_item(it: dict) -> str:
    dims = "x".join(f"{v:.1f}" for v in it["size_studs"])
    extra = f" match={it.get('match')}" if "match" in it else ""
    extra += f" shape_err={it.get('shape_error')}" if "shape_error" in it else ""
    return f'{it["id"]:<20} {it["category"]:<10} {dims:>16} studs  parts={it["part_count"]:<3}{extra}'
