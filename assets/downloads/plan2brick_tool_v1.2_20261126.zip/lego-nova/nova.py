"""lego-nova command line (own-code rebuild focused on floor-plan generation).

Commands map to the six required points:
  library --text / --shape   TA1 description retrieval + prof.3 shape retrieval
  gap                        TA2 model-gap harness (Run 7 replay + pending Astra)
  gen                        TA3 different plans -> different LEGO models
  gen --candidates N         prof.1 multiple models for comparison (+ HTML gallery)
  edit                       prof.2 part-level edit, other objects untouched
  generate                   Plan2Brick v1.0 single entry: plan/preset + brief -> N
                             candidates -> deterministic build -> optional gate
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from novalib import brief, diversity, floorplan, gap, variants  # noqa: E402
from novalib.edit import patch  # noqa: E402
from novalib.library import Library, format_item  # noqa: E402

DEFAULT_LIBRARY = ROOT.parent / "fyp-pipeline" / "library"
DEFAULT_IR_CACHE = ROOT.parent / "fyp-pipeline" / "examples"
DEFAULT_OUT = ROOT / "out"
ASSEMBLY = ROOT / "novalib" / "assembly.py"
FYP_CHECK = ROOT.parent / "fyp-pipeline" / "check_ir.py"


def cmd_library(a) -> int:
    lib = Library(a.library)
    if a.text:
        hits = lib.search_text(a.text, category=a.category, limit=a.limit)
        print(f"text query {a.text!r} -> {len(hits)} hits")
    elif a.shape:
        parts = [p for p in a.shape.lower().replace("×", "x").split("x") if p]
        vals = [float(p) for p in parts] + [None, None, None]
        hits = lib.search_shape(vals[0], vals[1], vals[2], tol=a.tol,
                                category=a.category, limit=a.limit)
        print(f"shape query {a.shape} studs (tol {a.tol}) -> {len(hits)} hits")
    else:
        s = lib.summary()
        print(json.dumps(s, ensure_ascii=False, indent=2))
        return 0
    for it in hits:
        print("  " + format_item(it))
    return 0


def cmd_plan(a) -> int:
    out = Path(a.out)
    (out / "ir").mkdir(parents=True, exist_ok=True)
    (out / "plans").mkdir(parents=True, exist_ok=True)
    cands = floorplan.generate_candidates(a.preset, n=a.candidates, seed=a.seed)
    lines = [f"# lego-nova · generated floor plans — `{a.preset}` (seed {a.seed})", "",
             "| 候选 | 平面评分 | 外接盒 m | 房间 | 面积 m² | 平面图 |", "|---|---|---|---|---|---|"]
    for c in cands:
        name = f"{a.preset}_plan{c['candidate']}"
        ir_path = out / "ir" / f"{name}.json"
        ir_path.write_text(json.dumps(c["ir"], ensure_ascii=False, indent=2), encoding="utf-8")
        (out / "plans" / f"{name}.svg").write_text(c["svg"], encoding="utf-8")
        try:
            png = floorplan.plan_png(c["ir"], out / "plans" / f"{name}.png")
        except ModuleNotFoundError:
            png = None
        plan_links = (f"[PNG]({Path(png).name}) / [SVG]({name}.svg)" if png
                      else f"[SVG]({name}.svg)")
        lines.append(f"| {name} | {c['score']:.3f} | {c['bbox_m'][0]:.1f}×{c['bbox_m'][1]:.1f} "
                     f"| {len(c['ir']['rooms'])} | {c['coverage_m2']:.1f} | "
                     f"{plan_links} |")
        print(f"{name}: score {c['score']:.3f} · {c['bbox_m'][0]:.1f}×{c['bbox_m'][1]:.1f} m · "
              f"{len(c['ir']['rooms'])} rooms")
    (out / "plans.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"-> {out / 'plans.md'}")
    return 0


def cmd_gen(a) -> int:
    out = Path(a.out)
    if a.ir:
        res = variants.run_ir(a.ir, a.candidates, out, a.library, seed=a.seed,
                              evaluate=a.evaluate)
    else:
        res = variants.run(a.preset or "1br", a.candidates, out, a.library, seed=a.seed,
                           evaluate=a.evaluate, mode=a.mode)
    for r in res["candidates"]:
        print(f'{r["name"]}: {r["coverage"]} · {r["parts"]} parts · '
              f'{r["rooms"]} rooms · overlaps {r["overlaps"]} · diversity '
              f'{r.get("diversity", {})}')
    print(f'-> {res["report"]}')
    print(f'-> {out / "index.html"}')
    return 0


def _resolve_plan(a) -> tuple[dict, dict]:
    """Resolve --plan to a scene IR + provenance.

    Accepted forms (one entry point, no hidden guesses):
      * a preset name (studio / 1br / 2br / 3br)
      * an existing scene-IR .json
      * a floor-plan image with a verified M2 IR in --ir-cache
        (``<stem>.json`` / ``<stem>_img_flash.json`` / ``<stem>_txt_flash.json``)
    """
    plan = str(a.plan)
    p = Path(plan)
    if p.suffix.lower() == ".json" and p.exists():
        return (json.loads(p.read_text(encoding="utf-8")),
                {"kind": "ir", "input": str(p.resolve()), "name": p.stem})
    if plan in floorplan.PRESETS:
        base = floorplan.generate_candidates(plan, n=1, seed=a.seed)[0]
        return base["ir"], {"kind": "preset", "input": plan, "name": plan}
    if p.exists():
        cache = Path(a.ir_cache)
        for stem in (p.stem, f"{p.stem}_img_flash", f"{p.stem}_txt_flash", f"{p.stem}_flash"):
            q = cache / f"{stem}.json"
            if q.exists():
                return (json.loads(q.read_text(encoding="utf-8")),
                        {"kind": "image-cached", "input": str(p.resolve()),
                         "ir": str(q.resolve()), "name": p.stem})
        raise SystemExit(
            f"no verified IR for image {p.name} in {cache}.\n"
            f"  Expected one of: {p.stem}.json, {p.stem}_img_flash.json, "
            f"{p.stem}_txt_flash.json.\n"
            "  The live image->IR vision call is an explicit M2 step; this command "
            "does not invent an IR when the cache is missing.")
    raise SystemExit(f"unknown --plan {plan!r}: not a preset, an existing IR, "
                     f"or an image with a verified IR in --ir-cache")


def cmd_generate(a) -> int:
    out = Path(a.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    ir, prov = _resolve_plan(a)
    patch_res = brief.apply_brief(ir, a.brief or "")
    # Single-entry generation is the product path: new scenes get real doors
    # and windows.  The frozen benchmark keeps its own build flags.
    patch_res["ir"].setdefault("_build", {}).setdefault("openings", True)

    ir_dir = out / "ir"
    ir_dir.mkdir(parents=True, exist_ok=True)
    base_path = ir_dir / f"{prov['name']}_briefed.json"
    base_path.write_text(json.dumps(patch_res["ir"], ensure_ascii=False, indent=2),
                         encoding="utf-8")

    check = subprocess.run([sys.executable, str(FYP_CHECK), str(base_path)],
                           capture_output=True, text=True, encoding="utf-8")
    if check.returncode != 0:
        print(check.stdout or "", end="")
        print(check.stderr or "", end="")
        print("generate: briefed IR failed check_ir.py; no scenes built.")
        return 1

    # Clean input drawing from the same layout the solver uses: room outlines,
    # names and areas only, no furniture.
    input_plan = floorplan.schematic_png(
        patch_res["ir"], out / "input_plan.png",
        title=f"{prov['name']} · input plan")

    if a.diversity != "off":
        styles = None if a.style == "mixed" else [a.style]
        res = variants.run_diversity(
            base_path, a.candidates, out, a.library, seed=a.seed,
            mode=a.diversity, pool=a.pool, styles=styles,
            evaluate=a.evaluate, name=prov["name"], min_coverage=a.min_coverage)
        lines = [
            f"# Plan2Brick · generate (diversity {a.diversity}) — `{prov['name']}`", "",
            f"- **Plan**: `{prov['input']}` ({prov['kind']})",
            f"- **Brief**: {a.brief or '(none)'}",
            f"- **Pool**: {a.pool} · **K**: {a.candidates} · **Seed**: {a.seed}",
            f"- **Selected**: {len(res['candidates'])} · **Shortfall**: {res['shortfall']}",
            f"- **Mean pairwise distance**: "
            f"{res['aggregate']['pairwise']['distance']['mean']:.3f} · "
            f"**Effective bins**: {res['aggregate']['effective_bins']:.2f}", "",
            f"- Diversity report: `{res['report']}`",
            f"- Gallery: `{res['gallery']}`",
            f"- Manifest: `{res['manifest']}`", ""]
        (out / "generate.md").write_text("\n".join(lines), encoding="utf-8")
        for r in res["candidates"]:
            print(f'{r["name"]}: {r["coverage"]} · {r["parts"]} parts · '
                  f'{r["style"]}/{r["palette"]} · overlaps {r["overlaps"]} · '
                  f'gate {r.get("gate", "—")}')
        print(f'diversity: pool {a.pool} -> {len(res["candidates"])} selected '
              f'(shortfall {res["shortfall"]})')
        print(f'-> {res["report"]}')
        print(f'-> {res["gallery"]}')
        return 0

    rows = res["candidates"]
    gates = [r.get("gate") for r in rows]
    gate = ("green" if all(g == "green" for g in gates) else "red") if a.evaluate else "not_evaluated"

    lines = [f"# Plan2Brick · generate v1.0 — `{prov['name']}`", "",
             f"- **Plan**: `{prov['input']}` ({prov['kind']})",
             f"- **Brief**: {a.brief or '(none)'}",
             f"- **Brief actions**: " + ("; ".join(
                 f"{x['action']} {x.get('room', '')}" for x in patch_res["actions"]) or "(none)"),
             f"- **Unmatched**: " + ("; ".join(patch_res["unmatched"]) or "(none)"),
             f"- **Candidates**: {len(rows)} · **Gate**: {gate}", ""]
    if prov["kind"] == "image-cached":
        lines += [f"> Input image resolved to its verified M2 IR `{prov['ir']}`; "
                  "the vision call is cached, not re-run in this command.", ""]
    lines += ["| Candidate | Rooms | Coverage | Parts (furniture + floor + walls) | "
              "Cross-room overlaps | Gate | ε |",
              "|---|---|---|---|---|---|---|"]
    for r in rows:
        g = r.get("gate", "—")
        eps = r.get("epsilon", "—") if g == "green" else "—"
        breakdown = (f"{r['parts']} ({r.get('furniture_parts', r['parts'])} + "
                     f"{r.get('floor_parts', 0)} + {r.get('wall_parts', 0)})")
        lines.append(f"| {r['name']} | {r['rooms']} | {r['coverage']} | {breakdown} "
                     f"| {r['overlaps']} | {g} | {eps} |")
    lines += ["", "## Artifacts", "",
              f"- Gallery: `{out / 'index.html'}`",
              f"- Candidate report: `{out / 'compare.md'}`",
              f"- Clean input plan: `{input_plan}`",
              f"- Briefed IR: `{base_path}`", ""]
    (out / "generate.md").write_text("\n".join(lines), encoding="utf-8")

    manifest = {
        "tool": "Plan2Brick v1.0 generate",
        "created": datetime.now().isoformat(timespec="seconds"),
        "plan": prov,
        "brief": a.brief,
        "brief_actions": patch_res["actions"],
        "brief_unmatched": patch_res["unmatched"],
        "briefed_ir": str(base_path),
        "input_plan": str(input_plan),
        "candidates": [{k: v for k, v in r.items() if k not in ("signature", "topology")}
                       for r in rows],
        "gate": gate,
    }
    (out / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2),
                                      encoding="utf-8")

    for r in rows:
        print(f'{r["name"]}: {r["coverage"]} · {r["parts"]} parts · {r["rooms"]} rooms · '
              f'overlaps {r["overlaps"]} · gate {r.get("gate", "—")}')
    print(f'brief: {len(patch_res["actions"])} action(s), '
          f'{len(patch_res["unmatched"])} unmatched')
    print(f'-> {out / "generate.md"}')
    print(f'-> {out / "index.html"}')
    return 0 if gate in ("green", "not_evaluated") else 1


def cmd_compare(a) -> int:
    out = Path(a.out)
    res = variants.compare_irs(a.ir, out, a.library, evaluate=a.evaluate)
    for r in res["rows"]:
        print(f'{r["name"]}: {r["coverage"]} · {r["parts"]} parts · {r["rooms"]} rooms · '
              f'overlaps {r["overlaps"]} · gate {r.get("gate", "—")}')
    print(f'-> {res["report"]}')
    print(f'-> {out / "index.html"}')
    return 0


def cmd_build(a) -> int:
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    cmd = [sys.executable, str(ASSEMBLY), "--ir", a.ir, "--name", a.name,
           "--library", str(a.library), "--out", str(out)]
    r = subprocess.run(cmd, text=True, encoding="utf-8")
    return r.returncode


def cmd_edit(a) -> int:
    res = patch(a.scene, a.library, no=a.no, room=a.room, label=a.label,
                new_library_id=a.library_id, remove=a.remove, dx=a.dx, dz=a.dz)
    e = res["placements"]
    print(f'edited {e["target_label"]} in {e["target_room"]} ({e["action"]})')
    print(f'others untouched: {e["unchanged_objects"]} objects, lines verified '
          f'{e["unchanged_lines_verified"]}')
    print(f'-> {res["scene"]} ({res["parts_total"]} parts)')
    if a.evaluate:
        # evaluate.py keys off the directory name; give the edited scene its own dir
        mpd = Path(res["scene"])
        stem = mpd.stem
        ev_dir = mpd.parent / stem
        ev_dir.mkdir(exist_ok=True)
        shutil.copy2(mpd, ev_dir / mpd.name)
        shutil.copy2(mpd.parent / f"{stem}.placements.json",
                     ev_dir / f"{stem}.placements.json")
        ev = variants.evaluate_scene(ev_dir)
        print(f'gate: {"green" if ev.get("ok") else "red"} · epsilon {ev.get("epsilon", 0)} '
              f'· renders {len(ev.get("renders", []))} · qc `{ev_dir / "qc"}`')
    return 0


def cmd_gap(a) -> int:
    if a.json:
        print(json.dumps({"cells": gap.rows(), "summary": gap.summary()},
                         ensure_ascii=False, indent=2))
    else:
        print(gap.markdown())
    return 0


def cmd_selftest(a) -> int:
    out = ROOT / "out" / "selftest"
    lib = Library(a.library)
    ok = []
    s = lib.summary()
    ok.append(("library", f'{s["items"]} items / {len(s["categories"])} categories', s["items"] >= 40))
    shape = lib.search_shape(12, 8, 3, tol=0.6, limit=5)
    ok.append(("shape retrieval", f"{len(shape)} hits for 12x8x3 studs", len(shape) > 0))

    res = variants.run("studio", 2, out, a.library, seed=1)
    rows = res["candidates"]
    ok.append(("multi-model", f'{len(rows)} candidates built', len(rows) == 2))
    ok.append(("coverage", " · ".join(r["coverage"] for r in rows),
               all(r["placed"] > 0 for r in rows)))
    ok.append(("no cross-room overlap", "0", all(r["overlaps"] == 0 for r in rows)))

    styles = variants.style_candidates("studio", 2, seed=1)
    ok.append(("style variants", f"{len(styles)} styles, same layout",
               len(styles) == 2
               and styles[0]["ir"]["layout_m"] == styles[1]["ir"]["layout_m"]))

    irs = [str((out / "ir" / f'studio_cand{r["candidate"]}.json').resolve()) for r in rows]
    cmp = variants.compare_irs(irs, out / "compare", a.library)
    ok.append(("IR comparison", f'{len(cmp["rows"])} plans',
               len(cmp["rows"]) == 2 and all(x["overlaps"] == 0 for x in cmp["rows"])))

    rv = variants.run_ir(irs[0], 2, out / "ir_variants", a.library)
    rrows = rv["candidates"]
    tops = {frozenset(r["topology"]) for r in rrows}
    source_ir = json.loads(Path(irs[0]).read_text(encoding="utf-8"))
    layout_fixed = bool(source_ir.get("layout_m"))
    ok.append(("IR replan variants",
               f'{len(rrows)} layouts, {len(tops)} topologies'
               + (" (input layout fixed)" if layout_fixed else ""),
               len(rrows) == 2
               and ((len(tops) == 1) if layout_fixed else (len(tops) > 1))
               and all(x["overlaps"] == 0 for x in rrows)))

    first = rows[0]
    pl = json.loads(Path(first["placement_file"]).read_text(encoding="utf-8"))
    tgt = pl["placements"][0]
    same_cat = [it for it in lib.items
                if it["category"] == tgt["category"] and it["id"] != tgt["library_id"]]
    if same_cat:
        edit = patch(Path(first["placement_file"]).parent, a.library,
                     no=tgt["no"], new_library_id=same_cat[0]["id"])
    else:
        edit = patch(Path(first["placement_file"]).parent, a.library, no=tgt["no"], dx=20)
    e = edit["placements"]
    expected_unchanged = sum(1 for p in pl["placements"] if p["no"] != tgt["no"])
    ok.append(("part-level edit", f'others {e["unchanged_objects"]}, '
                                  f'lines {e["unchanged_lines_verified"]}',
               e["unchanged_objects"] == expected_unchanged
               and e["unchanged_lines_verified"].split("/")[0] ==
               e["unchanged_lines_verified"].split("/")[1]))

    g = gap.summary()
    ok.append(("gap harness", "14 cells + pending Astra", len(gap.rows()) == 14))
    print("\n== lego-nova selftest ==")
    for name, detail, passed in ok:
        print(f'  [{"PASS" if passed else "FAIL"}] {name}: {detail}')
    return 0 if all(p for _, _, p in ok) else 1


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "ldraw":
        from lego_nova.ldraw.cli import main as ldraw_main
        return ldraw_main(argv[1:])
    ap = argparse.ArgumentParser(
        description="lego-nova (refactored FYP pipeline)",
        epilog="LDraw toolchain: python nova.py ldraw <command> ...",
    )
    ap.add_argument("--library", default=str(DEFAULT_LIBRARY))
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("library", help="text / shape retrieval")
    p.add_argument("--text")
    p.add_argument("--shape", help="LxSxH in studs, e.g. 12x8x3")
    p.add_argument("--category")
    p.add_argument("--tol", type=float, default=0.35)
    p.add_argument("--limit", type=int, default=8)
    p.set_defaults(func=cmd_library)

    p = sub.add_parser("plan", help="generate floor plans only (IR + SVG + PNG)")
    p.add_argument("--preset", default="1br", choices=sorted(floorplan.PRESETS))
    p.add_argument("--candidates", "-n", type=int, default=3)
    p.add_argument("--out", default=str(DEFAULT_OUT / "plans"))
    p.add_argument("--seed", type=int, default=0)
    p.set_defaults(func=cmd_plan)

    p = sub.add_parser("gen", help="generate + build multiple candidate models")
    p.add_argument("--preset", default=None, choices=sorted(floorplan.PRESETS))
    p.add_argument("--ir", help="existing scene IR; generate N alternative layout topologies "
                                "(real floor plan -> multiple models; ignores --mode)")
    p.add_argument("--candidates", "-n", type=int, default=3)
    p.add_argument("--out", default=str(DEFAULT_OUT / "compare"))
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--mode", choices=["plan", "style"], default="plan",
                   help="plan = different layouts; style = one layout, different furnishing")
    p.add_argument("--evaluate", action="store_true",
                   help="run fyp-pipeline evaluate.py (validate + three views) per candidate")
    p.set_defaults(func=cmd_gen)

    p = sub.add_parser("generate", help="Plan2Brick single entry: plan/preset + brief -> "
                                        "N candidates -> build -> optional gate")
    p.add_argument("--plan", required=True,
                   help="preset name, scene IR .json, or floor-plan image with a verified IR")
    p.add_argument("--brief", default="", help="short natural-language brief (add/remove/replace/"
                                               "use/style)")
    p.add_argument("--ir-cache", default=str(DEFAULT_IR_CACHE),
                   help="directory holding verified <stem>_img_flash.json IRs")
    p.add_argument("--candidates", "-n", type=int, default=3)
    p.add_argument("--out", default=str(DEFAULT_OUT / "plan2brick"))
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--diversity", choices=["off", "fidelity", "creative"], default="off",
                   help="four-layer pool + QD selection; fidelity keeps layout_m, "
                        "creative re-packs room topology")
    p.add_argument("--pool", type=int, default=24,
                   help="candidate pool before quality filtering / QD selection")
    p.add_argument("--style", choices=["mixed"] + diversity.STYLES, default="mixed",
                   help="programme style for the diversity pool")
    p.add_argument("--min-coverage", type=float, default=0.5,
                   help="quality filter for diversity candidates")
    p.add_argument("--evaluate", action="store_true",
                   help="validate + three-view render every selected candidate")
    p.set_defaults(func=cmd_generate)

    p = sub.add_parser("compare", help="compare arbitrary floor-plan IRs side by side")
    p.add_argument("--ir", nargs="+", required=True, help="one or more scene IR json files")
    p.add_argument("--out", default=str(DEFAULT_OUT / "compare_irs"))
    p.add_argument("--evaluate", action="store_true",
                   help="run fyp-pipeline evaluate.py (validate + three views) per scene")
    p.set_defaults(func=cmd_compare)

    p = sub.add_parser("build", help="build one scene IR")
    p.add_argument("--ir", required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--out", default=str(DEFAULT_OUT))
    p.set_defaults(func=cmd_build)

    p = sub.add_parser("edit", help="insert/replace/remove one object, keep the rest")
    p.add_argument("--scene", required=True, help="scene directory containing *.placements.json")
    p.add_argument("--no", type=int, help="placement number")
    p.add_argument("--room")
    p.add_argument("--label")
    p.add_argument("--library-id")
    p.add_argument("--remove", action="store_true")
    p.add_argument("--dx", type=float, default=0.0, help="nudge centre x, LDU")
    p.add_argument("--dz", type=float, default=0.0, help="nudge centre z, LDU")
    p.add_argument("--evaluate", action="store_true",
                   help="validate + render the edited scene via fyp-pipeline/evaluate.py")
    p.set_defaults(func=cmd_edit)

    p = sub.add_parser("gap", help="model-gap matrix (TA2)")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_gap)

    p = sub.add_parser("selftest", help="end-to-end smoke test")
    p.set_defaults(func=cmd_selftest)

    a = ap.parse_args(argv)
    return a.func(a)


if __name__ == "__main__":
    raise SystemExit(main())
