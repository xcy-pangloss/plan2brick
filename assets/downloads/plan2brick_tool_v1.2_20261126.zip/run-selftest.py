#!/usr/bin/env python3
"""Packaged Plan2Brick self-test (no network, no API keys).

Copy this file to the package root as ``run-selftest.py``.  It generates a
small three-room scene with the bundled library and checks the product
defaults: 10-course walls, one exterior door, closed-door clipping audit,
layout closure, full LDR/MPD/BOM artifacts and a cutaway preview.
"""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "lego-nova"))
sys.path.insert(0, str(ROOT / "lego-nova" / "app"))

import serve  # noqa: E402


def main() -> int:
    payload = {
        "rooms": [
            {"name_cn": "客厅", "room_type": "living", "dims_m": [4.0, 3.6]},
            {"name_cn": "卧室", "room_type": "bedroom", "dims_m": [3.6, 3.6]},
            {"name_cn": "卫生间", "room_type": "bathroom", "dims_m": [2.0, 1.8]},
        ],
        "brief": "",
        "mode": "fidelity",
        "k": 3,
        "style": "mixed",
        "palette": "mixed",
    }
    result = serve.run_generate(payload)
    try:
        candidates = result.get("candidates") or []
        assert len(candidates) == 3, f"expected 3 candidates, got {len(candidates)}"
        for cand in candidates:
            assert cand["wallCourses"] == 10, cand.get("wallCourses")
            assert cand["wallHeightM"] == 2.4, cand.get("wallHeightM")
            assert cand["exteriorDoors"] == 1, cand.get("exteriorDoors")
            assert cand["layoutQA"]["ok"] and cand["layoutQA"]["connected"]
            checks = cand["doorChecks"]
            assert checks["wall_cell_hits"] == 0, checks
            assert checks["furniture_zone_hits"] == 0, checks
            assert checks["door_height_m"] == 1.92, checks
            assert cand["previewParts"] > 0, cand.get("previewParts")
            for key in ("ldr", "preview", "mpd", "bom", "placements", "ir", "planSvg"):
                assert cand["urls"].get(key), f"missing {key}"
        print(json.dumps({
            "ok": True,
            "candidates": len(candidates),
            "wall_courses": candidates[0]["wallCourses"],
            "wall_height_m": candidates[0]["wallHeightM"],
            "exterior_doors": candidates[0]["exteriorDoors"],
            "door_wall_hits": candidates[0]["doorChecks"]["wall_cell_hits"],
            "door_furniture_hits": candidates[0]["doorChecks"]["furniture_zone_hits"],
            "layout": candidates[0]["layoutQA"],
            "preview_parts": candidates[0]["previewParts"],
        }, indent=2))
        return 0
    finally:
        shutil.rmtree(serve.WORKBENCH_OUT / result["job"], ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
