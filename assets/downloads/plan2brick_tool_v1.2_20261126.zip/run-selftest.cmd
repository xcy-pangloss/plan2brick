@echo off
python run-selftest.py
