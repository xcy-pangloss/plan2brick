@echo off
cd /d "%~dp0"
set "PY=python"
if exist "%~dp0.venv\Scripts\python.exe" set "PY=%~dp0.venv\Scripts\python.exe"
"%PY%" lego-nova\app\serve.py --port 8000 --quiet --open-workbench
pause
