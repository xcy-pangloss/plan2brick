"""Floor-plan generation for lego-nova (TA direction 3 / professor point 1).

Deterministic, zero-token generator: preset -> several candidate room layouts
(shelf packing with different room orders / target widths) -> scene IR with an
explicit `layout_m` topology and a standard furniture program per room type.
Each candidate also gets an SVG so humans can compare plans side by side.

The point is not photorealism: it makes "different floor plans -> different
LEGO models" a first-class, reproducible axis (the old pipeline always packed
rooms row-major, ignoring the plan topology; assembly.py [N1] now honours
`layout_m`).
"""
from __future__ import annotations

import math
import random

# room -> (furniture: category, label, count, size_est_m)
FURNISH = {
    "living": [
        ("sofa", "三人沙发", 1, [2.1, 0.9, 0.8]),
        ("table", "茶几", 1, [1.0, 0.55, 0.4]),
        ("tv", "电视柜", 1, [1.2, 0.4, 0.6]),
        ("lamp", "落地灯", 1, [0.4, 0.4, 1.5]),
        ("plant", "盆栽", 1, [0.5, 0.5, 1.1]),
    ],
    "dining": [
        ("table", "餐桌", 1, [1.2, 0.8, 0.75]),
        ("chair", "餐椅", 4, [0.45, 0.45, 0.9]),
    ],
    "bedroom": [
        ("bed", "双人床", 1, [2.0, 1.5, 0.5]),
        ("cabinet", "衣柜", 1, [1.8, 0.6, 2.0]),
        ("cabinet", "床头柜", 1, [0.5, 0.4, 0.55]),
        ("lamp", "床头灯", 1, [0.35, 0.35, 0.5]),
    ],
    "kitchen": [
        ("fridge", "冰箱", 1, [0.7, 0.7, 1.8]),
        ("stove", "灶台", 1, [1.5, 0.6, 0.9]),
        ("sink", "厨房水槽", 1, [0.6, 0.55, 0.9]),
        ("cabinet", "橱柜", 1, [1.2, 0.6, 0.9]),
    ],
    "bathroom": [
        ("toilet", "马桶", 1, [0.7, 0.4, 0.75]),
        ("sink", "洗手盆", 1, [0.6, 0.5, 0.85]),
        ("bath", "淋浴区", 1, [0.9, 0.9, 0.05]),
    ],
    "study": [
        ("desk", "书桌", 1, [1.2, 0.6, 0.75]),
        ("chair", "书桌椅", 1, [0.45, 0.45, 0.9]),
        ("bookshelf", "书架", 1, [0.9, 0.35, 2.0]),
    ],
    "hallway": [("cabinet", "鞋柜", 1, [1.0, 0.35, 1.0])],
    "balcony": [("washer", "洗衣机", 1, [0.6, 0.6, 0.85]),
                ("plant", "盆栽", 2, [0.35, 0.35, 0.8])],
    "empty": [],
}

# preset -> rooms: (name_cn, name_en, room_type, [w, d])
PRESETS = {
    "studio": [
        ("客厅", "living room", "living", [5.4, 4.2]),
        ("厨房", "kitchen", "kitchen", [2.4, 2.4]),
        ("卫生间", "bathroom", "bathroom", [2.0, 1.8]),
        ("过道", "hallway", "hallway", [2.4, 1.2]),
        ("阳台", "balcony", "balcony", [4.2, 1.2]),
    ],
    "1br": [
        ("卧室", "bedroom", "bedroom", [3.6, 3.6]),
        ("厨房", "kitchen", "kitchen", [2.4, 2.4]),
        ("卫生间", "bathroom", "bathroom", [2.4, 2.1]),
        ("过道", "hallway", "hallway", [4.8, 1.2]),
        ("客厅", "living room", "living", [6.0, 3.6]),
        ("阳台", "balcony", "balcony", [6.0, 1.2]),
    ],
    "2br": [
        ("主卧", "master bedroom", "bedroom", [3.9, 3.6]),
        ("次卧", "bedroom 2", "bedroom", [3.3, 3.0]),
        ("客厅", "living room", "living", [5.4, 3.6]),
        ("厨房", "kitchen", "kitchen", [2.4, 2.4]),
        ("卫生间", "bathroom", "bathroom", [2.1, 1.8]),
        ("过道", "hallway", "hallway", [4.5, 1.2]),
        ("阳台", "balcony", "balcony", [5.4, 1.2]),
    ],
    "3br": [
        ("主卧", "master bedroom", "bedroom", [4.2, 3.9]),
        ("次卧1", "bedroom 2", "bedroom", [3.6, 3.3]),
        ("次卧2", "bedroom 3", "bedroom", [3.0, 3.0]),
        ("客厅", "living room", "living", [6.6, 4.2]),
        ("餐厅", "dining room", "dining", [3.0, 3.0]),
        ("厨房", "kitchen", "kitchen", [2.7, 2.4]),
        ("卫生间", "bathroom", "bathroom", [2.4, 2.0]),
        ("过道", "hallway", "hallway", [5.1, 1.2]),
        ("阳台", "balcony", "balcony", [6.6, 1.2]),
    ],
}

GAP_M = 0.0  # rooms share walls in the shelf pack


WANTED_ADJ = {("hallway", "living"), ("hallway", "kitchen"), ("hallway", "bathroom"),
              ("living", "balcony"), ("living", "dining"), ("kitchen", "dining"),
              ("bedroom", "hallway")}


def _room_key(r):
    """Unique packing key: index string for existing-IR replans, name for presets."""
    return r.get("key") or r["name_cn"]


def _adjacency_stats(rooms, origins):
    """Desired adjacency hits + number of connected components (wall-sharing graph)."""
    n = len(rooms)
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    hits = 0
    for i in range(n):
        ax, az = origins[_room_key(rooms[i])]
        aw, ad = rooms[i]["dims_m"]
        for j in range(i + 1, n):
            bx, bz = origins[_room_key(rooms[j])]
            bw, bd = rooms[j]["dims_m"]
            x_touch = (abs(ax + aw - bx) < 1e-6 or abs(bx + bw - ax) < 1e-6) \
                and min(az + ad, bz + bd) > max(az, bz) + 1e-6
            z_touch = (abs(az + ad - bz) < 1e-6 or abs(bz + bd - az) < 1e-6) \
                and min(ax + aw, bx + bw) > max(ax, bx) + 1e-6
            if x_touch or z_touch:
                parent[find(i)] = find(j)
                if tuple(sorted((rooms[i]["room_type"], rooms[j]["room_type"]))) in WANTED_ADJ:
                    hits += 1
    comps = len({find(i) for i in range(n)})
    return hits, comps


def _shelf_pack(rooms, max_w):
    """Pack room rectangles left-to-right, wrap rows. Returns origins + score."""
    x = z = row_h = 0.0
    origins, bbox_w = {}, 0.0
    for r in rooms:
        w, d = r["dims_m"]
        if x > 0 and x + w > max_w + 1e-9:
            x, z, row_h = 0.0, z + row_h, 0.0
        origins[_room_key(r)] = [round(x, 3), round(z, 3)]
        bbox_w = max(bbox_w, x + w)
        x += w + GAP_M
        row_h = max(row_h, d)
    bbox_d = z + row_h
    total = sum(r["dims_m"][0] * r["dims_m"][1] for r in rooms)
    compactness = total / max(bbox_w * bbox_d, 1e-6)
    aspect = max(bbox_w / max(bbox_d, 1e-6), bbox_d / max(bbox_w, 1e-6))
    hits, comps = _adjacency_stats(rooms, origins)
    score = (compactness - 0.08 * math.log(aspect)
             + 0.03 * hits - 0.06 * (comps - 1))
    return origins, round(score, 4), round(bbox_w, 2), round(bbox_d, 2)


def make_ir(rooms: list[dict], origins: dict, source: str, ci: int = 0) -> dict:
    """Build a scene IR from an explicit room programme.

    ``rooms`` entries need name_cn, name_en, room_type and dims_m [w, d].  This
    is the shared constructor for preset plans and the local workbench's
    room editor (presets previously went through a private wrapper).
    """
    objects = []
    for r in rooms:
        rtype = r.get("room_type") or infer_room_type(r.get("name_en"), r.get("name_cn"))
        for cat, label, count, size in FURNISH.get(rtype, []):
            objects.append({
                "category": cat, "label": f"{label} ({r['name_cn']})", "count": count,
                "room": r["name_cn"], "size_est_m": size,
                "placement": "auto (standard furnishing program)", "confidence": 0.6,
            })
    return {
        "source": source,
        "image_type": "floorplan",
        "rooms": [{
            "name_cn": r["name_cn"],
            "name_en": r.get("name_en") or r["name_cn"],
            "room_type": r.get("room_type") or infer_room_type(r.get("name_en"), r.get("name_cn")),
            "dims_m": list(r["dims_m"]),
        } for r in rooms],
        "objects": objects,
        "layout_m": origins,
        "_build": {"pref_shift": ci % 4, "item_bias": round(1.0 + 0.06 * ((ci % 3) - 1), 3),
                   "openings": True, "door_clearance_ldu": 30},
        "uncertain": ["Generated plan: room dimensions from a preset catalogue; "
                      "topology is one deterministic packing candidate, not read from an image."],
        "notes": f"lego-nova generated {source}: {len(rooms)} rooms, "
                 f"{sum(len(FURNISH.get(r.get('room_type'), [])) for r in rooms)} object groups.",
    }


def _make_ir(preset: str, rooms: list[dict], origins: dict, ci: int) -> dict:
    return make_ir(rooms, origins, f"generated:{preset}#cand{ci}", ci)


def generate_candidates(preset: str, n: int = 3, seed: int = 0) -> list[dict]:
    """Return up to n diverse candidate plans (IR + SVG + packing stats)."""
    if preset not in PRESETS:
        raise KeyError(f"unknown preset {preset!r}; choose from {sorted(PRESETS)}")
    base = [{"name_cn": a, "name_en": b, "room_type": c, "dims_m": d}
            for a, b, c, d in PRESETS[preset]]
    total_area = sum(r["dims_m"][0] * r["dims_m"][1] for r in base)
    rng = random.Random(seed)
    trials = []
    widths = [math.sqrt(total_area) * k for k in (1.05, 1.2, 1.35, 1.5)]
    n_orders = max(24, n * 16)
    for t in range(n_orders):
        order = base[:]
        rng.shuffle(order)
        max_w = widths[t % len(widths)]
        origins, score, bw, bd = _shelf_pack(order, max_w)
        trials.append((score, order, origins, bw, bd))
    trials.sort(key=lambda x: -x[0])

    picked, seen = [], set()
    for score, order, origins, bw, bd in trials:
        sig = tuple((r["name_cn"], tuple(origins[r["name_cn"]])) for r in base)
        # diversity: require a different ordering of room types OR a different
        # aspect class, so candidates are visibly different plans
        type_sig = tuple(r["room_type"] for r in order)
        key = (type_sig, round(bw / max(bd, 1e-6), 1))
        if key in seen and len(picked) < n:
            continue
        seen.add(key)
        picked.append((score, order, origins, bw, bd))
        if len(picked) >= n:
            break
    # if diversity filter was too strict, top up with next best
    for cand in trials:
        if len(picked) >= n:
            break
        if not any(cand[1] is p[1] for p in picked):
            picked.append(cand)

    out = []
    for ci, (score, order, origins, bw, bd) in enumerate(picked):
        ir = _make_ir(preset, order, origins, ci)
        out.append({
            "candidate": ci,
            "preset": preset,
            "score": score,
            "bbox_m": [bw, bd],
            "coverage_m2": round(total_area, 2),
            "ir": ir,
            "svg": plan_svg(ir, score, bw, bd),
        })
    return out


ROOM_TYPE_HINTS = [
    ("balcony", ("balcony", "阳台")),
    ("bathroom", ("bathroom", "toilet", "卫生间", "浴室", "洗手间")),
    ("kitchen", ("kitchen", "厨房")),
    ("dining", ("dining", "餐厅", "饭厅")),
    ("living", ("living", "客厅")),
    ("bedroom", ("bedroom", "卧室")),
    ("study", ("study", "书房")),
    ("hallway", ("hallway", "corridor", "过道", "走廊", "玄关")),
    ("storage", ("storage", "储藏", "杂物")),
]


def infer_room_type(name_en="", name_cn=""):
    s = f"{name_en or ''} {name_cn or ''}".lower()
    for t, keys in ROOM_TYPE_HINTS:
        if any(k in s for k in keys):
            return t
    return "empty"


def replan_ir(ir: dict, n: int = 3, seed: int = 0) -> list[dict]:
    """Build up to n candidates from an existing IR.

    If the IR carries an explicit ``layout_m`` (a real floor plan, a preset, or
    a user-edited workbench plan), that layout is authoritative: every candidate
    keeps the same room positions and varies only the furnishing/wall-preference
    knobs.  This is what makes the rendered output correspond to the input plan.
    If there is no layout, the rooms are re-packed into alternative topologies
    (the original behaviour, useful for quickly exploring a bare room list).

    Rooms and objects stay exactly as given; candidates differ in furniture
    selection and wall-band preference, not in the plan itself.
    """
    rooms = []
    for i, r in enumerate(ir.get("rooms") or []):
        dims = r.get("dims_m") or [0, 0]
        if len(dims) < 2 or dims[0] <= 0 or dims[1] <= 0:
            raise ValueError(f"room {i} has invalid dims_m {dims!r}")
        rooms.append({
            "key": str(i),
            "name_cn": r.get("name_cn") or r.get("name_en") or f"room{i}",
            "name_en": r.get("name_en") or r.get("name_cn") or f"room {i}",
            # Explicit room_type (workbench editor, brief "use ... as ...") wins;
            # otherwise infer from the name as before.
            "room_type": r.get("room_type") or infer_room_type(r.get("name_en"), r.get("name_cn")),
            "dims_m": [float(dims[0]), float(dims[1])],
        })
    if not rooms:
        raise ValueError("IR has no rooms")

    total_area = sum(w * d for w, d in (r["dims_m"] for r in rooms))

    # Explicit layout: preserve it for every candidate.
    layout = ir.get("layout_m") or {}
    if layout:
        origins: dict[str, list[float]] = {}
        for i, r in enumerate(rooms):
            o = layout.get(str(i)) or layout.get(r["name_cn"]) or layout.get(r["name_en"])
            if not (isinstance(o, (list, tuple)) and len(o) >= 2):
                origins = {}
                break
            origins[str(i)] = [float(o[0]), float(o[1])]
        if origins:
            bw = max(origins[str(i)][0] + r["dims_m"][0] for i, r in enumerate(rooms))
            bd = max(origins[str(i)][1] + r["dims_m"][1] for i, r in enumerate(rooms))
            out = []
            for ci in range(n):
                cand_ir = dict(ir)
                cand_ir["rooms"] = [dict(r) for r in ir["rooms"]]
                cand_ir["objects"] = [dict(o) for o in (ir.get("objects") or [])]
                cand_ir["source"] = f"fixed:{ir.get('source', 'ir')}#cand{ci}"
                cand_ir["layout_m"] = {k: list(v) for k, v in origins.items()}
                build = {"pref_shift": ci % 4,
                         "item_bias": round(1.0 + 0.06 * ((ci % 3) - 1), 3)}
                build.update(ir.get("_build") or {})
                cand_ir["_build"] = build
                cand_ir["notes"] = (str(ir.get("notes") or "")
                                    + f" lego-nova candidate {ci}: input room layout preserved; "
                                      f"alternative furnishing and wall preferences.")
                out.append({
                    "candidate": ci,
                    "source": ir.get("source", "ir"),
                    "score": 1.0,
                    "bbox_m": [round(bw, 2), round(bd, 2)],
                    "coverage_m2": round(total_area, 2),
                    "ir": cand_ir,
                    "svg": plan_svg(cand_ir, 1.0, bw, bd),
                })
            return out
    # No explicit layout: fall back to re-packing the room rectangles.
    rng = random.Random(seed)
    widths = [math.sqrt(total_area) * k for k in (1.05, 1.2, 1.35, 1.5)]
    trials = []
    n_orders = max(24, n * 16)
    for t in range(n_orders):
        order = rooms[:]
        rng.shuffle(order)
        origins, score, bw, bd = _shelf_pack(order, widths[t % len(widths)])
        trials.append((score, order, origins, bw, bd))
    trials.sort(key=lambda x: -x[0])

    picked, seen = [], set()
    for trial in trials:
        _, order, _, bw, bd = trial
        key = (tuple(r["room_type"] for r in order), round(bw / max(bd, 1e-6), 1))
        if key in seen and len(picked) < n:
            continue
        seen.add(key)
        picked.append(trial)
        if len(picked) >= n:
            break
    for cand in trials:
        if len(picked) >= n:
            break
        if not any(cand[1] is p[1] for p in picked):
            picked.append(cand)

    out = []
    for ci, (score, order, origins, bw, bd) in enumerate(picked):
        cand_ir = dict(ir)
        cand_ir["rooms"] = [dict(r) for r in ir["rooms"]]
        cand_ir["objects"] = [dict(o) for o in (ir.get("objects") or [])]
        cand_ir["source"] = f"replanned:{ir.get('source', 'ir')}#cand{ci}"
        cand_ir["layout_m"] = {r["key"]: origins[r["key"]] for r in order}
        # Candidate defaults first; the IR's own knobs (brief "minimal" /
        # "compact" / "spacious", _build.walls) take precedence.
        build = {"pref_shift": ci % 4,
                 "item_bias": round(1.0 + 0.06 * ((ci % 3) - 1), 3)}
        build.update(ir.get("_build") or {})
        cand_ir["_build"] = build
        cand_ir["notes"] = (str(ir.get("notes") or "")
                            + f" lego-nova replanned candidate {ci}: same rooms/objects, "
                              f"alternative pack order and wall preferences.")
        out.append({
            "candidate": ci,
            "source": ir.get("source", "ir"),
            "score": score,
            "bbox_m": [bw, bd],
            "coverage_m2": round(total_area, 2),
            "ir": cand_ir,
            "svg": plan_svg(cand_ir, score, bw, bd),
        })
    return out


def _layout_origin(ir: dict, idx: int, r: dict):
    """Look up a room origin for name-keyed (presets) or index-keyed (replans) layouts."""
    layout = ir.get("layout_m") or {}
    return (layout.get(str(idx)) or layout.get(r.get("name_cn"))
            or layout.get(r.get("name_en")) or [0.0, 0.0])


def plan_svg(ir: dict, score: float, bw: float, bd: float, ppm: float = 60.0) -> str:
    pad, header = 30.0, 60.0
    width, height = bw * ppm + 2 * pad, bd * ppm + 2 * pad + header
    colors = {"living": "#dbeafe", "dining": "#fef3c7", "bedroom": "#ede9fe",
              "kitchen": "#dcfce7", "bathroom": "#cffafe", "study": "#fae8ff",
              "hallway": "#f3f4f6", "balcony": "#ecfccb", "empty": "#ffffff"}
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width:.0f}" height="{height:.0f}" '
             f'viewBox="0 0 {width:.0f} {height:.0f}">',
             f'<rect width="100%" height="100%" fill="white"/>',
             f'<text x="{pad}" y="30" font-family="Segoe UI,Arial" font-size="18" font-weight="700">'
             f'{ir["source"]}</text>',
             f'<text x="{pad}" y="50" font-family="Segoe UI,Arial" font-size="13" fill="#555">'
             f'packing score {score:.3f} · bbox {bw:.1f}×{bd:.1f} m · '
             f'{len(ir["rooms"])} rooms</text>']
    typ = {r["name_cn"]: None for r in ir["rooms"]}
    for r in ir["rooms"]:
        typ[r["name_cn"]] = r["name_en"]
    for idx, r in enumerate(ir["rooms"]):
        x, z = _layout_origin(ir, idx, r)
        w, d = r["dims_m"]
        t = typ[r["name_cn"]]
        fill = next((c for k, c in colors.items() if k in t), "#eee")
        px, py = pad + x * ppm, pad + header + z * ppm
        parts.append(f'<rect x="{px:.1f}" y="{py:.1f}" width="{w*ppm:.1f}" height="{d*ppm:.1f}" '
                     f'fill="{fill}" stroke="#374151" stroke-width="2"/>')
        parts.append(f'<text x="{px + w*ppm/2:.1f}" y="{py + d*ppm/2 - 4:.1f}" text-anchor="middle" '
                     f'font-family="Segoe UI,Arial" font-size="14" font-weight="600">{r["name_cn"]}</text>')
        parts.append(f'<text x="{px + w*ppm/2:.1f}" y="{py + d*ppm/2 + 14:.1f}" text-anchor="middle" '
                     f'font-family="Segoe UI,Arial" font-size="11" fill="#555">'
                     f'{w:.1f}×{d:.1f} m</text>')
    parts.append("</svg>")
    return "\n".join(parts)


def plan_png(ir: dict, path, ppm: float = 60.0) -> str:
    """Rasterise a generated plan with PIL (ASCII room names, no font dependency)."""
    from PIL import Image, ImageDraw, ImageFont

    rooms = ir["rooms"]
    origins = [_layout_origin(ir, i, r) for i, r in enumerate(rooms)]
    xs = [o[0] for o in origins]
    zs = [o[1] for o in origins]
    bw = max(x + r["dims_m"][0] for x, r in zip(xs, rooms))
    bd = max(z + r["dims_m"][1] for z, r in zip(zs, rooms))
    pad, header = 30, 60
    W, H = int(bw * ppm + 2 * pad), int(bd * ppm + 2 * pad + header)
    img = Image.new("RGB", (W, H), "white")
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.load_default(size=14)
        small = ImageFont.load_default(size=11)
        title_font = ImageFont.load_default(size=17)
    except TypeError:
        font = small = title_font = ImageFont.load_default()
    draw.text((pad, 14), ir["source"], fill="#111", font=title_font)
    draw.text((pad, 36), f"generated plan · {len(rooms)} rooms", fill="#555", font=small)
    colors = {"living": "#dbeafe", "dining": "#fef3c7", "bedroom": "#ede9fe",
              "kitchen": "#dcfce7", "bathroom": "#cffafe", "study": "#fae8ff",
              "hallway": "#f3f4f6", "balcony": "#ecfccb"}
    for i, r in enumerate(rooms):
        x, z = origins[i]
        w, d = r["dims_m"]
        px, py = pad + x * ppm, pad + header + z * ppm
        t = r["name_en"]
        fill = next((c for k, c in colors.items() if k in t), "#eeeeee")
        draw.rectangle([px, py, px + w * ppm, py + d * ppm], fill=fill, outline="#374151", width=2)
        label = r["name_en"].replace(" ", "_")
        draw.text((px + 6, py + 6), label, fill="#111", font=font)
        draw.text((px + 6, py + 24), f"{w:.1f}x{d:.1f} m", fill="#555", font=small)
    img.save(path)
    return str(path)


def _font(size: int, bold: bool = False):
    """Windows CJK-capable font, with a portable fallback."""
    from PIL import ImageFont
    candidates = ([r"C:\Windows\Fonts\msyhbd.ttc", r"C:\Windows\Fonts\msyh.ttc"]
                  if bold else [r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\simhei.ttf"])
    candidates += [r"C:\Windows\Fonts\simhei.ttf", r"C:\Windows\Fonts\arial.ttf"]
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except Exception:
            continue
    return ImageFont.load_default()


def schematic_png(ir: dict, path, ppm: float = 90.0, title: str | None = None) -> str:
    """Clean input-plan drawing: walls, room names and areas only.

    No furniture, fixture or object glyph is drawn.  The geometry comes from the
    same ``layout_m`` that the solver consumes, so the input drawing and every
    candidate scene share one room arrangement.
    """
    from PIL import Image, ImageDraw

    rooms = ir["rooms"]
    origins = [_layout_origin(ir, i, r) for i, r in enumerate(rooms)]
    floor_m = ir.get("floor_m") or []
    if floor_m:
        xs = [float(v) for r in floor_m for v in (r[0], r[2])]
        zs = [float(v) for r in floor_m for v in (r[1], r[3])]
    else:
        xs = [o[0] + r["dims_m"][0] for o, r in zip(origins, rooms)] + [o[0] for o in origins]
        zs = [o[1] + r["dims_m"][1] for o, r in zip(origins, rooms)] + [o[1] for o in origins]
    x0, x1, z0, z1 = min(xs), max(xs), min(zs), max(zs)
    pad, header = 48, 116
    W = int((x1 - x0) * ppm + 2 * pad)
    H = int((z1 - z0) * ppm + 2 * pad + header)
    img = Image.new("RGB", (W, H), "#ffffff")
    draw = ImageDraw.Draw(img)

    def px(mx, mz):
        return pad + (mx - x0) * ppm, pad + header + (mz - z0) * ppm

    total = sum(r["dims_m"][0] * r["dims_m"][1] for r in rooms)
    plan_title = title or str(ir.get("source") or "floor plan")
    draw.text((pad, 22), plan_title, fill="#1d1d1b", font=_font(26, bold=True))
    draw.text((pad, 58), f"input schematic · {len(rooms)} rooms · {total:.1f} m²",
              fill="#5c5a55", font=_font(15))
    draw.text((pad, 82), "walls, room names and areas only — no furniture",
              fill="#8a857c", font=_font(13))

    # Palette by inferred room type, deliberately pale so the walls read first.
    palette = {"living": "#eaf2fb", "dining": "#fdf4dd", "bedroom": "#f1edfb",
               "kitchen": "#eaf7ec", "bathroom": "#e8f7f8", "study": "#f9ecf8",
               "hallway": "#f4f4f2", "balcony": "#f0f8df", "empty": "#fafafa"}
    fills = []
    for r in rooms:
        rtype = r.get("room_type") or infer_room_type(r.get("name_en"), r.get("name_cn"))
        fills.append(palette.get(rtype, "#f7f7f5"))

    # Outer floor / apartment footprint; a pale neutral shows circulation
    # areas between rooms without inventing furniture or extra room labels.
    for r in floor_m:
        a = px(float(r[0]), float(r[1]))
        b = px(float(r[2]), float(r[3]))
        draw.rectangle([a[0], a[1], b[0], b[1]], fill="#f6f3ec",
                       outline="#2d2d2a", width=6)

    # Room floors + walls. Walls are the thick dark room outlines.
    for i, (r, org) in enumerate(zip(rooms, origins)):
        x, z = org
        w, d = r["dims_m"]
        a = px(x, z)
        b = px(x + w, z + d)
        draw.rectangle([a[0], a[1], b[0], b[1]], fill=fills[i], outline="#262624", width=5)

    # Labels after all rectangles so walls cannot cover text.
    for i, (r, org) in enumerate(zip(rooms, origins)):
        x, z = org
        w, d = r["dims_m"]
        cx, cy = px(x + w / 2, z + d / 2)
        size = max(11, min(21, int(min(w, d) * ppm * 0.20)))
        name = str(r.get("name_cn") or r.get("name_en") or "")
        en = str(r.get("name_en") or "").replace("_", " ").strip()
        area = w * d
        draw.text((cx, cy - size * 0.55), name, anchor="mm", fill="#111110",
                  font=_font(size, bold=True))
        sub = f"{en} · {area:.1f} m²" if en else f"{area:.1f} m²"
        if min(w, d) * ppm >= 80:
            draw.text((cx, cy + size * 0.62), sub, anchor="mm", fill="#57544e",
                      font=_font(max(9, min(13, size - 5))))
        else:
            draw.text((cx, cy + size * 0.62), f"{area:.1f} m²", anchor="mm",
                      fill="#57544e", font=_font(max(9, size - 7)))

    # North arrow, upper right.
    ax, ay = W - pad - 22, header - 4
    draw.line([(ax, ay + 28), (ax, ay)], fill="#262624", width=3)
    draw.polygon([(ax, ay - 8), (ax - 7, ay + 7), (ax + 7, ay + 7)], fill="#262624")
    draw.text((ax, ay + 34), "N", anchor="ma", fill="#262624", font=_font(12, bold=True))

    img.save(path)
    return str(path)


def svg_from_zones(rooms: list[dict], title: str, ppm: float = 0.6) -> str:
    """Plan-like SVG from built scene zones (LDU): works for any IR, including
    legacy row-major plans that carry no `layout_m`."""
    xs = [r["zone_ldu"][0] for r in rooms] + [r["zone_ldu"][2] for r in rooms]
    zs = [r["zone_ldu"][1] for r in rooms] + [r["zone_ldu"][3] for r in rooms]
    x0, z0, x1, z1 = min(xs), min(zs), max(xs), max(zs)
    pad, header = 30.0, 56.0
    width = (x1 - x0) * ppm + 2 * pad
    height = (z1 - z0) * ppm + 2 * pad + header
    palette = ["#dbeafe", "#fef3c7", "#ede9fe", "#dcfce7", "#cffafe", "#fae8ff", "#f3f4f6", "#ecfccb"]
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width:.0f}" height="{height:.0f}" '
             f'viewBox="0 0 {width:.0f} {height:.0f}">',
             '<rect width="100%" height="100%" fill="white"/>',
             f'<text x="{pad}" y="28" font-family="Segoe UI,Arial" font-size="17" font-weight="700">{title}</text>',
             f'<text x="{pad}" y="47" font-family="Segoe UI,Arial" font-size="12" fill="#555">'
             f'{len(rooms)} rooms · {(x1-x0)/100:.1f}×{(z1-z0)/100:.1f} m</text>']
    for i, r in enumerate(rooms):
        zx0, zz0, zx1, zz1 = r["zone_ldu"]
        px, py = pad + (zx0 - x0) * ppm, pad + header + (zz0 - z0) * ppm
        pw, ph = (zx1 - zx0) * ppm, (zz1 - zz0) * ppm
        parts.append(f'<rect x="{px:.1f}" y="{py:.1f}" width="{pw:.1f}" height="{ph:.1f}" '
                     f'fill="{palette[i % len(palette)]}" stroke="#374151" stroke-width="2"/>')
        parts.append(f'<text x="{px + pw/2:.1f}" y="{py + ph/2 + 5:.1f}" text-anchor="middle" '
                     f'font-family="Segoe UI,Arial" font-size="13" font-weight="600">{r["name_cn"]}</text>')
    parts.append("</svg>")
    return "\n".join(parts)
