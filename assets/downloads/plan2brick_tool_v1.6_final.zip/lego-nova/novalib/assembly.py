"""lego-nova · M3 选件 + M4 布局 + M5 组装（确定性，零 token）。

重构自 fyp-pipeline v1.3 `build_scene.py`（本 FYP 自建代码）；lego-nova 增补：
  [N1] 可选户型拓扑：IR 带 `layout_m`（room -> [x0,z0] 米）时按真实坐标分区，
       否则退回 row-major 打包（向后兼容既有 IR）。
  [N2] 候选变体旋钮（IR `_build`）：`pref_shift` 旋转贴墙偏好序、
       `item_bias` 缩放选件尺寸估计 → 同户型多方案比较。

Input : 场景 IR（schema/scene_ir.schema.json；由 M2 臂产出，提示词 = prompts/m2_scene_ir_v1.md）
        M1 物体库（library/index.json + <id>.mpd + <id>.meta.json）
Output: out/<name>/scene.mpd + out/<name>/placements.json

Usage: C:\\Python314\\python.exe build_scene.py --ir examples/floorplan_flash.json --name scene_floorplan

v1 相对 Run 6 v0（step_c_assemble.py）的三处改进：
  [v1a] 选件带房间适配：只从「两个水平跨度都能放进目标房间内空」的候选里挑；
        全不满足 → 丢弃记 "no library item fits room"（v0 会把超大件选中摆出房间）。
  [v1b] try_place 增加进深检查：贴墙件的进深 > 房间内空 → 该带跳过
        （v0 缺陷来源：餐厅进深 1.2 m 却放入进深 199.4 LDU 的餐桌，
         从南墙穿到北侧、侵入邻区客厅与沙发脚印重叠 79.4×19.4 LDU）。
  [v1c] 摆放完成后做全局 footprint 互斥扫描（跨房间），结果记入 placements.json
        `cross_room_overlaps`（v0 只在房间内部做 AABB 拒绝，跨区不可见）。
  [v1.3] 同名多实例房间修复（R1 img 臂三个「卧室」）：对象先解析到**具体房间实例**
        （name_en 精确优先；同名歧义时按「连续同名对象段」round-robin——IR 对象通常
        按房间分组排列，同段沿用同一实例），按实例 rid 归属；修复此前同名房间共用
        name_cn 池、每个同名区各摆一遍全部对象导致的重复摆放。

Layout v1 rules（其余沿用 v0，见 Run 6 REPORT §7）：
- 房间 = 按 IR 顺序 row-major 打包的矩形区（不复原户型拓扑，→ backlog）；
- 贴墙带 N/E/S/W 槽位（每类偏好序），1 stud 边距，游标推进，先到先得；无旋转（yaw 0）；
- 房间内 AABB 互斥；放不下 → 丢弃（供覆盖率指标）；
- 组装 = 纯平移：new = old + anchor_ldu + (px, 0, pz)。
尺度：MINIFIG-SCALE，1 m ≈ 5 studs ≈ 100 LDU（M2LDU=100；见 library/LIBRARY.md）。
"""
import argparse
import json
import math
import re
from pathlib import Path

try:  # package import (edit.py, variants.py) vs. direct script execution
    from . import circulation, floorplan, floors, relations, walls
except ImportError:  # pragma: no cover - exercised by `python assembly.py`
    import circulation  # type: ignore[no-redef]
    import floorplan  # type: ignore[no-redef]
    import floors  # type: ignore[no-redef]
    import relations  # type: ignore[no-redef]
    import walls  # type: ignore[no-redef]

HERE = Path(__file__).resolve().parent
DEFAULT_LIBRARY = HERE.parent.parent / "fyp-pipeline" / "library"

LDU = 20          # per stud
M2LDU = 100.0     # metres -> LDU at MINIFIG-SCALE (1 m ~= 5 studs); NOT plastic scale (2500)
MARGIN = 1        # studs from wall
GAP = 1           # studs between items and between zones
ROOM_GAP = 3      # studs between room zones
CAT_ORDER = ["bed", "sofa", "desk", "cabinet", "bookshelf", "fridge", "washer", "bath", "stove", "tv",
             "table", "chair", "sink", "toilet", "lamp", "plant"]

# category -> preferred wall bands (N=north/z-, S=south/z+, W=west/x-, E=east/x+)
PREF = {
    "bed": "NSWE", "sofa": "SWNE", "tv": "NEWS", "desk": "EWNS", "cabinet": "EWNS",
    "bookshelf": "EWNS", "table": "SNEW", "chair": "SNEW", "lamp": "WESN", "plant": "WESN",
    "fridge": "EWNS", "stove": "EWNS", "sink": "EWNS", "toilet": "WESN", "bath": "NSWE",
    "washer": "WESN",
}

# Palette layer (diversity v1): furniture parts are recoloured to the nearest
# colour in a fixed LDraw palette.  Floors/walls keep their intentional colours
# (28 dark tan / 71 light bluish grey), so a palette change is furniture-only.
# RGB values are copied from the local LDraw LDConfig.ldr so the mapping is
# deterministic and needs no external file at build time.
COLOR_RGB = {
    "0": "1B2A34", "1": "1E5AA8", "2": "00852B", "3": "069D9F", "4": "B40000",
    "6": "543324", "7": "8A928D", "8": "545955", "9": "97CBD9", "10": "58AB41",
    "14": "FAC80A", "15": "F4F4F4", "19": "D7BA8C", "25": "D67923", "27": "A5CA18",
    "28": "897D62", "29": "FF9ECD", "34": "237841", "36": "C91A09", "38": "FF800D",
    "40": "635F52", "42": "C0FF00", "43": "AEE9EF", "47": "FCFCFC", "57": "F08F1C",
    "70": "5F3109", "71": "969696", "72": "646464", "73": "7396C8", "74": "7FC475",
    "80": "767676", "84": "AA7D55", "85": "441A91", "86": "7B5D41", "110": "26469A",
    "112": "4861AC", "135": "A0A0A0", "147": "83724F", "151": "C8C8C8",
    "179": "898788", "191": "FCAC00", "212": "9DC3F7", "216": "872B17",
    "226": "FFEC6C", "232": "77C9D8", "272": "19325A", "288": "00451A",
    "297": "AA7F2E", "308": "352100", "320": "720012", "321": "469BC3",
    "322": "68C3E2", "323": "D3F2EA", "326": "E2F99A", "330": "77774E",
    "335": "88605E", "351": "F785B1", "353": "FF6D77", "366": "D86D2C",
    "378": "708E7C", "379": "70819A", "509": "CF8A47",
}
PALETTE_TARGETS = {
    "neutral": ["15", "71", "72", "19", "28", "84"],
    "warm": ["4", "14", "25", "19", "28", "70", "84", "191", "226", "366", "509"],
    "cool": ["1", "2", "3", "9", "10", "71", "73", "74", "212", "232", "321", "322", "379"],
    "mono": ["0", "15", "71", "72", "80", "135", "151", "179"],
    "earth": ["6", "19", "28", "70", "84", "147", "297", "308", "330"],
    "vivid": ["1", "2", "4", "10", "14", "29", "36", "38", "42", "43", "191", "226", "351", "353"],
}


def _rgb(hex6):
    return tuple(int(hex6[i:i + 2], 16) / 255.0 for i in (0, 2, 4))


PALETTE_MAPS = {}
for _name, _targets in PALETTE_TARGETS.items():
    _tgt = {code: _rgb(COLOR_RGB[code]) for code in _targets}
    PALETTE_MAPS[_name] = {}
    for _code, _hex in COLOR_RGB.items():
        _src = _rgb(_hex)
        _best = min(_tgt, key=lambda c: sum((a - b) ** 2 for a, b in zip(_src, _tgt[c])))
        PALETTE_MAPS[_name][_code] = _best


def recolor_parts(parts, palette):
    """Return part lines with colour codes remapped to `palette` (unknown ids kept)."""
    mapping = PALETTE_MAPS.get(str(palette or "").lower())
    if not mapping:
        return list(parts)
    out = []
    for ln in parts:
        t = ln.split()
        if len(t) > 1 and t[0] == "1":
            t[1] = mapping.get(t[1], t[1])
            out.append(" ".join(t))
        else:
            out.append(ln)
    return out


def m2ldu(v):
    return v * M2LDU


def load_items(lib):
    idx = json.loads((lib / "index.json").read_text(encoding="utf-8"))
    items = {}
    for it in idx:
        meta = json.loads((lib / f"{it['id']}.meta.json").read_text(encoding="utf-8"))
        body = [ln for ln in (lib / it["file"]).read_text(encoding="utf-8").splitlines() if ln.startswith("1 ")]
        items[it["id"]] = {
            "id": it["id"],
            "category": it["category"],
            "size_studs": meta["size_studs"],          # [x, y(=height), z] studs
            "anchor": meta["anchor_ldu"],
            "parts": body,
            "part_count": meta["part_count"],
            "style_tags": meta.get("style_tags") or [],
            "color_family": meta.get("color_family"),
            "size_class": it.get("size_class") or meta.get("size_class"),
        }
    return items


def fits_room(item, inner_x, inner_z):
    """[v1a] 两个水平跨度都能放进房间内空（无旋转下 N/S 与 E/W 带约化为同一约束）。"""
    sx, _, sz = item["size_studs"]
    return sx * LDU <= inner_x and sz * LDU <= inner_z


def _room_style_tags(placed):
    """Most common style tags already present in a room (for soft consistency)."""
    counts = {}
    for p in placed:
        for tag in (p.get("item") or {}).get("style_tags") or []:
            counts[tag] = counts.get(tag, 0) + 1
    if not counts:
        return set()
    top = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:2]
    return {tag for tag, _ in top}


def pick_item(items, category, size_est_m, used_count, inner_x, inner_z, style=None,
              room_tags=None):
    """从适配房间的候选里取 log2 尺寸距离最优件。Returns (item, None) or (None, reason)。

    ``style`` is a soft preference from the diversity layer: matching
    ``meta.style_tags`` gets a small bonus, but size fit remains dominant.
    """
    cands = [it for it in items.values() if it["category"] == category]
    if not cands:
        return None, f"no library item for {category}"
    fit = [it for it in cands if fits_room(it, inner_x, inner_z)]
    if not fit:
        return None, f"no library item fits room (inner {inner_x:.0f}x{inner_z:.0f} LDU)"
    tgt = (max(size_est_m[0], size_est_m[1]) * 5, min(size_est_m[0], size_est_m[1]) * 5, size_est_m[2] * 5)
    style_pref = {
        "minimal": {"modern", "compact"},
        "compact": {"compact", "modern"},
        "family": {"family", "rustic", "vintage"},
        "wfh": {"modern", "compact"},
        "spacious": {"family", "rustic"},
        "balanced": set(),
    }.get(str(style or "").lower(), set())
    size_pref = {
        "minimal": {"small"},
        "compact": {"small"},
        "family": {"large"},
        "spacious": {"large"},
        "wfh": {"medium"},
    }.get(str(style or "").lower(), set())

    def score(it):
        sx, sy, sz = it["size_studs"]
        L, S = max(sx, sz), min(sx, sz)
        base = sum(abs(math.log2(max(v, 0.2) / max(t, 0.2))) for v, t in zip((L, S, sy), tgt))
        base += 0.05 * used_count.get(it["id"], 0)  # spread usage a bit
        tags = set(it.get("style_tags") or [])
        if style_pref:
            if tags & style_pref:
                base -= 0.12
            elif tags:
                base += 0.06
        if room_tags and tags & room_tags:
            base -= 0.08
        if size_pref:
            sc = it.get("size_class")
            if sc in size_pref:
                base -= 0.05
            elif sc:
                base += 0.02
        return base

    best = min(fit, key=score)
    used_count[best["id"]] = used_count.get(best["id"], 0) + 1
    return best, None


def rect(x0, z0, x1, z1):
    return {"x0": x0, "z0": z0, "x1": x1, "z1": z1}


def overlaps(a, b):
    return a["x0"] < b["x1"] and b["x0"] < a["x1"] and a["z0"] < b["z1"] and b["z0"] < a["z1"]


def band_slots(room, reverse_bands=None):
    m = MARGIN * LDU
    reverse = {b.upper() for b in (reverse_bands or [])}
    slots = {
        "N": {"axis": "x", "at": "z0", "c0": room["x0"] + m, "c1": room["x1"] - m},
        "S": {"axis": "x", "at": "z1", "c0": room["x0"] + m, "c1": room["x1"] - m},
        "W": {"axis": "z", "at": "x0", "c0": room["z0"] + m, "c1": room["z1"] - m},
        "E": {"axis": "z", "at": "x1", "c0": room["z0"] + m, "c1": room["z1"] - m},
    }
    for band, s in slots.items():
        s["rev"] = band in reverse
        s["cur"] = s["c1"] if s["rev"] else s["c0"]
    return slots


def try_place(room, slots, placed, item, cat_order, pref=None, reserved=None):
    """Return (foot, cx, cz, band) or None; tries preferred bands in order.

    A blocked band is scanned in deterministic one-stud steps until a free
    interval is found, instead of abandoning the whole band at the first
    collision.  The slot cursor is committed only after a candidate passes
    both the room-containment and footprint-overlap checks.  ``reserved``
    rectangles (door approach zones) are treated as occupied.
    """
    m = MARGIN * LDU
    inner_x = room["x1"] - room["x0"] - 2 * m
    inner_z = room["z1"] - room["z0"] - 2 * m
    sx, _, sz = item["size_studs"]
    fw, fd = sx * LDU, sz * LDU
    pref_map = pref or PREF
    bands = pref_map.get(cat_order) or PREF.get(cat_order, "NSEW")
    for band in bands:
        s = slots[band]
        along = fw if s["axis"] == "x" else fd          # extent along the wall
        depth = fd if s["axis"] == "x" else fw          # extent into the room
        if depth > (inner_z if s["axis"] == "x" else inner_x):
            continue                                    # [v1b] depth must fit the room
        step = GAP * LDU
        if s["rev"]:
            start = s["cur"] - along
            limit = s["c0"]
            while start >= limit:
                center_along = start + along / 2
                if s["axis"] == "x":
                    cx = center_along
                    cz = (room["z0"] + m + depth / 2) if s["at"] == "z0" else (room["z1"] - m - depth / 2)
                else:
                    cz = center_along
                    cx = (room["x0"] + m + depth / 2) if s["at"] == "x0" else (room["x1"] - m - depth / 2)
                foot = rect(cx - fw / 2, cz - fd / 2, cx + fw / 2, cz + fd / 2)
                inside = (room["x0"] + m <= foot["x0"] and foot["x1"] <= room["x1"] - m
                          and room["z0"] + m <= foot["z0"] and foot["z1"] <= room["z1"] - m)
                if inside and not any(overlaps(foot, p["foot"]) for p in placed) \
                        and not any(overlaps(foot, z) for z in (reserved or [])):
                    s["cur"] = start - step
                    return foot, cx, cz, band
                start -= step
        else:
            start = s["cur"]
            limit = s["c1"]
            while start + along <= limit:
                center_along = start + along / 2
                if s["axis"] == "x":
                    cx = center_along
                    cz = (room["z0"] + m + depth / 2) if s["at"] == "z0" else (room["z1"] - m - depth / 2)
                else:
                    cz = center_along
                    cx = (room["x0"] + m + depth / 2) if s["at"] == "x0" else (room["x1"] - m - depth / 2)
                foot = rect(cx - fw / 2, cz - fd / 2, cx + fw / 2, cz + fd / 2)
                inside = (room["x0"] + m <= foot["x0"] and foot["x1"] <= room["x1"] - m
                          and room["z0"] + m <= foot["z0"] and foot["z1"] <= room["z1"] - m)
                if inside and not any(overlaps(foot, p["foot"]) for p in placed) \
                        and not any(overlaps(foot, z) for z in (reserved or [])):
                    s["cur"] = start + along + step
                    return foot, cx, cz, band
                start += step
    return None


def try_place_at(room, placed, item, cx, cz, reserved=None):
    """Place an item at an explicit centre; return (foot, cx, cz, "C") or None.

    Used by the centre-table pass, which needs positions that are not on a
    wall band.  The room margin and all normal overlap checks still apply.
    """
    m = MARGIN * LDU
    sx, _, sz = item["size_studs"]
    fw, fd = sx * LDU, sz * LDU
    foot = rect(cx - fw / 2, cz - fd / 2, cx + fw / 2, cz + fd / 2)
    inside = (room["x0"] + m <= foot["x0"] and foot["x1"] <= room["x1"] - m
              and room["z0"] + m <= foot["z0"] and foot["z1"] <= room["z1"] - m)
    if not inside:
        return None
    if any(overlaps(foot, p["foot"]) for p in placed):
        return None
    if any(overlaps(foot, z) for z in (reserved or [])):
        return None
    return foot, cx, cz, "C"


def _place_dining_set(room, objs, placed, placed_all, items, used_count,
                      style, reserved, dropped):
    """Centre a dining table and place its chairs around it (product path).

    Returns the set of object ids consumed.  If the table cannot fit at the
    room centre or a nearby offset, nothing is consumed and the caller falls
    back to the normal wall-band placement.
    """
    table_obj = next((o for o in objs
                      if o.get("category") == "table"
                      and ("餐桌" in str(o.get("label") or "") or "dining" in str(o.get("label") or "").lower())), None)
    if table_obj is None:
        return set()
    m = MARGIN * LDU
    inner_x = room["x1"] - room["x0"] - 2 * m
    inner_z = room["z1"] - room["z0"] - 2 * m
    table_item, why = pick_item(items, "table", table_obj.get("size_est_m") or [1.2, 0.8, 0.75],
                                used_count, inner_x, inner_z, style=style,
                                room_tags=_room_style_tags(placed))
    if table_item is None:
        return set()
    cx0 = (room["x0"] + room["x1"]) / 2
    cz0 = (room["z0"] + room["z1"]) / 2
    table_res = None
    for dx, dz in ((0, 0), (0, LDU), (0, -LDU), (LDU, 0), (-LDU, 0),
                   (2 * LDU, 0), (-2 * LDU, 0), (0, 2 * LDU), (0, -2 * LDU)):
        table_res = try_place_at(room, placed, table_item, cx0 + dx, cz0 + dz, reserved)
        if table_res:
            break
    if table_res is None:
        return set()
    foot, cx, cz, band = table_res
    placed.append({"item": table_item, "foot": foot, "cx": cx, "cz": cz,
                   "band": band, "ir": table_obj, "index": len(placed_all) + 1,
                   "rid": room["rid"]})
    placed_all.append(placed[-1])
    handled = {id(table_obj)}

    chair_obj = next((o for o in objs
                      if o.get("category") == "chair"
                      and ("餐椅" in str(o.get("label") or "") or "dining" in str(o.get("label") or "").lower())), None)
    if chair_obj is None:
        return handled
    count = int(chair_obj.get("count", 1) or 1)
    chair_item, why = pick_item(items, "chair", chair_obj.get("size_est_m") or [0.45, 0.45, 0.9],
                                used_count, inner_x, inner_z, style=style,
                                room_tags=_room_style_tags(placed))
    if chair_item is None:
        dropped.append({"room": room["name_cn"], "object": chair_obj.get("label"),
                        "why": why or "no chair item"})
        return handled
    tw = table_item["size_studs"][0] * LDU
    td = table_item["size_studs"][2] * LDU
    cw = chair_item["size_studs"][0] * LDU
    cd = chair_item["size_studs"][2] * LDU
    gap = GAP * LDU
    # Two chairs on the north and two on the south side; fall back to east and
    # west if a side is blocked by a door zone or another item.
    positions = []
    for n in (-1, 1):
        positions.append((cx + n * tw / 4, cz - td / 2 - cd / 2 - gap))
    for n in (-1, 1):
        positions.append((cx + n * tw / 4, cz + td / 2 + cd / 2 + gap))
    for n in (-1, 1):
        positions.append((cx - tw / 2 - cw / 2 - gap, cz + n * td / 4))
    for n in (-1, 1):
        positions.append((cx + tw / 2 + cw / 2 + gap, cz + n * td / 4))
    placed_chairs = 0
    for px, pz in positions:
        if placed_chairs >= count:
            break
        res = try_place_at(room, placed, chair_item, px, pz, reserved)
        if res is None:
            continue
        foot, pcx, pcz, band = res
        placed.append({"item": chair_item, "foot": foot, "cx": pcx, "cz": pcz,
                       "band": band, "ir": chair_obj, "index": len(placed_all) + 1,
                       "rid": room["rid"]})
        placed_all.append(placed[-1])
        placed_chairs += 1
    handled.add(id(chair_obj))
    for k in range(placed_chairs, count):
        dropped.append({"room": room["name_cn"], "object": f"{chair_obj.get('label')} #{k+1}",
                        "why": "no space around dining table"})
    return handled


def _place_bed_set(room, objs, slots, placed, placed_all, items, used_count, style,
                   pref_active, reserved):
    """Place a bed and its bedside companions as one group (product path).

    The bed uses the normal wall-band placer; the bedside cabinet (and a
    bedside lamp when present) are then placed explicitly on the free side of
    the bed.  If the bed cannot be placed, nothing is consumed and the normal
    loop handles the room.
    """
    bed_obj = next((o for o in objs if o.get("category") == "bed"), None)
    if bed_obj is None:
        return set()
    m = MARGIN * LDU
    inner_x = room["x1"] - room["x0"] - 2 * m
    inner_z = room["z1"] - room["z0"] - 2 * m
    bed_item, why = pick_item(items, "bed", bed_obj.get("size_est_m") or [2.0, 1.5, 0.5],
                              used_count, inner_x, inner_z, style=style,
                              room_tags=_room_style_tags(placed))
    if bed_item is None:
        return set()
    res = try_place(room, slots, placed, bed_item, "bed", pref_active, reserved=reserved)
    if res is None:
        return set()
    foot, cx, cz, band = res
    placed.append({"item": bed_item, "foot": foot, "cx": cx, "cz": cz,
                   "band": band, "ir": bed_obj, "index": len(placed_all) + 1,
                   "rid": room["rid"]})
    placed_all.append(placed[-1])
    handled = {id(bed_obj)}

    bw = bed_item["size_studs"][0] * LDU
    bd = bed_item["size_studs"][2] * LDU
    gap = GAP * LDU

    def side_positions(item):
        sw = item["size_studs"][0] * LDU
        sd = item["size_studs"][2] * LDU
        if band in ("N", "S"):
            off = bw / 2 + sw / 2 + gap
            primary = [(cx - off, cz), (cx + off, cz)]
            into = cz + (bd / 2 + sd / 2 + gap) if band == "N" else cz - (bd / 2 + sd / 2 + gap)
            return primary + [(cx + dx, into) for dx in (0, -60, 60, -120, 120)]
        if band in ("E", "W"):
            off = bd / 2 + sd / 2 + gap
            primary = [(cx, cz - off), (cx, cz + off)]
            into = cx + (bw / 2 + sw / 2 + gap) if band == "W" else cx - (bw / 2 + sw / 2 + gap)
            return primary + [(into, cz + dz) for dz in (0, -60, 60, -120, 120)]
        return [(cx - bw / 2 - sw / 2 - gap, cz), (cx + bw / 2 + sw / 2 + gap, cz)]

    ns_obj = next((o for o in objs
                   if o.get("category") == "cabinet"
                   and ("床头柜" in str(o.get("label") or "") or "nightstand" in str(o.get("label") or "").lower())), None)
    if ns_obj is not None:
        ns_item, why = pick_item(items, "cabinet", ns_obj.get("size_est_m") or [0.5, 0.4, 0.55],
                                 used_count, inner_x, inner_z, style=style,
                                 room_tags=_room_style_tags(placed))
        if ns_item is not None:
            for px, pz in side_positions(ns_item):
                r2 = try_place_at(room, placed, ns_item, px, pz, reserved)
                if r2 is None:
                    continue
                f2, c2x, c2z, b2 = r2
                placed.append({"item": ns_item, "foot": f2, "cx": c2x, "cz": c2z,
                               "band": b2, "ir": ns_obj, "index": len(placed_all) + 1,
                               "rid": room["rid"]})
                placed_all.append(placed[-1])
                handled.add(id(ns_obj))
                break

    lamp_obj = next((o for o in objs
                     if o.get("category") == "lamp"
                     and ("床头灯" in str(o.get("label") or "") or "night" in str(o.get("label") or "").lower())), None)
    if lamp_obj is not None:
        lamp_item, why = pick_item(items, "lamp", lamp_obj.get("size_est_m") or [0.35, 0.35, 0.5],
                                   used_count, inner_x, inner_z, style=style,
                                   room_tags=_room_style_tags(placed))
        if lamp_item is not None:
            for px, pz in side_positions(lamp_item):
                r3 = try_place_at(room, placed, lamp_item, px, pz, reserved)
                if r3 is None:
                    continue
                f3, c3x, c3z, b3 = r3
                placed.append({"item": lamp_item, "foot": f3, "cx": c3x, "cz": c3z,
                               "band": b3, "ir": lamp_obj, "index": len(placed_all) + 1,
                               "rid": room["rid"]})
                placed_all.append(placed[-1])
                handled.add(id(lamp_obj))
                break
    return handled


def _place_living_set(room, objs, slots, placed, placed_all, items, used_count, style,
                      pref_active, reserved):
    """Place sofa + TV + coffee table as one group (product path).

    Sofa uses the normal wall-band placer; the TV goes on the opposite wall,
    aligned with the sofa, and the coffee table goes in front of the sofa.
    Missing/failed companions fall back to the normal wall-band loop.
    """
    sofa_obj = next((o for o in objs if o.get("category") == "sofa"), None)
    if sofa_obj is None:
        return set()
    m = MARGIN * LDU
    inner_x = room["x1"] - room["x0"] - 2 * m
    inner_z = room["z1"] - room["z0"] - 2 * m
    sofa_item, why = pick_item(items, "sofa", sofa_obj.get("size_est_m") or [2.1, 0.9, 0.8],
                               used_count, inner_x, inner_z, style=style,
                               room_tags=_room_style_tags(placed))
    if sofa_item is None:
        return set()
    res = try_place(room, slots, placed, sofa_item, "sofa", pref_active, reserved=reserved)
    if res is None:
        return set()
    foot, cx, cz, band = res
    placed.append({"item": sofa_item, "foot": foot, "cx": cx, "cz": cz,
                   "band": band, "ir": sofa_obj, "index": len(placed_all) + 1,
                   "rid": room["rid"]})
    placed_all.append(placed[-1])
    handled = {id(sofa_obj)}
    sfw = foot["x1"] - foot["x0"]
    sfd = foot["z1"] - foot["z0"]
    gap = GAP * LDU

    tv_obj = next((o for o in objs if o.get("category") == "tv"), None)
    if tv_obj is not None:
        tv_item, why = pick_item(items, "tv", tv_obj.get("size_est_m") or [1.2, 0.4, 0.6],
                                 used_count, inner_x, inner_z, style=style,
                                 room_tags=_room_style_tags(placed))
        if tv_item is not None:
            tw = tv_item["size_studs"][0] * LDU
            td = tv_item["size_studs"][2] * LDU
            if band in ("N", "S"):
                z = room["z1"] - m - td / 2 if band == "N" else room["z0"] + m + td / 2
                cand = [(cx + dx, z) for dx in (0, -sfw / 4, sfw / 4, -sfw / 2, sfw / 2)]
            else:
                x = room["x1"] - m - td / 2 if band == "W" else room["x0"] + m + td / 2
                cand = [(x, cz + dz) for dz in (0, -sfd / 4, sfd / 4, -sfd / 2, sfd / 2)]
            for px, pz in cand:
                r2 = try_place_at(room, placed, tv_item, px, pz, reserved)
                if r2 is None:
                    continue
                f2, c2x, c2z, b2 = r2
                placed.append({"item": tv_item, "foot": f2, "cx": c2x, "cz": c2z,
                               "band": b2, "ir": tv_obj, "index": len(placed_all) + 1,
                               "rid": room["rid"]})
                placed_all.append(placed[-1])
                handled.add(id(tv_obj))
                break

    table_obj = next((o for o in objs
                      if o.get("category") == "table"
                      and ("茶几" in str(o.get("label") or "") or "coffee" in str(o.get("label") or "").lower())), None)
    if table_obj is not None:
        table_item, why = pick_item(items, "table", table_obj.get("size_est_m") or [1.0, 0.55, 0.4],
                                    used_count, inner_x, inner_z, style=style,
                                    room_tags=_room_style_tags(placed))
        if table_item is not None:
            tfw = table_item["size_studs"][0] * LDU
            tfd = table_item["size_studs"][2] * LDU
            if band == "N":
                z = cz + sfd / 2 + tfd / 2 + gap
                cand = [(cx + dx, z) for dx in (0, -sfw / 4, sfw / 4)]
            elif band == "S":
                z = cz - sfd / 2 - tfd / 2 - gap
                cand = [(cx + dx, z) for dx in (0, -sfw / 4, sfw / 4)]
            elif band == "W":
                x = cx + sfw / 2 + tfw / 2 + gap
                cand = [(x, cz + dz) for dz in (0, -sfd / 4, sfd / 4)]
            else:
                x = cx - sfw / 2 - tfw / 2 - gap
                cand = [(x, cz + dz) for dz in (0, -sfd / 4, sfd / 4)]
            for px, pz in cand:
                r3 = try_place_at(room, placed, table_item, px, pz, reserved)
                if r3 is None:
                    continue
                f3, c3x, c3z, b3 = r3
                placed.append({"item": table_item, "foot": f3, "cx": c3x, "cz": c3z,
                               "band": b3, "ir": table_obj, "index": len(placed_all) + 1,
                               "rid": room["rid"]})
                placed_all.append(placed[-1])
                handled.add(id(table_obj))
                break
    return handled


def norm_name(s):
    return str(s or "").lower().replace("_", " ").strip()


def dims_pick(pool, o):
    """[v1.3] Break same-name ambiguity with a W×D token in the object's own text
    (e.g. placement「卧室（3600×4000）：床头靠东墙」-> the 3600×4000 room).
    Matches mm tokens (3600×4000) and metre tokens (3.6 m×4.0 m). None if not unique."""
    text = " ".join(str(o.get(k) or "") for k in ("room", "label", "placement"))
    pairs = set()
    for a, b in re.findall(r"(\d{3,4})\s*[×xX*]\s*(\d{3,4})", text):
        pairs.add(frozenset((int(a), int(b))))
    for a, b in re.findall(r"(\d+(?:\.\d+)?)\s*m?\s*[×xX*]\s*(\d+(?:\.\d+)?)\s*m", text):
        pairs.add(frozenset((round(float(a) * 1000), round(float(b) * 1000))))
    if not pairs:
        return None
    hits = [r for r in pool
            if frozenset((round(r["dims_m"][0] * 1000), round(r["dims_m"][1] * 1000))) in pairs]
    return hits[0] if len(hits) == 1 else None


def find_room(rooms, o, rr, prefer=None):
    """Resolve an object's `room` string to a room zone [v1.3].
    Same-name multi-instance IRs (e.g. R1 三个「卧室」) must neither collapse
    into one pool nor duplicate into every zone. Ambiguity resolution order:
    exact match (name_en preferred — image arms reference name_en) -> dims token
    in the object text -> `prefer` (the instance used by the preceding run of
    same-named objects) -> round-robin via the rr counter dict; pass 2 prefers
    the longest name hit."""
    rn = norm_name(o.get("room"))
    if not rn:
        return None
    exact = [r for r in rooms if rn in (norm_name(r.get("name_cn")), norm_name(r.get("name_en")))]
    if exact:
        pool = [r for r in exact if norm_name(r.get("name_en")) == rn] or exact
        if len(pool) > 1:
            hit = dims_pick(pool, o)
            if hit is not None:
                return hit
            if prefer in pool:
                return prefer
        key = ("exact", rn)
        i = rr.get(key, 0)
        rr[key] = i + 1
        return pool[i % len(pool)]
    sub = []
    for r in rooms:                                     # pass 2: substring either way
        for k in ("name_cn", "name_en"):
            nm = norm_name(r.get(k))
            if nm and (nm in rn or rn in nm):
                sub.append((len(nm), r))
                break
    if not sub:
        return None
    best = max(n for n, _ in sub)
    pool = [r for n, r in sub if n == best]
    if len(pool) > 1:
        hit = dims_pick(pool, o)
        if hit is not None:
            return hit
        if prefer in pool:
            return prefer
    key = ("sub", rn)
    i = rr.get(key, 0)
    rr[key] = i + 1
    return pool[i % len(pool)]


def room_of(rooms, px, pz):
    for r in rooms:
        if r["x0"] - 1 <= px <= r["x1"] + 1 and r["z0"] - 1 <= pz <= r["z1"] + 1:
            dup = sum(1 for q in rooms if q["name_cn"] == r["name_cn"]) > 1
            return f'{r["name_cn"]}#{r["rid"]}' if dup else r["name_cn"]
    return "?"  # footprint centre outside every zone (record, don't crash)


def global_overlaps(rooms, placed_all):
    """[v1c] pairwise footprint intersection count over ALL placements (cross-room included)."""
    out = []
    for i in range(len(placed_all)):
        for j in range(i + 1, len(placed_all)):
            a, b = placed_all[i], placed_all[j]
            if overlaps(a["foot"], b["foot"]):
                ox = min(a["foot"]["x1"], b["foot"]["x1"]) - max(a["foot"]["x0"], b["foot"]["x0"])
                oz = min(a["foot"]["z1"], b["foot"]["z1"]) - max(a["foot"]["z0"], b["foot"]["z0"])
                out.append({
                    "a_no": a["index"], "a_id": a["item"]["id"], "a_room": room_of(rooms, a["cx"], a["cz"]),
                    "b_no": b["index"], "b_id": b["item"]["id"], "b_room": room_of(rooms, b["cx"], b["cz"]),
                    "overlap_ldu": [round(ox, 1), round(oz, 1)],
                })
    return out


def main():
    ap = argparse.ArgumentParser(description="FYP pipeline v1 M3+M4+M5 (deterministic)")
    ap.add_argument("--ir", required=True, help="scene IR json (M2 output)")
    ap.add_argument("--name", required=True, help="scene name -> out/<name>/")
    ap.add_argument("--library", default=str(DEFAULT_LIBRARY))
    ap.add_argument("--out", default=str(HERE / "out"))
    args = ap.parse_args()

    ir_path = Path(args.ir).resolve()
    lib = Path(args.library)
    outdir = Path(args.out) / args.name
    outdir.mkdir(parents=True, exist_ok=True)

    ir = json.loads(ir_path.read_text(encoding="utf-8"))
    items = load_items(lib)
    build_opts = ir.get("_build") or {}
    style = build_opts.get("program_style") or ""

    # room zones: explicit topology (`layout_m`, [N1]) or row-major packing in IR order
    layout = ir.get("layout_m") or {}
    rooms = []
    cx = cz = 0.0
    row_depth = 0.0
    target_w = max(max(r["dims_m"][0] for r in ir["rooms"]),
                   (sum(r["dims_m"][0] * r["dims_m"][1] for r in ir["rooms"]) * 1.6) ** 0.5)
    for r in ir["rooms"]:
        w, d = m2ldu(r["dims_m"][0]), m2ldu(r["dims_m"][1])
        origin = layout.get(str(len(rooms))) or layout.get(r.get("name_cn")) or layout.get(r.get("name_en"))
        if origin:
            x0, z0 = m2ldu(origin[0]), m2ldu(origin[1])
        else:
            if cx > 0 and cx + w > m2ldu(target_w):
                cx = 0.0
                cz += row_depth + ROOM_GAP * LDU
                row_depth = 0.0
            x0, z0 = cx, cz
            cx += w + ROOM_GAP * LDU
            row_depth = max(row_depth, d)
        rooms.append({**r, "rid": len(rooms), "x0": x0, "z0": z0,
                      "x1": x0 + w, "z1": z0 + d, "w": w, "d": d})

    # Door/window openings are needed before furniture placement so the
    # circulation pass can reserve a clear approach on both sides of every door.
    # Real-plan IRs often omit room_type; infer it only for opening generation
    # (entrance/bathroom doors) without changing the furniture programme.
    rooms_for_openings = rooms
    if build_opts.get("openings", False):
        rooms_for_openings = [
            {**r, "room_type": r.get("room_type")
             or floorplan.infer_room_type(r.get("name_en"), r.get("name_cn"))}
            for r in rooms
        ]
    openings = (walls.wall_openings(rooms_for_openings)
                if build_opts.get("walls", True) and build_opts.get("openings", False) else [])
    door_depth = float(build_opts.get("door_clearance_ldu")
                       or 20)
    door_zones = walls.door_clearance_zones(rooms, openings, depth_ldu=door_depth)
    # Relation preferences are part of the product path.  The frozen
    # benchmark runs with openings=false, so it keeps its original placement
    # order and results; an explicit `_build.relations` still overrides this.
    use_relations = bool(build_opts.get("relations", bool(openings)))

    # [N2] variant knobs
    shift = int(build_opts.get("pref_shift", 0) or 0) % 4
    pref_active = {c: s[shift:] + s[:shift] for c, s in PREF.items()} if shift else PREF
    # Diversity v1: an explicit per-category wall preference overrides pref_shift.
    wall_prefs = build_opts.get("wall_prefs") or {}
    if wall_prefs:
        pref_active = {c: str(wall_prefs.get(c, s)) for c, s in PREF.items()}
    reverse_bands = build_opts.get("band_start") or []
    palette = build_opts.get("palette")
    bias = float(build_opts.get("item_bias", 1.0) or 1.0)

    by_room = {}
    rr = {}
    last_key, cur_room = None, None
    for o in ir["objects"]:
        rn = norm_name(o.get("room"))
        prefer = cur_room if (rn and rn == last_key) else None   # same-run instance [v1.3]
        room = find_room(rooms, o, rr, prefer)
        last_key, cur_room = rn, room
        if room is None:
            continue
        by_room.setdefault(room["rid"], []).append(o)

    placed_all, dropped = [], []
    used_count = {}
    for room in rooms:
        objs = by_room.get(room["rid"], [])
        objs.sort(key=lambda o: CAT_ORDER.index(o["category"]) if o.get("category") in CAT_ORDER else 99)
        slots = band_slots(room, reverse_bands)
        placed = []
        m = MARGIN * LDU
        inner_x = room["x1"] - room["x0"] - 2 * m
        inner_z = room["z1"] - room["z0"] - 2 * m
        if build_opts.get("living_set", bool(openings)) and room.get("room_type") == "living":
            handled = _place_living_set(room, objs, slots, placed, placed_all, items,
                                        used_count, style, pref_active,
                                        door_zones.get(room["rid"], []))
            if handled:
                objs = [o for o in objs if id(o) not in handled]
        if build_opts.get("bedside", bool(openings)) and room.get("room_type") == "bedroom":
            handled = _place_bed_set(room, objs, slots, placed, placed_all, items,
                                     used_count, style, pref_active,
                                     door_zones.get(room["rid"], []))
            if handled:
                objs = [o for o in objs if id(o) not in handled]
        if build_opts.get("center_dining", bool(openings)) and room.get("room_type") == "dining":
            handled = _place_dining_set(room, objs, placed, placed_all, items, used_count,
                                        style, door_zones.get(room["rid"], []), dropped)
            if handled:
                objs = [o for o in objs if id(o) not in handled]
        for o in objs:
            cat = o.get("category")
            count = int(o.get("count", 1) or 1)
            if cat not in CAT_ORDER:
                dropped.append({"room": room["name_cn"], "object": o.get("label"), "why": "category 'other' (no library)"})
                continue
            size_est = o.get("size_est_m") or [1.0, 1.0, 0.8]
            size_est = [v * bias for v in size_est]
            for k in range(count):
                item, why = pick_item(items, cat, size_est, used_count, inner_x, inner_z,
                                      style=style, room_tags=_room_style_tags(placed))
                if item is None:
                    dropped.append({"room": room["name_cn"], "object": f"{o.get('label')} #{k+1}", "why": why})
                    continue
                pref_for_obj = (relations.override(pref_active, o, placed)
                                if use_relations else pref_active)
                res = try_place(room, slots, placed, item, cat, pref_for_obj,
                                reserved=door_zones.get(room["rid"], []))
                if res is None:
                    dropped.append({"room": room["name_cn"], "object": f"{o.get('label')} #{k+1}",
                                    "why": "no free wall slot (bands full)"})
                    continue
                foot, pcx, pcz, band = res
                placed.append({"item": item, "foot": foot, "cx": pcx, "cz": pcz,
                               "band": band, "ir": o, "index": len(placed_all) + 1,
                               "rid": room["rid"]})
                placed_all.append(placed[-1])

    # Bathroom door repair [P1]: a toilet/sink can sit directly behind the
    # original centred door.  Slide the door along the same shared wall; if no
    # free approach exists and the bathroom has another door, drop this one.
    bathroom_door_moves = []
    bathroom_doors_removed = []
    if openings:
        bath_rids = {r["rid"] for r in rooms_for_openings if r.get("room_type") == "bathroom"}
        openings, bathroom_door_moves, bathroom_doors_removed = walls.fix_bathroom_doors(
            rooms, openings, placed_all, bath_rids=bath_rids)
        if bathroom_door_moves or bathroom_doors_removed:
            door_zones = walls.door_clearance_zones(rooms, openings, depth_ldu=door_depth)

    # Circulation / walkability [P0-2]: after the wall-band placement, remove
    # low-priority furniture until every room's doors are in one free-space
    # component.  With no openings (the frozen benchmark) this is a no-op.
    circulation_removed = []
    circulation_summary = circulation.analyze(rooms, placed_all, openings)
    if openings and build_opts.get("circulation", True):
        placed_all, circulation_removed, circulation_summary = circulation.repair(
            rooms, placed_all, openings)
        if circulation_removed:
            for rec in circulation_removed:
                dropped.append({
                    "room": room_of(rooms, rec["cx"], rec["cz"]),
                    "object": (rec.get("ir") or {}).get("label"),
                    "why": rec["why"],
                })
            for i, p in enumerate(placed_all, 1):
                p["index"] = i
    circulation_summary["removed"] = len(circulation_removed)

    # Window placement [P0-3]: openings are generated before furniture, so a
    # tall item can end up in front of a window.  Slide windows along the same
    # exterior edge to the nearest free interval; doors are untouched.
    window_moves = []
    if openings:
        openings, window_moves = walls.reposition_windows(rooms, openings, placed_all)

    # Real LEGO floors: room footprint (or IR.floor_m outline) -> 24-LDU-tall
    # bricks whose top face is the y=0 scene plane [floors.py].
    floor_rects = floors.rects_from_ir(ir, rooms)
    floor_bricks = (floors.floor_bricks(rooms, ir=ir, rects_ldu=floor_rects)
                    if build_opts.get("floor", True) else [])
    for i, b in enumerate(floor_bricks, 1):
        b["no"] = i

    # Real LEGO walls: boundary edges -> 5 courses of 1xN bricks [walls.py].
    # `_build.walls = false` keeps the old furniture-only scene for comparison.
    wall_bricks = walls.wall_bricks(rooms, openings) if build_opts.get("walls", True) else []
    opening_parts = walls.opening_parts(openings) if openings else []
    for i, b in enumerate(wall_bricks, 1):
        b["no"] = i
    wall_overlaps = walls.check_wall_furniture(wall_bricks, placed_all)

    # compose MPD (flat; translate each library body by anchor + placement)
    lines = [f"0 FILE {args.name}.ldr", f"0 FYP pipeline v1 scene - {args.name}",
             f"0 Name: {args.name}.ldr", "0 Author: fyp-pipeline v1 deterministic assembler"]
    table = []
    color_hist = {}
    for p in placed_all:
        ax, ay, az = p["item"]["anchor"]
        tx, ty, tz = ax + p["cx"], ay, az + p["cz"]
        parts = recolor_parts(p["item"]["parts"], palette) if palette else p["item"]["parts"]
        for ln in parts:
            t = ln.split()
            x, y, z = float(t[2]) + tx, float(t[3]) + ty, float(t[4]) + tz
            lines.append(" ".join([t[0], t[1], f"{x:.4f}", f"{y:.4f}", f"{z:.4f}", *t[5:]]))
            color_hist[t[1]] = color_hist.get(t[1], 0) + 1
        table.append({
            "no": p["index"],
            "library_id": p["item"]["id"],
            "category": p["item"]["category"],
            "room": room_of(rooms, p["cx"], p["cz"]),
            "wall_band": p["band"],
            "center_ldu": [round(p["cx"], 1), 0.0, round(p["cz"], 1)],
            "footprint_ldu": [round(p["foot"]["x1"] - p["foot"]["x0"], 1), round(p["foot"]["z1"] - p["foot"]["z0"], 1)],
            "foot_ldu": [round(p["foot"]["x0"], 1), round(p["foot"]["z0"], 1),
                         round(p["foot"]["x1"], 1), round(p["foot"]["z1"], 1)],
            "ir_label": p["ir"].get("label"),
        })
    if floor_bricks:
        lines.append(floors.FLOOR_MARKER)
        lines.extend(floors.mpd_line(b) for b in floor_bricks)
    if wall_bricks:
        lines.append(walls.WALLS_MARKER)
        lines.extend(walls.mpd_line(b) for b in wall_bricks)
    if opening_parts:
        lines.append(walls.OPENINGS_MARKER)
        lines.extend(walls.mpd_line(b) for b in opening_parts)
    lines.append("0")
    (outdir / f"{args.name}.mpd").write_text("\n".join(lines) + "\n", encoding="utf-8")

    cross = global_overlaps(rooms, placed_all)
    requested = sum(int(o.get("count", 1) or 1) for o in ir["objects"] if o.get("category") in CAT_ORDER)
    furniture_parts = sum(p["item"]["part_count"] for p in placed_all)
    placement = {
        "source_ir": str(ir_path),
        "scene": f"{args.name}.mpd",
        "pipeline": "lego-nova (refactor of fyp-pipeline v1.3)",
        "build_options": build_opts,
        "layout_mode": "explicit" if layout else "row-major",
        "rooms": [{"name_cn": r["name_cn"], "rid": r["rid"], "zone_ldu": [r["x0"], r["z0"], r["x1"], r["z1"]]} for r in rooms],
        "placed_count": len(placed_all),
        "requested_count": requested,
        "coverage": f"{len(placed_all)}/{requested}",
        "furniture_parts": furniture_parts,
        "floor_parts": len(floor_bricks),
        "wall_parts": len(wall_bricks),
        "opening_parts": len(opening_parts),
        "parts_total": furniture_parts + len(floor_bricks) + len(wall_bricks) + len(opening_parts),
        "floor_rects_ldu": [[round(v, 1) for v in r] for r in floor_rects],
        "floor_summary": floors.floor_summary(floor_bricks, floor_rects),
        "wall_summary": walls.wall_summary(wall_bricks, openings, len(opening_parts)),
        "openings": openings,
        "door_clearance_zones": {str(rid): zones for rid, zones in door_zones.items()},
        "circulation": circulation_summary,
        "window_moves": window_moves,
        "bathroom_door_moves": bathroom_door_moves,
        "bathroom_doors_removed": bathroom_doors_removed,
        "furniture_colors": dict(sorted(color_hist.items())),
        "wall_furniture_overlaps": wall_overlaps,
        "cross_room_overlaps": cross,
        "placements": table,
        "floors": floor_bricks,
        "walls": wall_bricks,
        "dropped": dropped,
    }
    (outdir / f"{args.name}.placements.json").write_text(json.dumps(placement, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{args.name}: placed {len(placed_all)}/{requested} "
          f"(parts {placement['parts_total']} = furniture {furniture_parts} "
          f"+ floor {len(floor_bricks)} + walls {len(wall_bricks)} "
          f"+ openings {len(opening_parts)}), "
          f"dropped {len(dropped)}, cross-room overlaps {len(cross)}, "
          f"wall-furniture overlaps {len(wall_overlaps)}, "
          f"circulation {circulation_summary.get('connected')} "
          f"(walkable {circulation_summary.get('walkable_ratio')}, "
          f"removed {circulation_summary.get('removed', 0)}), "
          f"windows moved {len(window_moves)}, "
          f"bath doors moved {len(bathroom_door_moves)}/removed {len(bathroom_doors_removed)}")
    for d in dropped:
        print(f"  dropped: {d['room']} {d['object']} - {d['why']}")
    for x in cross:
        print(f"  OVERLAP: #{x['a_no']} {x['a_id']}@{x['a_room']} x #{x['b_no']} {x['b_id']}@{x['b_room']} = {x['overlap_ldu']}")
    print(f"-> {outdir / (args.name + '.mpd')}")


if __name__ == "__main__":
    main()
